/**
 * Background Service Worker - V3.1.1
 * 重构：使用模块化消息处理器
 * 修复：并发状态、请求指纹随机化、间隔抖动、进度通知
 */

import { MessageType, KnowledgeType, platformConfig, AIProvider } from '../lib/types';
import { messageRouter } from '../lib/message-handlers';
import { stateManager } from '../lib/state-manager';

// ==================== 插件安装初始化 ====================
chrome.runtime.onInstalled.addListener(async () => {
  console.log('Rednote2Notion V3.1.1 插件已安装');
  // 初始化跨域规则
  await chrome.declarativeNetRequest.updateEnabledRulesets({
    enableRulesetIds: ['ruleset_1']
  });
});

// ==================== 消息监听（使用模块化路由）====================
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  // 使用消息路由处理
  messageRouter.handle(message, sender)
    .then(result => sendResponse(result))
    .catch(error => sendResponse({ success: false, error: error.message }));
  
  // 返回true表示异步响应
  return true;
});

// ==================== 定时同步闹钟 ====================
chrome.alarms.onAlarm.addListener(async (alarm) => {
  if (alarm.name.startsWith('rednote-sync-')) {
    const platform = alarm.name.replace('rednote-sync-', '') as keyof typeof platformConfig;
    console.log(`[定时同步] 闹钟触发: ${platform}`);
    
    // 从存储获取同步配置
    const config = await stateManager.get('sync_config') as any;
    if (config?.notionApiKey && config?.notionDatabaseId) {
      // 触发同步
      messageRouter.handle({
        name: MessageType.SYNC_TO_NOTION,
        data: {
          platform,
          notionApiKey: config.notionApiKey,
          notionDatabaseId: config.notionDatabaseId,
          ...config
        }
      }, { tab: undefined });
    }
  }
});

// ==================== 导出（供其他模块使用）====================
export { platformConfig };

import { AIProvider, AI_MODEL_PRESETS } from './types';
import type { AIAnalysisResult, KnowledgeTopic, SmartKnowledgeNote, AIModelConfig } from './types';
import { createAIClient } from './ai-service';

/**
 * AI智能分析笔记内容
 * 整合四个方案：主题归类 + 智能标签 + 内容索引 + 路径推荐
 */
export const analyzeNoteContent = async (
  title: string,
  content: string,
  config: AIModelConfig
): Promise<AIAnalysisResult> => {
  const preset = AI_MODEL_PRESETS[config.provider];
  const model = config.model || preset.defaultModel;
  
  const prompt = `你是一个知识管理专家。请分析以下小红书笔记内容，输出JSON格式的分析结果。

笔记标题：${title}
笔记内容：${content}

请输出以下内容（JSON格式）：
{
  "topic": "知识主题（编程开发/设计美学/理财投资/职场成长/健康生活/语言学习/效率工具/兴趣爱好/其他）",
  "subTopic": "具体子主题（如Python、UI设计、基金定投、时间管理等）",
  "tags": ["#教程", "#案例", "#工具", "#干货"等3-5个标签],
  "summary": "一句话摘要（50字以内，概括核心价值）",
  "keywords": ["关键词1", "关键词2", "关键词3"],
  "applicableScenarios": "适用场景（如：写Python代码时、做理财规划时）",
  "learningPathSuggestion": "学习路径建议（如：适合作为Python入门第二步）",
  "relatedNoteIds": []
}

只输出JSON，不要其他内容。`;

  try {
    const client = createAIClient(config);
    
    const response = await client.chat.completions.create({
      model: model,
      messages: [
        { role: 'system', content: '你是一个专业的知识管理专家，擅长内容分析和知识整理。' },
        { role: 'user', content: prompt }
      ],
      max_tokens: 1000,
      temperature: 0.7
    });

    const content = response.choices[0]?.message?.content;
    if (!content) {
      return getDefaultAnalysis(title);
    }

    // 尝试解析JSON响应
    const jsonMatch = content.match(/\{[\s\S]*\}/);
    if (jsonMatch) {
      const result = JSON.parse(jsonMatch[0]) as AIAnalysisResult;
      // 验证topic是否在允许的枚举值中
      if (!isValidTopic(result.topic)) {
        result.topic = '其他';
      }
      return result;
    }

    return getDefaultAnalysis(title);
  } catch (error) {
    console.error('AI分析失败:', error);
    return getDefaultAnalysis(title);
  }
};

/**
 * 验证主题是否在允许的枚举值中
 */
const isValidTopic = (topic: string): topic is KnowledgeTopic => {
  const validTopics: KnowledgeTopic[] = [
    '编程开发', '设计美学', '理财投资', '职场成长',
    '健康生活', '语言学习', '效率工具', '兴趣爱好', '其他'
  ];
  return validTopics.includes(topic as KnowledgeTopic);
};

/**
 * 获取相似笔记（用于学习路径关联）
 * @param noteId 当前笔记ID
 * @param keywords 当前笔记关键词
 * @param title 当前笔记标题
 * @param allNotes 所有笔记
 * @param limit 返回数量限制
 * @returns 相关笔记ID列表
 */
export const findRelatedNotes = (
  noteId: string,
  keywords: string[],
  title: string,
  allNotes: SmartKnowledgeNote[],
  limit: number = 5
): string[] => {
  if (allNotes.length === 0) return [];

  // 简单的关键词匹配算法
  const scored = allNotes
    .filter(n => n.id !== noteId)
    .map(n => ({
      id: n.id,
      score: calculateRelevanceScore(keywords, n.keywords, title, n.title)
    }))
    .filter(s => s.score > 0) // 过滤掉完全不相关的
    .sort((a, b) => b.score - a.score)
    .slice(0, limit);

  return scored.map(s => s.id);
};

/**
 * 计算两篇笔记的相关性得分
 */
const calculateRelevanceScore = (
  keywords1: string[],
  keywords2: string[],
  title1: string,
  title2: string
): number => {
  let score = 0;
  
  // 1. 关键词匹配（权重最高）
  const commonKeywords = keywords1.filter(k => 
    keywords2.some(k2 => k.toLowerCase() === k2.toLowerCase())
  );
  score += commonKeywords.length * 10;

  // 2. 标题关键词匹配（次要权重）
  const titleWords1 = extractTitleKeywords(title1);
  const titleWords2 = extractTitleKeywords(title2);
  const commonTitleWords = titleWords1.filter(w => titleWords2.includes(w));
  score += commonTitleWords.length * 5;

  // 3. 额外关键词匹配奖励
  const allKeywords2 = [...keywords2, ...titleWords2];
  keywords1.forEach(k => {
    if (allKeywords2.some(k2 => k2.includes(k) || k.includes(k2))) {
      score += 2;
    }
  });

  return score;
};

/**
 * 从标题中提取关键词
 */
const extractTitleKeywords = (title: string): string[] => {
  if (!title) return [];
  
  // 移除常见符号和停用词
  const stopWords = ['的', '了', '是', '在', '和', '与', '及', '或', '如何', '怎么', '怎样', '教程', '技巧', '方法'];
  
  return title
    .replace(/[^\u4e00-\u9fa5a-zA-Z0-9]/g, ' ')
    .split(/\s+/)
    .filter(word => word.length > 1 && !stopWords.includes(word));
};

/**
 * 默认分析结果（AI调用失败时使用）
 */
const getDefaultAnalysis = (title: string): AIAnalysisResult => ({
  topic: '其他',
  subTopic: '未分类',
  tags: [],
  summary: title.slice(0, 50),
  keywords: [],
  applicableScenarios: '通用场景',
  learningPathSuggestion: '',
  relatedNoteIds: []
});

/**
 * 批量分析笔记内容
 * @param notes 笔记列表
 * @param config AI配置
 * @param onProgress 进度回调
 * @param batchSize 批量大小，默认5
 */
export const batchAnalyzeNotes = async (
  notes: Array<{ id: string; title: string; content: string }>,
  config: AIModelConfig,
  onProgress?: (current: number, total: number) => void,
  batchSize: number = 5
): Promise<Map<string, AIAnalysisResult>> => {
  const results = new Map<string, AIAnalysisResult>();
  const total = notes.length;

  for (let i = 0; i < notes.length; i += batchSize) {
    const batch = notes.slice(i, i + batchSize);
    
    const batchResults = await Promise.all(
      batch.map(async (note) => {
        const result = await analyzeNoteContent(note.title, note.content, config);
        return { id: note.id, result };
      })
    );

    batchResults.forEach(({ id, result }) => {
      results.set(id, result);
    });

    // 报告进度
    if (onProgress) {
      onProgress(Math.min(i + batchSize, total), total);
    }

    // 添加延迟以避免API限流
    if (i + batchSize < notes.length) {
      await new Promise(resolve => setTimeout(resolve, 1000));
    }
  }

  return results;
};

/**
 * 生成学习路径建议
 */
export const generateLearningPathSuggestion = (
  currentNote: SmartKnowledgeNote,
  allNotes: SmartKnowledgeNote[]
): string => {
  const sameTopicNotes = allNotes.filter(
    n => n.knowledgeTopic === currentNote.knowledgeTopic && n.id !== currentNote.id
  );

  if (sameTopicNotes.length === 0) {
    return `这是您收藏的第一篇「${currentNote.knowledgeTopic}」相关文章，建议作为入门学习。`;
  }

  // 根据学习状态分组
  const masteredNotes = sameTopicNotes.filter(n => n.learningStatus === '已掌握');
  const learningNotes = sameTopicNotes.filter(n => n.learningStatus === '学习中');
  const notStartedNotes = sameTopicNotes.filter(n => n.learningStatus === '未学');

  if (masteredNotes.length > 0) {
    return `您已掌握 ${masteredNotes.length} 篇同主题内容，建议在巩固基础上继续深入学习。`;
  }

  if (learningNotes.length > 0) {
    return `您正在学习 ${learningNotes.length} 篇同主题内容，建议按学习顺序逐步推进。`;
  }

  return `建议先学习基础知识，再逐步深入到本篇内容的实践应用。`;
};

/**
 * 验证分析结果是否完整
 */
export const validateAnalysisResult = (result: AIAnalysisResult): boolean => {
  return (
    result.topic !== undefined &&
    result.subTopic !== undefined &&
    Array.isArray(result.tags) &&
    typeof result.summary === 'string' &&
    Array.isArray(result.keywords) &&
    typeof result.applicableScenarios === 'string'
  );
};

/**
 * 合并多个分析结果（用于聚合分析）
 */
export const mergeAnalysisResults = (
  results: AIAnalysisResult[]
): {
  topics: Record<string, number>;
  allTags: string[];
  commonKeywords: string[];
} => {
  const topics: Record<string, number> = {};
  const allTags: string[] = [];
  const allKeywords: string[][] = [];

  results.forEach(result => {
    // 统计主题分布
    topics[result.topic] = (topics[result.topic] || 0) + 1;
    
    // 收集所有标签
    allTags.push(...result.tags);
    
    // 收集所有关键词
    allKeywords.push(result.keywords);
  });

  // 计算共同关键词
  const commonKeywords = findCommonKeywords(allKeywords);

  return {
    topics,
    allTags: [...new Set(allTags)],
    commonKeywords
  };
};

/**
 * 找出多个关键词数组的交集
 */
const findCommonKeywords = (keywordArrays: string[][]): string[] => {
  if (keywordArrays.length === 0) return [];
  if (keywordArrays.length === 1) return keywordArrays[0];

  const firstArray = keywordArrays[0];
  const normalizedFirst = firstArray.map(k => k.toLowerCase());

  return firstArray.filter(keyword => 
    keywordArrays.slice(1).every(arr => 
      arr.some(k => k.toLowerCase() === keyword.toLowerCase())
    )
  );
};

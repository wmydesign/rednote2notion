/**
 * 并发控制模块 V3.1.1
 * 实现 3-5 个并发优化、速率限制、失败重试
 * 支持：并发队列、令牌桶限流、指数退避重试
 * 新增：锁机制、状态校验、请求间隔随机化
 */

// ==================== 类型定义 ====================
export interface ConcurrentQueueOptions {
  concurrency: number;          // 并发数量（推荐 3-5）
  timeout?: number;             // 单任务超时时间（毫秒）
  retries?: number;             // 失败重试次数
  retryDelay?: number;          // 重试延迟（毫秒）
  onProgress?: ProgressCallback;// 进度回调
  onTaskComplete?: TaskCompleteCallback; // 任务完成回调
  onTaskError?: TaskErrorCallback; // 任务错误回调
  enableLock?: boolean;         // 启用锁机制
}

export interface QueueTask<T = any> {
  id: string;
  fn: () => Promise<T>;
  retries: number;
  result?: T;
  error?: Error;
  status: 'pending' | 'running' | 'completed' | 'failed';
}

export type ProgressCallback = (completed: number, total: number, running?: number) => void;
export type TaskCompleteCallback = <T>(taskId: string, result: T) => void;
export type TaskErrorCallback = (taskId: string, error: Error, retries: number) => void;

export interface RateLimiterOptions {
  tokensPerInterval: number;    // 每间隔时间产生的令牌数
  interval: number;             // 间隔时间（毫秒）
  burstSize?: number;           // 突发容量
}

// ==================== 状态锁 ====================
class StateLock {
  private locks: Map<string, Promise<void>> = new Map();
  private readonly maxWaitTime = 30000; // 30秒最大等待时间

  /**
   * 获取锁
   */
  async acquire(key: string): Promise<() => void> {
    const startTime = Date.now();
    
    while (this.locks.has(key)) {
      if (Date.now() - startTime > this.maxWaitTime) {
        throw new Error(`获取锁超时: ${key}`);
      }
      // 等待锁释放
      await new Promise(resolve => setTimeout(resolve, 50));
    }

    let releaseFn: (() => void) | null = null;
    const lockPromise = new Promise<void>((resolve) => {
      releaseFn = () => resolve();
    });
    
    this.locks.set(key, lockPromise);
    
    // 返回释放函数
    return () => {
      if (this.locks.get(key) === lockPromise) {
        this.locks.delete(key);
      }
    };
  }

  /**
   * 检查锁状态
   */
  isLocked(key: string): boolean {
    return this.locks.has(key);
  }

  /**
   * 强制释放锁
   */
  forceRelease(key: string): void {
    this.locks.delete(key);
  }

  /**
   * 释放所有锁
   */
  releaseAll(): void {
    this.locks.clear();
  }
}

// ==================== 全局状态锁实例 ====================
const globalLock = new StateLock();

// ==================== 并发队列类 ====================
export class ConcurrentQueue {
  private concurrency: number;
  private timeout: number;
  private retries: number;
  private retryDelay: number;
  private onProgress?: ProgressCallback;
  private onTaskComplete?: TaskCompleteCallback;
  private onTaskError?: TaskErrorCallback;
  private enableLock: boolean;

  private queue: QueueTask[] = [];
  private running: number = 0;
  private completed: number = 0;
  private paused: boolean = false;
  private processing: boolean = false;  // 状态校验：防止重复处理
  private taskCounter: number = 0;        // 任务计数器
  private taskLock: StateLock;           // 任务级别锁

  // 任务锁（用于单个任务的状态保护）
  private taskLocks: Map<string, Promise<void>> = new Map();

  constructor(options: ConcurrentQueueOptions) {
    this.concurrency = Math.min(Math.max(options.concurrency, 1), 10);
    this.timeout = options.timeout || 30000;
    this.retries = options.retries || 2;
    this.retryDelay = options.retryDelay || 1000;
    this.onProgress = options.onProgress;
    this.onTaskComplete = options.onTaskComplete;
    this.onTaskError = options.onTaskError;
    this.enableLock = options.enableLock ?? true;
    this.taskLock = new StateLock();
  }

  /**
   * 添加任务到队列（线程安全）
   */
  add<T>(fn: () => Promise<T>, id?: string): Promise<T> {
    return new Promise(async (resolve, reject) => {
      const taskId = id || `task_${Date.now()}_${++this.taskCounter}`;
      
      // 状态校验：检查任务是否已存在
      const existingTask = this.queue.find(t => t.id === taskId && t.status === 'pending');
      if (existingTask) {
        reject(new Error(`任务 ${taskId} 已在队列中`));
        return;
      }

      const task: QueueTask = {
        id: taskId,
        fn: async () => {
          // 任务锁
          const releaseTaskLock = await this.taskLock.acquire(taskId);
          try {
            const result = await fn();
            return result;
          } finally {
            releaseTaskLock();
          }
        },
        retries: this.retries,
        status: 'pending',
      };

      // 包装任务以支持 resolve/reject
      (task as any)._resolve = resolve;
      (task as any)._reject = reject;

      this.queue.push(task);
      this.process();
    });
  }

  /**
   * 批量添加任务
   */
  addBatch<T>(fns: (() => Promise<T>)[], baseId?: string): Promise<T[]> {
    return Promise.all(fns.map((fn, i) => this.add(fn, `${baseId || 'batch'}_${i}`)));
  }

  /**
   * 处理队列（线程安全 - 使用原子锁）
   */
  private async process(): Promise<void> {
    // 使用原子锁保护，防止竞态条件
    const releaseProcess = await this.taskLock.acquire('process_lock');
    
    try {
      // 双重检查
      if (this.paused) return;
      if (this.running >= this.concurrency) return;
      if (this.queue.length === 0) return;
      
      // 找到第一个pending状态的任务
      const pendingIndex = this.queue.findIndex(t => t.status === 'pending');
      if (pendingIndex === -1) return;

      const task = this.queue.splice(pendingIndex, 1)[0];
      if (!task) return;

      task.status = 'running';
      this.running++;

      // 异步执行任务（不阻塞队列继续处理）
      this.executeTask(task);
      
      // 如果还有空闲槽位，继续处理下一个
      if (this.running < this.concurrency && this.queue.length > 0) {
        setTimeout(() => this.process(), 0);
      }
    } finally {
      releaseProcess();
    }
  }

  /**
   * 执行单个任务
   */
  private async executeTask(task: QueueTask): Promise<void> {
    try {
      const result = await this.executeWithRetry(task);
      task.result = result;
      task.status = 'completed';
      (task as any)._resolve?.(result);
      this.completed++;
      this.onProgress?.(this.completed, this.completed + this.queue.length + this.running, this.running);
      this.onTaskComplete?.(task.id, result);
    } catch (error) {
      task.error = error as Error;
      task.status = 'failed';
      (task as any)._reject?.(error);
      this.onTaskError?.(task.id, error as Error, task.retries);
    } finally {
      this.running--;
      // 继续处理队列
      if (!this.paused && this.queue.length > 0) {
        this.process();
      }
    }
  }

  private async processInternal(): Promise<void> {
    // 保留兼容性，调用新的process方法
    await this.process();
  }

  /**
   * 带重试的任务执行
   */
  private async executeWithRetry<T>(task: QueueTask<T>): Promise<T> {
    let lastError: Error | null = null;
    let attempt = 0;
    const maxAttempts = this.retries + 1;

    while (attempt < maxAttempts) {
      try {
        // 带超时执行
        const result = await Promise.race([
          task.fn(),
          new Promise<never>((_, reject) =>
            setTimeout(() => reject(new Error(`Task timeout after ${this.timeout}ms`)), this.timeout)
          ),
        ]);
        return result;
      } catch (error) {
        lastError = error as Error;
        attempt++;

        if (attempt < maxAttempts) {
          // 指数退避 + 随机抖动
          const jitter = Math.random() * 500; // 添加0-500ms随机抖动
          const delay = this.retryDelay * Math.pow(2, attempt - 1) + jitter;
          await this.sleep(delay);
        }
      }
    }

    throw lastError;
  }

  /**
   * 暂停队列
   */
  pause(): void {
    this.paused = true;
  }

  /**
   * 恢复队列
   */
  resume(): void {
    this.paused = false;
    this.process();
  }

  /**
   * 清空队列
   */
  clear(): void {
    // 取消所有pending任务
    for (const task of this.queue) {
      if (task.status === 'pending') {
        (task as any)._reject?.(new Error('Queue cleared'));
      }
    }
    this.queue = [];
    this.taskLock.releaseAll();
  }

  /**
   * 获取队列状态（线程安全）
   */
  getStatus(): { pending: number; running: number; completed: number; total: number; isPaused: boolean; isProcessing: boolean } {
    return {
      pending: this.queue.filter(t => t.status === 'pending').length,
      running: this.running,
      completed: this.completed,
      total: this.queue.length + this.running + this.completed,
      isPaused: this.paused,
      isProcessing: this.processing,
    };
  }

  /**
   * 等待所有任务完成
   */
  async allSettled<T>(tasks: (() => Promise<T>)[], baseId?: string): Promise<PromiseSettledResult<T>[]> {
    const promises = tasks.map((fn, i) => this.add(fn, `${baseId || 'task'}_${i}`));
    return Promise.allSettled(promises);
  }

  /**
   * 等待队列清空
   */
  async waitForComplete(): Promise<void> {
    return new Promise((resolve) => {
      const check = () => {
        const status = this.getStatus();
        if (status.pending === 0 && status.running === 0) {
          resolve();
        } else {
          setTimeout(check, 100);
        }
      };
      check();
    });
  }

  /**
   * 延迟函数
   */
  private sleep(ms: number): Promise<void> {
    return new Promise(resolve => setTimeout(resolve, ms));
  }
}

// ==================== 速率限制器类（带令牌桶和突发容量）====================
export class RateLimiter {
  private tokensPerInterval: number;
  private interval: number;
  private burstSize: number;
  private tokens: number;
  private lastRefill: number;
  private readonly lock = new StateLock();

  constructor(options: RateLimiterOptions) {
    this.tokensPerInterval = options.tokensPerInterval;
    this.interval = options.interval;
    this.burstSize = options.burstSize || options.tokensPerInterval * 2;
    this.tokens = this.burstSize;
    this.lastRefill = Date.now();
  }

  /**
   * 获取令牌（带随机间隔抖动）
   */
  async acquire(additionalJitter: boolean = false): Promise<void> {
    const release = await this.lock.acquire('rate_limit');
    
    try {
      // 补充令牌
      this.refill();
      
      // 等待令牌
      if (this.tokens < 1) {
        const waitTime = Math.ceil((1 - this.tokens) * this.interval / this.tokensPerInterval);
        // 添加随机抖动（100-300ms）
        const jitter = additionalJitter ? Math.floor(Math.random() * 200 + 100) : 0;
        await this.sleep(waitTime + jitter);
        this.refill();
      }
      
      this.tokens = Math.max(0, this.tokens - 1);
    } finally {
      release();
    }
  }

  /**
   * 补充令牌
   */
  private refill(): void {
    const now = Date.now();
    const elapsed = now - this.lastRefill;
    const tokensToAdd = (elapsed / this.interval) * this.tokensPerInterval;
    this.tokens = Math.min(this.burstSize, this.tokens + tokensToAdd);
    this.lastRefill = now;
  }

  /**
   * 获取当前可用令牌数
   */
  getAvailableTokens(): number {
    this.refill();
    return Math.floor(this.tokens);
  }

  private sleep(ms: number): Promise<void> {
    return new Promise(resolve => setTimeout(resolve, ms));
  }
}

// ==================== 指数退避重试 ====================
export interface RetryOptions {
  maxRetries?: number;
  baseDelay?: number;
  maxDelay?: number;
  timeout?: number;  // 单次操作超时时间（毫秒）
  onRetry?: (attempt: number, error: Error) => void;
}

/**
 * 带指数退避的重试函数
 */
export async function retryWithBackoff<T>(
  fn: () => Promise<T>,
  options: RetryOptions = {}
): Promise<T> {
  const {
    maxRetries = 3,
    baseDelay = 1000,
    maxDelay = 10000,
    timeout = 30000, // 默认30秒超时
    onRetry,
  } = options;

  let lastError: Error | undefined;
  
  for (let attempt = 0; attempt <= maxRetries; attempt++) {
    try {
      // 带超时的执行
      const result = await Promise.race([
        fn(),
        new Promise<never>((_, reject) =>
          setTimeout(() => reject(new Error(`操作超时 (${timeout}ms)`)), timeout)
        ),
      ]);
      return result;
    } catch (error) {
      lastError = error as Error;
      
      if (attempt < maxRetries) {
        // 指数退避 + 随机抖动
        const exponentialDelay = Math.min(baseDelay * Math.pow(2, attempt), maxDelay);
        const jitter = Math.random() * exponentialDelay * 0.3; // 最多30%抖动
        const delay = exponentialDelay + jitter;
        
        console.warn(`[重试] 第 ${attempt + 1} 次重试，等待 ${Math.round(delay)}ms，原因: ${(error as Error).message}`);
        onRetry?.(attempt + 1, lastError);
        await new Promise(resolve => setTimeout(resolve, delay));
      }
    }
  }
  
  throw lastError;
}

// ==================== 工厂函数 ====================

/**
 * 创建并发队列
 */
export function createConcurrentQueue(concurrency: number, options?: Partial<ConcurrentQueueOptions>): ConcurrentQueue {
  return new ConcurrentQueue({
    concurrency,
    timeout: options?.timeout ?? 30000,
    retries: options?.retries ?? 2,
    retryDelay: options?.retryDelay ?? 1000,
    onProgress: options?.onProgress,
    onTaskComplete: options?.onTaskComplete,
    onTaskError: options?.onTaskError,
    enableLock: options?.enableLock ?? true,
  });
}

/**
 * 创建速率限制器
 */
export function createRateLimiter(
  tokensPerInterval: number,
  interval: number = 1000,
  burstSize?: number
): RateLimiter {
  return new RateLimiter({
    tokensPerInterval,
    interval,
    burstSize,
  });
}

/**
 * 创建带随机抖动的延迟
 */
export function randomDelay(minMs: number, maxMs: number): Promise<void> {
  const delay = Math.floor(Math.random() * (maxMs - minMs + 1)) + minMs;
  return new Promise(resolve => setTimeout(resolve, delay));
}

/**
 * 导出全局锁（供其他模块使用）
 */
export { globalLock };

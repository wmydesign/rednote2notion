/**
 * 小红书数据解析器
 * 提供健壮的数据解析能力，支持字段变更容错
 */

import type { RednoteNote, NoteComment } from './types';

// ==================== 解析器选项 ====================
export interface RednoteParserOptions {
  strictMode?: boolean;        // 严格模式：遇到未知字段是否抛出错误
  defaultValue?: any;          // 默认值
  onParseError?: (field: string, error: Error) => void;  // 解析错误回调
}

// ==================== 解析结果类型 ====================
export interface ParseResult<T> {
  success: boolean;
  data?: T;
  errors: ParseError[];
}

export interface ParseError {
  field: string;
  expected: string;
  actual: any;
  message: string;
}

// ==================== 原始API数据结构（多版本兼容） ====================
export interface RawNoteData {
  // 笔记ID
  id?: string;
  note_id?: string;
  _id?: string;
  
  // 标题
  title?: string;
  display_title?: string;
  
  // 描述/正文
  desc?: string;
  content?: string;
  text?: string;
  
  // 封面图
  cover?: {
    url_default?: string;
    url?: string;
    width?: number;
    height?: number;
  };
  image_list?: Array<{
    url: string;
    width?: number;
    height?: number;
  }>;
  images?: Array<{
    url: string;
    width?: number;
    height?: number;
  }>;
  
  // 作者信息
  user?: {
    user_id?: string;
    nickname?: string;
    avatar?: string;
  };
  author?: {
    user_id?: string;
    nickname?: string;
    avatar?: string;
  };
  
  // 时间
  time?: number | string;
  publish_time?: number | string;
  time_create?: number | string;
  
  // 互动数据
  like_count?: number;
  liked_count?: number;
  collect_count?: number;
  collected_count?: number;
  comment_count?: number;
  share_count?: number;
  
  // 标签
  tag_list?: Array<{ name: string; id?: string }>;
  tags?: Array<{ name: string; id?: string }>;
  
  // 笔记类型
  type?: string;
  note_type?: string;
  display_type?: string;
  
  // 专辑
  album_id?: string;
  album_title?: string;
  collection_id?: string;
  collection_title?: string;
}

// ==================== 健壮解析器类 ====================
export class RednoteParser {
  private options: Required<RednoteParserOptions>;
  private parseErrors: ParseError[] = [];

  constructor(options: RednoteParserOptions = {}) {
    this.options = {
      strictMode: false,
      defaultValue: null,
      onParseError: options.onParseError || (() => {}),
    };
  }

  /**
   * 解析笔记数据（容错处理）
   */
  parseNote(raw: RawNoteData): ParseResult<RednoteNote> {
    this.parseErrors = [];
    const errors: ParseError[] = [];

    try {
      const note: RednoteNote = {
        // 解析ID
        id: this.parseString(raw.id || raw.note_id || raw._id, 'id', errors) || 'unknown',

        // 解析标题
        title: this.parseString(raw.title || raw.display_title, 'title', errors) || '无标题',

        // 解析正文
        desc: this.parseString(raw.desc || raw.content || raw.text, 'desc', errors) || '',

        // 解析封面图
        coverUrl: this.parseCoverUrl(raw, errors),

        // 解析所有图片
        allImages: this.parseAllImages(raw, errors),

        // 解析作者信息
        authorName: this.parseAuthorName(raw, errors),
        authorId: this.parseAuthorId(raw, errors),

        // 解析时间
        publishTime: this.parseTime(raw.time || raw.publish_time || raw.time_create, errors),

        // 解析互动数据
        likeCount: this.parseNumber(raw.like_count || raw.liked_count, 'likeCount', errors) || 0,
        collectCount: this.parseNumber(raw.collect_count || raw.collected_count, 'collectCount', errors) || 0,
        commentCount: this.parseNumber(raw.comment_count, 'commentCount', errors) || 0,
        shareCount: this.parseNumber(raw.share_count, 'shareCount', errors) || 0,

        // 解析原文链接
        noteUrl: this.parseNoteUrl(raw, errors),

        // 解析笔记类型
        noteType: this.parseNoteType(raw, errors),

        // 解析标签
        tags: this.parseTags(raw, errors),

        // 解析专辑
        albumId: raw.album_id || raw.collection_id,
        albumName: raw.album_title || raw.collection_title,
      };

      return {
        success: errors.length === 0,
        data: note,
        errors,
      };
    } catch (error) {
      return {
        success: false,
        data: undefined,
        errors: [...errors, {
          field: 'root',
          expected: 'RednoteNote',
          actual: typeof raw,
          message: `解析失败: ${(error as Error).message}`,
        }],
      };
    }
  }

  /**
   * 批量解析笔记
   */
  parseNotes(rawList: RawNoteData[]): { parsed: RednoteNote[]; failed: RawNoteData[] } {
    const parsed: RednoteNote[] = [];
    const failed: RawNoteData[] = [];

    for (const raw of rawList) {
      const result = this.parseNote(raw);
      if (result.success && result.data) {
        parsed.push(result.data);
      } else {
        failed.push(raw);
        // 记录错误
        result.errors.forEach(err => {
          this.options.onParseError(err.field, new Error(err.message));
        });
      }
    }

    return { parsed, failed };
  }

  /**
   * 解析笔记列表（支持多种API响应格式）
   */
  parseNoteList(response: any): ParseResult<RawNoteData[]> {
    this.parseErrors = [];
    const errors: ParseError[] = [];

    if (!response) {
      return {
        success: false,
        errors: [{ field: 'response', expected: 'object', actual: response, message: '响应为空' }],
      };
    }

    // 尝试多种数据路径
    let notes: RawNoteData[] = [];

    // 路径1: data.notes
    if (response.data?.notes) {
      notes = response.data.notes;
    }
    // 路径2: data.items (收藏夹常用)
    else if (response.data?.items) {
      notes = response.data.items;
    }
    // 路径3: data
    else if (response.data) {
      notes = Array.isArray(response.data) ? response.data : [response.data];
    }
    // 路径4: items (某些接口)
    else if (response.items) {
      notes = response.items;
    }

    // 获取分页信息
    const cursor = response.data?.cursor || response.cursor || '';
    const hasMore = response.data?.has_more || response.has_more || false;

    return {
      success: notes.length > 0,
      data: notes,
      errors: notes.length === 0 ? [{ field: 'notes', expected: 'array', actual: response, message: '未找到笔记数据' }] : [],
    };
  }

  /**
   * 解析评论数据
   */
  parseComment(raw: any): ParseResult<NoteComment> {
    const errors: ParseError[] = [];

    const comment: NoteComment = {
      commentId: this.parseString(raw.comment_id || raw.id, 'commentId', errors) || 'unknown',
      content: this.parseString(raw.content || raw.text, 'content', errors) || '',
      authorName: this.parseString(raw.user_info?.nickname || raw.author?.nickname, 'authorName', errors) || '匿名用户',
      isAuthor: raw.is_author === true || raw.is_self === true,
      likeCount: this.parseNumber(raw.like_count || raw.liked_count, 'likeCount', errors) || 0,
      publishTime: this.parseTime(raw.create_time || raw.time, errors) || Date.now(),
    };

    return {
      success: errors.length === 0,
      data: comment,
      errors,
    };
  }

  // ==================== 私有解析方法 ====================

  /**
   * 解析字符串
   */
  private parseString(value: any, fieldName: string, errors: ParseError[]): string | undefined {
    if (value === null || value === undefined) {
      this.recordError(fieldName, 'string', value, errors);
      return undefined;
    }
    if (typeof value === 'string') {
      return value.trim();
    }
    if (typeof value === 'number') {
      return String(value);
    }
    this.recordError(fieldName, 'string', value, errors);
    return undefined;
  }

  /**
   * 解析数字
   */
  private parseNumber(value: any, fieldName: string, errors: ParseError[]): number | undefined {
    if (value === null || value === undefined) {
      return undefined; // 数字类型不记录错误
    }
    const num = Number(value);
    if (isNaN(num)) {
      this.recordError(fieldName, 'number', value, errors);
      return undefined;
    }
    return num;
  }

  /**
   * 解析时间戳
   */
  private parseTime(value: any, errors: ParseError[]): number | undefined {
    if (!value) return undefined;

    // 已经是数字（毫秒或秒）
    if (typeof value === 'number') {
      // 如果小于10位，可能是秒级时间戳
      if (value < 10000000000) {
        return value * 1000;
      }
      return value;
    }

    // 字符串格式
    if (typeof value === 'string') {
      const date = new Date(value);
      if (!isNaN(date.getTime())) {
        return date.getTime();
      }
    }

    this.recordError('time', 'timestamp', value, errors);
    return undefined;
  }

  /**
   * 解析封面图URL
   */
  private parseCoverUrl(raw: RawNoteData, errors: ParseError[]): string {
    // 尝试多种路径
    if (raw.cover?.url) return raw.cover.url;
    if (raw.cover?.url_default) return raw.cover.url_default;
    if (raw.image_list?.[0]?.url) return raw.image_list[0].url;
    if (raw.images?.[0]?.url) return raw.images[0].url;
    
    this.recordError('coverUrl', 'url', raw.cover, errors);
    return '';
  }

  /**
   * 解析所有图片
   */
  private parseAllImages(raw: RawNoteData, errors: ParseError[]): string[] {
    const images: string[] = [];

    // image_list
    if (raw.image_list?.length) {
      images.push(...raw.image_list.map(img => img.url).filter(Boolean));
    }
    // images
    if (raw.images?.length) {
      images.push(...raw.images.map(img => img.url).filter(Boolean));
    }

    return images;
  }

  /**
   * 解析作者昵称
   */
  private parseAuthorName(raw: RawNoteData, errors: ParseError[]): string {
    const name = raw.user?.nickname || raw.author?.nickname;
    if (!name) {
      this.recordError('authorName', 'string', raw.user, errors);
      return '未知作者';
    }
    return name;
  }

  /**
   * 解析作者ID
   */
  private parseAuthorId(raw: RawNoteData, errors: ParseError[]): string {
    const id = raw.user?.user_id || raw.author?.user_id;
    if (!id) {
      this.recordError('authorId', 'string', raw.user, errors);
      return 'unknown';
    }
    return id;
  }

  /**
   * 解析笔记类型
   */
  private parseNoteType(raw: RawNoteData, errors: ParseError[]): 'normal' | 'video' | 'image' {
    const type = raw.type || raw.note_type || raw.display_type;
    
    if (type === 'video' || type === 'video_normal') return 'video';
    if (type === 'normal' || type === 'image') return 'image';
    
    return 'normal';
  }

  /**
   * 解析标签
   */
  private parseTags(raw: RawNoteData, errors: ParseError[]): string[] {
    const tags: string[] = [];
    
    const tagList = raw.tag_list || raw.tags;
    if (Array.isArray(tagList)) {
      tags.push(...tagList.map(tag => tag.name).filter(Boolean));
    }
    
    return tags;
  }

  /**
   * 解析笔记URL
   */
  private parseNoteUrl(raw: RawNoteData, errors: ParseError[]): string {
    const noteId = raw.id || raw.note_id || raw._id;
    if (noteId) {
      return `https://www.xiaohongshu.com/discovery/item/${noteId}`;
    }
    this.recordError('noteUrl', 'url', raw, errors);
    return '';
  }

  /**
   * 记录解析错误
   */
  private recordError(field: string, expected: string, actual: any, errors: ParseError[]): void {
    const error: ParseError = {
      field,
      expected,
      actual: typeof actual === 'object' ? '[object]' : actual,
      message: `字段 "${field}" 解析失败，期望 ${expected}，实际得到 ${typeof actual}`,
    };
    errors.push(error);
    this.parseErrors.push(error);
    this.options.onParseError(field, new Error(error.message));
  }
}

// ==================== 快捷函数 ====================

// 默认解析器实例
let defaultParser: RednoteParser | null = null;

/**
 * 获取默认解析器
 */
export function getDefaultParser(): RednoteParser {
  if (!defaultParser) {
    defaultParser = new RednoteParser({
      strictMode: false,
    });
  }
  return defaultParser;
}

/**
 * 解析单条笔记（快捷函数）
 */
export function parseNote(raw: RawNoteData): RednoteNote {
  const parser = getDefaultParser();
  const result = parser.parseNote(raw);
  if (!result.success || !result.data) {
    console.warn('笔记解析失败:', result.errors);
  }
  return result.data || {
    id: raw.note_id || raw.id || 'unknown',
    title: '解析失败',
    desc: '',
    coverUrl: '',
    allImages: [],
    authorName: '未知',
    authorId: 'unknown',
    publishTime: Date.now(),
    likeCount: 0,
    collectCount: 0,
    commentCount: 0,
    shareCount: 0,
    noteUrl: '',
    noteType: 'normal',
    tags: [],
  };
}

/**
 * 解析笔记列表（快捷函数）
 */
export function parseNoteList(response: any): { notes: RednoteNote[]; cursor: string; hasMore: boolean } {
  const parser = getDefaultParser();
  const result = parser.parseNoteList(response);
  
  if (!result.success || !result.data) {
    console.warn('笔记列表解析失败:', result.errors);
    return { notes: [], cursor: '', hasMore: false };
  }

  const parsed = parseNotes(result.data);
  const cursor = response.data?.cursor || response.cursor || '';
  const hasMore = response.data?.has_more || response.has_more || false;

  return { notes: parsed, cursor, hasMore };
}

/**
 * 批量解析笔记（快捷函数）
 */
export function parseNotes(rawList: RawNoteData[]): RednoteNote[] {
  return rawList.map(raw => parseNote(raw));
}

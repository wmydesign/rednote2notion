/**
 * 授权码生成工具 - 卖家专用
 * 
 * 使用方法：
 * 1. 安装依赖：npm install uuid crypto-js
 * 2. 运行脚本：node generate-license.js
 * 
 * 或者在 Node.js 环境中直接引入使用
 */

const crypto = require('crypto');
const { v4: uuidv4 } = require('uuid');

// ==================== 加密配置（与插件保持一致）====================
const ENCRYPTION_KEY = 'Rednote2Notion_License_2024_Secret_Key_32Byte!';
const IV_LENGTH = 16;

/**
 * 加密函数
 */
function encrypt(text) {
  const iv = crypto.randomBytes(IV_LENGTH);
  const cipher = crypto.createCipheriv(
    'aes-256-cbc',
    Buffer.from(ENCRYPTION_KEY),
    iv
  );
  let encrypted = cipher.update(text);
  encrypted = Buffer.concat([encrypted, cipher.final()]);
  return iv.toString('hex') + ':' + encrypted.toString('hex');
}

/**
 * 解密函数（用于验证）
 */
function decrypt(text) {
  const textParts = text.split(':');
  const iv = Buffer.from(textParts.shift(), 'hex');
  const encryptedText = Buffer.from(textParts.join(':'), 'hex');
  const decipher = crypto.createDecipheriv(
    'aes-256-cbc',
    Buffer.from(ENCRYPTION_KEY),
    iv
  );
  let decrypted = decipher.update(encryptedText);
  decrypted = Buffer.concat([decrypted, decipher.final()]);
  return decrypted.toString();
}

// ==================== 授权码类型 ====================
const LicenseType = {
  FREE: 'free',
  TRIAL: 'trial',
  PERMANENT: 'permanent'
};

// ==================== 常量配置 ====================
const TRIAL_DEFAULT_DAYS = 7;
const PERMANENT_VALID_YEARS = 99;
const UNACTIVATED_DEVICE_FLAG = 'UNACTIVATED_CARD';

// ==================== 核心生成函数 ====================

/**
 * 生成授权码
 * @param {Object} config 配置参数
 * @param {string} config.type - 授权类型：'trial' | 'permanent'
 * @param {number} config.validDays - 体验版有效天数（默认7天）
 * @param {number} config.count - 生成数量（默认1条）
 * @returns {Array} 授权码数组
 */
function generateLicenseCode(config) {
  const {
    type = 'permanent',
    validDays = 7,
    count = 1
  } = config;

  const codes = [];

  for (let i = 0; i < count; i++) {
    const licenseId = uuidv4().replace(/-/g, '');
    const generateTime = Date.now();
    let expireTime = 0;
    let maxSyncCount = Infinity; // 默认无限制

    // 计算过期时间和同步上限
    if (type === LicenseType.FREE) {
      // 免费版：99年有效，5篇同步上限
      expireTime = generateTime + 99 * 365 * 24 * 60 * 60 * 1000;
      maxSyncCount = 5;
    } else if (type === LicenseType.TRIAL) {
      // 体验版：预生成卡密有1年激活窗口期
      expireTime = generateTime + 365 * 24 * 60 * 60 * 1000;
    } else if (type === LicenseType.PERMANENT) {
      // 永久版：99年
      expireTime = generateTime + PERMANENT_VALID_YEARS * 365 * 24 * 60 * 60 * 1000;
    } else {
      expireTime = generateTime + 99 * 365 * 24 * 60 * 60 * 1000;
    }

    // 构建授权码数据
    const rawLicense = {
      licenseId,
      licenseType: type,
      generateTime,
      expireTime,
      deviceFingerprint: UNACTIVATED_DEVICE_FLAG, // 预生成，用户激活时绑定
      validDays: type === LicenseType.TRIAL ? validDays : 0,
      maxSyncCount: maxSyncCount,
      isPreGenerated: true
    };

    // 加密生成授权码
    const licenseStr = JSON.stringify(rawLicense);
    const licenseCode = encrypt(licenseStr);
    codes.push(licenseCode);
  }

  return codes;
}

/**
 * 解析授权码（售后验证用）
 * @param {string} licenseCode 授权码
 * @returns {Object} 解析结果
 */
function parseLicenseCode(licenseCode) {
  try {
    const decryptedStr = decrypt(licenseCode);
    const data = JSON.parse(decryptedStr);
    
    const isActivated = data.deviceFingerprint !== UNACTIVATED_DEVICE_FLAG;
    const now = Date.now();
    let isValid = true;
    let status = '';

    if (data.expireTime < now) {
      isValid = false;
      status = '已过期';
    } else if (isActivated) {
      status = '已激活';
    } else {
      status = '未激活';
    }

    const typeNames = {
      'free': '免费版',
      'trial': '体验版',
      'permanent': '永久版'
    };

    return {
      licenseId: data.licenseId,
      type: data.licenseType,
      typeName: typeNames[data.licenseType] || data.licenseType,
      generateTime: new Date(data.generateTime).toLocaleString('zh-CN'),
      expireTime: new Date(data.expireTime).toLocaleString('zh-CN'),
      validDays: data.validDays || '无限制',
      maxSyncCount: data.maxSyncCount || '无限制',
      isActivated,
      isValid,
      status
    };
  } catch (error) {
    return { error: '授权码无效' };
  }
}

// ==================== 命令行工具 ====================

function printUsage() {
  console.log(`
╔═══════════════════════════════════════════════════════════════╗
║           🔑 Rednote2Notion 授权码生成工具 v1.1              ║
╠═══════════════════════════════════════════════════════════════╣
║  使用方法：                                                   ║
║                                                               ║
║  1. 生成免费版授权码（5篇上限）：                             ║
║     node generate-license.js free                             ║
║                                                               ║
║  2. 生成永久版授权码（单条）：                                ║
║     node generate-license.js permanent                        ║
║                                                               ║
║  3. 生成永久版授权码（批量）：                                ║
║     node generate-license.js permanent 10                     ║
║                                                               ║
║  4. 生成体验版授权码（7天）：                                 ║
║     node generate-license.js trial                            ║
║                                                               ║
║  5. 生成体验版授权码（自定义天数）：                          ║
║     node generate-license.js trial 30                         ║
║                                                               ║
║  6. 解析授权码：                                              ║
║     node generate-license.js parse "授权码"                   ║
║                                                               ║
╚═══════════════════════════════════════════════════════════════╝
  `);
}

function main() {
  const args = process.argv.slice(2);
  
  if (args.length === 0) {
    printUsage();
    return;
  }

  const command = args[0];

  if (command === 'free') {
    const count = parseInt(args[1]) || 1;
    console.log(`\n🚀 正在生成 ${count} 条免费版授权码...\n`);
    
    const codes = generateLicenseCode({ type: 'free', count });
    
    console.log('┌─────────────────────────────────────────────────────────┐');
    console.log('│                🆓 免费版授权码（5篇上限）                │');
    console.log('├─────────────────────────────────────────────────────────┤');
    codes.forEach((code, index) => {
      console.log(`│ ${index + 1}. ${code}`);
    });
    console.log('└─────────────────────────────────────────────────────────┘');
    console.log(`\n✅ 生成完成！共 ${count} 条授权码`);
    console.log(`⚠️  提示：免费版仅能同步5篇笔记\n`);

  } else if (command === 'permanent') {
    const count = parseInt(args[1]) || 1;
    console.log(`\n🚀 正在生成 ${count} 条永久版授权码...\n`);
    
    const codes = generateLicenseCode({ type: 'permanent', count });
    
    console.log('┌─────────────────────────────────────────────────────────┐');
    console.log('│                    💎 永久版授权码                       │');
    console.log('├─────────────────────────────────────────────────────────┤');
    codes.forEach((code, index) => {
      console.log(`│ ${index + 1}. ${code}`);
    });
    console.log('└─────────────────────────────────────────────────────────┘');
    console.log(`\n✅ 生成完成！共 ${count} 条授权码\n`);

  } else if (command === 'trial') {
    const validDays = parseInt(args[1]) || 7;
    const count = parseInt(args[2]) || 1;
    console.log(`\n🚀 正在生成 ${count} 条体验版授权码（${validDays}天有效期）...\n`);
    
    const codes = generateLicenseCode({ type: 'trial', validDays, count });
    
    console.log('┌─────────────────────────────────────────────────────────┐');
    console.log(`│                ⏰ 体验版授权码（${validDays}天）            `);
    console.log('├─────────────────────────────────────────────────────────┤');
    codes.forEach((code, index) => {
      console.log(`│ ${index + 1}. ${code}`);
    });
    console.log('└─────────────────────────────────────────────────────────┘');
    console.log(`\n✅ 生成完成！共 ${count} 条授权码\n`);
    console.log(`⚠️  提示：体验版在用户激活后开始计算${validDays}天有效期\n`);

  } else if (command === 'parse') {
    const licenseCode = args[1];
    if (!licenseCode) {
      console.log('❌ 请提供要解析的授权码');
      return;
    }
    
    console.log('\n🔍 正在解析授权码...\n');
    const result = parseLicenseCode(licenseCode);
    
    if (result.error) {
      console.log(`❌ ${result.error}\n`);
    } else {
      console.log('┌─────────────────────────────────────────────────────────┐');
      console.log('│                    📋 授权码信息                         │');
      console.log('├─────────────────────────────────────────────────────────┤');
      console.log(`│ 授权ID：${result.licenseId}`);
      console.log(`│ 类型：${result.typeName}`);
      console.log(`│ 同步上限：${result.maxSyncCount}`);
      console.log(`│ 生成时间：${result.generateTime}`);
      console.log(`│ 过期时间：${result.expireTime}`);
      if (result.type === 'trial') {
        console.log(`│ 有效天数：${result.validDays}天（激活后开始计时）`);
      }
      console.log(`│ 激活状态：${result.status}`);
      console.log(`│ 当前状态：${result.isValid ? '✅ 有效' : '❌ 无效'}`);
      console.log('└─────────────────────────────────────────────────────────┘\n');
    }

  } else {
    printUsage();
  }
}

// 导出供其他模块使用
module.exports = {
  generateLicenseCode,
  parseLicenseCode,
  LicenseType
};

// 命令行运行
if (require.main === module) {
  main();
}

import React, { useState, useEffect } from 'react';
import { MessageType, platformConfig } from './lib/types';
import './style.css';

// 骨架屏组件
const SkeletonLoader = () => (
  <div className="skeleton-container">
    {/* 头部骨架 */}
    <div className="skeleton-card">
      <div style={{ display: 'flex', alignItems: 'center' }}>
        <div className="skeleton skeleton-avatar" />
        <div className="skeleton-info">
          <div className="skeleton skeleton-line" style={{ width: '120px' }} />
          <div className="skeleton skeleton-line" style={{ width: '80px', height: '10px' }} />
        </div>
      </div>
    </div>
    
    {/* Tab骨架 */}
    <div className="skeleton-card">
      <div className="skeleton skeleton-title" />
      {/* 同步卡片骨架 */}
      {[1, 2, 3].map((i) => (
        <div key={i} className="skeleton-row" style={{ borderBottom: i < 3 ? '1px solid #F0F0F0' : 'none' }}>
          <div className="skeleton skeleton-circle" />
          <div className="skeleton-info" style={{ marginLeft: '12px' }}>
            <div className="skeleton skeleton-line" style={{ width: `${100 + i * 20}px` }} />
            <div className="skeleton skeleton-line" style={{ width: '60px', height: '10px' }} />
          </div>
        </div>
      ))}
    </div>
    
    {/* 操作按钮骨架 */}
    <div className="skeleton-card">
      <div style={{ display: 'flex', gap: '10px' }}>
        <div className="skeleton" style={{ flex: 1, height: '40px', borderRadius: '12px' }} />
        <div className="skeleton" style={{ flex: 1, height: '40px', borderRadius: '12px' }} />
      </div>
    </div>
  </div>
);

// 圆环进度组件
const CircularProgress = ({ progress, size = 64, strokeWidth = 5 }: { 
  progress: number; 
  size?: number;
  strokeWidth?: number;
}) => {
  const radius = (size - strokeWidth) / 2;
  const circumference = radius * 2 * Math.PI;
  const offset = circumference - (progress / 100) * circumference;
  
  return (
    <div className="progress-ring-container">
      <div className="progress-ring" style={{ width: size, height: size }}>
        <svg viewBox={`0 0 ${size} ${size}`}>
          <defs>
            <linearGradient id="progressGradient" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#FF2442" />
              <stop offset="100%" stopColor="#FF6B81" />
            </linearGradient>
          </defs>
          <circle
            className="progress-ring-bg"
            cx={size / 2}
            cy={size / 2}
            r={radius}
          />
          <circle
            className="progress-ring-value"
            cx={size / 2}
            cy={size / 2}
            r={radius}
            style={{ 
              strokeDasharray: circumference,
              strokeDashoffset: offset
            }}
          />
        </svg>
        <span className="progress-ring-text">{Math.round(progress)}%</span>
      </div>
    </div>
  );
};

// 空状态组件
const EmptyState = ({ 
  icon = '📭', 
  title = '暂无数据', 
  description = '这里什么都没有，快去添加内容吧',
  actionText = '',
  onAction = () => {}
}: {
  icon?: string;
  title?: string;
  description?: string;
  actionText?: string;
  onAction?: () => void;
}) => (
  <div className="empty-state animate-fade-in">
    <div className="empty-state-icon">{icon}</div>
    <div className="empty-state-title">{title}</div>
    <div className="empty-state-desc">{description}</div>
    {actionText && (
      <button className="empty-state-action" onClick={onAction}>
        {actionText}
      </button>
    )}
  </div>
);

// Toast组件
const Toast = ({ message, type = 'default', show }: { 
  message: string; 
  type?: 'default' | 'success' | 'error' | 'warning';
  show: boolean;
}) => {
  if (!message) return null;
  
  const icons = {
    default: '💡',
    success: '✅',
    error: '❌',
    warning: '⚠️'
  };
  
  return (
    <div className={`xhs-toast ${show ? 'show' : ''} ${type !== 'default' ? `xhs-toast-${type}` : ''}`}>
      <span className="xhs-toast-icon">{icons[type]}</span>
      <span>{message}</span>
    </div>
  );
};

const SidePanel = () => {
  // 状态管理
  const [userInfo, setUserInfo] = useState<{ userId: string; nickname: string } | null>(null);
  const [notionConfig, setNotionConfig] = useState({
    apiKey: '',
    databaseId: ''
  });
  const [openaiConfig, setOpenaiConfig] = useState({
    apiKey: '',
    enableAIClassify: false
  });
  const [syncStatus, setSyncStatus] = useState<Record<string, boolean>>({});
  const [lastSyncTime, setLastSyncTime] = useState<Record<string, number>>({});
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState<'sync' | 'config'>('sync');
  const [syncProgress, setSyncProgress] = useState(0);
  const [isDarkMode, setIsDarkMode] = useState(false);
  const [toast, setToast] = useState({ show: false, message: '', type: 'default' as 'default' | 'success' | 'error' | 'warning' });

  // 初始化加载配置
  useEffect(() => {
    loadConfig();
    initDarkMode();
  }, []);

  // 深色模式初始化
  const initDarkMode = () => {
    // 检查本地存储
    const stored = localStorage.getItem('darkMode');
    if (stored !== null) {
      setIsDarkMode(stored === 'true');
      document.body.classList.toggle('dark', stored === 'true');
    } else {
      // 检查系统偏好
      const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
      setIsDarkMode(prefersDark);
      document.body.classList.toggle('dark', prefersDark);
    }
  };

  // 切换深色模式
  const toggleDarkMode = () => {
    const newMode = !isDarkMode;
    setIsDarkMode(newMode);
    localStorage.setItem('darkMode', String(newMode));
    document.body.classList.toggle('dark', newMode);
  };

  // 显示提示
  const showToast = (msg: string, type: 'default' | 'success' | 'error' | 'warning' = 'default') => {
    setToast({ show: true, message: msg, type });
    setTimeout(() => setToast({ show: false, message: '', type: 'default' }), 2500);
  };

  // 加载本地存储配置
  const loadConfig = async () => {
    setLoading(true);
    
    // 模拟加载延迟以展示骨架屏
    await new Promise(resolve => setTimeout(resolve, 800));
    
    const storageData = await chrome.storage.local.get([
      'notion_api_key',
      'notion_database_id',
      'openai_api_key',
      'openai_enable_classify',
      'sync-rednote-post-to-notion',
      'sync-rednote-bookmark-to-notion',
      'sync-rednote-like-to-notion',
      'sync-rednote-post-to-notion_last_time',
      'sync-rednote-bookmark-to-notion_last_time',
      'sync-rednote-like-to-notion_last_time',
      'current_user',
      'sync_progress'
    ]);

    setNotionConfig({
      apiKey: storageData.notion_api_key || '',
      databaseId: storageData.notion_database_id || ''
    });

    setOpenaiConfig({
      apiKey: storageData.openai_api_key || '',
      enableAIClassify: storageData.openai_enable_classify || false
    });

    setSyncStatus({
      post: storageData['sync-rednote-post-to-notion'] || false,
      bookmark: storageData['sync-rednote-bookmark-to-notion'] || false,
      like: storageData['sync-rednote-like-to-notion'] || false
    });

    setLastSyncTime({
      post: storageData['sync-rednote-post-to-notion_last_time'] || 0,
      bookmark: storageData['sync-rednote-bookmark-to-notion_last_time'] || 0,
      like: storageData['sync-rednote-like-to-notion_last_time'] || 0
    });

    setUserInfo(storageData.current_user || null);
    setSyncProgress(storageData.sync_progress || 0);
    setLoading(false);
  };

  // 保存配置
  const saveConfig = async () => {
    setLoading(true);
    await chrome.storage.local.set({
      'notion_api_key': notionConfig.apiKey,
      'notion_database_id': notionConfig.databaseId,
      'openai_api_key': openaiConfig.apiKey,
      'openai_enable_classify': openaiConfig.enableAIClassify
    });
    setLoading(false);
    showToast('配置保存成功', 'success');
  };

  // 切换同步状态
  const toggleSync = async (platform: 'rednotePost' | 'rednoteBookmark' | 'rednoteLike') => {
    if (!notionConfig.apiKey || !notionConfig.databaseId) {
      showToast('请先配置Notion', 'warning');
      setActiveTab('config');
      return;
    }

    const statusKey = platform === 'rednotePost' ? 'post' : platform === 'rednoteBookmark' ? 'bookmark' : 'like';
    const newStatus = !syncStatus[statusKey];
    
    if (newStatus) {
      // 开始同步动画
      let progress = 0;
      const progressInterval = setInterval(() => {
        progress += Math.random() * 15;
        if (progress > 90) progress = 90;
        setSyncProgress(progress);
      }, 500);

      await chrome.runtime.sendMessage({
        name: MessageType.SYNC_TO_NOTION,
        data: {
          platform,
          notionApiKey: notionConfig.apiKey,
          notionDatabaseId: notionConfig.databaseId,
          openaiApiKey: openaiConfig.apiKey,
          enableAIClassify: openaiConfig.enableAIClassify
        }
      });

      clearInterval(progressInterval);
      setSyncProgress(100);
      showToast('同步已开始', 'success');
    } else {
      await chrome.runtime.sendMessage({
        name: MessageType.STOP_ALL_SYNC
      });
      setSyncProgress(0);
      showToast('已停止同步', 'default');
    }

    await loadConfig();
  };

  // 停止所有同步
  const stopAllSync = async () => {
    await chrome.runtime.sendMessage({
      name: MessageType.STOP_ALL_SYNC
    });
    setSyncProgress(0);
    await loadConfig();
    showToast('已停止所有同步', 'default');
  };

  // 清除缓存
  const clearCache = async () => {
    if (confirm('确定要清除所有同步缓存吗？')) {
      await chrome.runtime.sendMessage({
        name: MessageType.CLEAR_CACHE
      });
      await loadConfig();
      showToast('缓存清除成功', 'success');
    }
  };

  // 格式化时间
  const formatTime = (timestamp: number) => {
    if (!timestamp) return '从未同步';
    const date = new Date(timestamp);
    const now = new Date();
    const diff = now.getTime() - date.getTime();
    
    if (diff < 60000) return '刚刚';
    if (diff < 3600000) return `${Math.floor(diff / 60000)}分钟前`;
    if (diff < 86400000) return `${Math.floor(diff / 3600000)}小时前`;
    return date.toLocaleDateString();
  };

  // 同步类型配置
  const syncTypes = [
    {
      key: 'post' as const,
      platform: 'rednotePost' as const,
      title: '个人帖子',
      desc: '同步发布过的笔记',
      icon: '📝',
      iconClass: 'post'
    },
    {
      key: 'bookmark' as const,
      platform: 'rednoteBookmark' as const,
      title: '收藏内容',
      desc: '同步收藏的笔记',
      icon: '⭐',
      iconClass: 'bookmark'
    },
    {
      key: 'like' as const,
      platform: 'rednoteLike' as const,
      title: '点赞内容',
      desc: '同步点赞的笔记',
      icon: '❤️',
      iconClass: 'like'
    }
  ];

  // 显示骨架屏
  if (loading) {
    return (
      <div className="w-full min-h-screen" style={{ background: 'var(--bg-light)' }}>
        <div className="xhs-header">
          <h1>Rednote2Notion</h1>
          <p>小红书内容同步 · AI智能分类</p>
        </div>
        <SkeletonLoader />
      </div>
    );
  }

  return (
    <div className="w-full min-h-screen" style={{ background: 'var(--bg-light)' }}>
      {/* 小红书风格头部 */}
      <div className="xhs-header micro-glow">
        <h1>Rednote2Notion</h1>
        <p>小红书内容同步 · AI智能分类</p>
      </div>

      {/* 深色模式切换 */}
      <div className="p-4">
        <div className="dark-mode-toggle glass-card">
          <div className="dark-mode-toggle-label">
            <span className="dark-mode-toggle-icon">{isDarkMode ? '🌙' : '☀️'}</span>
            <span>{isDarkMode ? '深色模式' : '浅色模式'}</span>
          </div>
          <div 
            className={`dark-mode-switch ${isDarkMode ? 'active' : ''}`}
            onClick={toggleDarkMode}
          />
        </div>
      </div>

      {/* 用户信息卡片 */}
      {userInfo ? (
        <div className="px-4 pb-2">
          <div className="user-card glass-card">
            <div className="user-avatar">
              {userInfo.nickname?.charAt(0) || 'U'}
            </div>
            <div className="user-info">
              <div className="user-name">{userInfo.nickname}</div>
              <div className="user-status">
                <span className="xhs-badge xhs-badge-success">已登录</span>
              </div>
            </div>
          </div>
        </div>
      ) : (
        <div className="px-4 pb-2">
          <EmptyState
            icon="👤"
            title="未登录"
            description="请先在小红书登录账号"
            actionText="去登录"
            onAction={() => showToast('请在小红书网页版登录', 'info')}
          />
        </div>
      )}

      {/* 同步进度展示 */}
      {syncProgress > 0 && syncProgress < 100 && (
        <div className="px-4 pb-2 animate-fade-in">
          <div className="xhs-card glass-card" style={{ padding: '12px 16px' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '16px' }}>
              <CircularProgress progress={syncProgress} size={56} strokeWidth={4} />
              <div style={{ flex: 1 }}>
                <div style={{ fontSize: '13px', fontWeight: 500, color: 'var(--text-primary)' }}>
                  正在同步中...
                </div>
                <div className="sync-progress-detail">
                  <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                    <span>已完成</span>
                    <span style={{ color: 'var(--primary-color)' }}>{Math.round(syncProgress)}%</span>
                  </div>
                  <div className="sync-progress-bar-container">
                    <div className="sync-progress-bar" style={{ width: `${syncProgress}%` }} />
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Tab切换 */}
      <div className="px-4">
        <div className="glass-card" style={{ padding: '4px', display: 'flex' }}>
          <button
            onClick={() => setActiveTab('sync')}
            className={`xhs-btn ${activeTab === 'sync' ? 'xhs-btn-primary' : 'xhs-btn-secondary'}`}
            style={{ 
              flex: 1, 
              borderRadius: 'var(--radius-md)',
              boxShadow: activeTab === 'sync' ? 'var(--shadow-sm)' : 'none'
            }}
          >
            📥 同步管理
          </button>
          <button
            onClick={() => setActiveTab('config')}
            className={`xhs-btn ${activeTab === 'config' ? 'xhs-btn-primary' : 'xhs-btn-secondary'}`}
            style={{ 
              flex: 1, 
              borderRadius: 'var(--radius-md)',
              boxShadow: activeTab === 'config' ? 'var(--shadow-sm)' : 'none'
            }}
          >
            ⚙️ 配置设置
          </button>
        </div>
      </div>

      {/* 同步管理面板 */}
      {activeTab === 'sync' && (
        <div className="p-4">
          <div className="xhs-card glass-card">
            <div className="xhs-card-title">同步内容</div>
            
            {syncTypes.map((item) => (
              <div 
                key={item.key}
                className={`sync-status-card ${syncStatus[item.key] ? 'active' : ''}`}
              >
                <div 
                  className={`sync-status-icon ${item.iconClass} ${syncStatus[item.key] ? 'syncing' : ''} xhs-bubble`}
                  data-bubble={syncStatus[item.key] ? '同步中...' : '点击开启'}
                  style={{ 
                    background: item.iconClass === 'post' 
                      ? 'linear-gradient(135deg, #FFE4E8 0%, #FFCCD5 100%)'
                      : item.iconClass === 'bookmark'
                      ? 'linear-gradient(135deg, #FFF3E0 0%, #FFE0B2 100%)'
                      : 'linear-gradient(135deg, #FFE4EC 0%, #FFCCD5 100%)'
                  }}
                >
                  {item.icon}
                </div>
                <div className="sync-status-info">
                  <div className="sync-status-title">{item.title}</div>
                  <div className="sync-status-time">
                    {syncStatus[item.key] ? (
                      <span style={{ color: 'var(--success-color)', display: 'flex', alignItems: 'center', gap: '4px' }}>
                        <span className="animate-pulse">●</span> 同步中 · {formatTime(lastSyncTime[item.key])}
                      </span>
                    ) : (
                      `最后同步：${formatTime(lastSyncTime[item.key])}`
                    )}
                  </div>
                </div>
                <div 
                  className={`xhs-switch ${syncStatus[item.key] ? 'active' : ''}`}
                  onClick={() => toggleSync(item.platform)}
                />
              </div>
            ))}
          </div>

          {/* 快捷操作 */}
          <div className="xhs-card glass-card">
            <div className="xhs-card-title">快捷操作</div>
            <div style={{ display: 'flex', gap: '10px' }}>
              <button 
                className="xhs-btn xhs-btn-secondary xhs-btn-block"
                onClick={stopAllSync}
              >
                ⏹️ 停止全部
              </button>
              <button 
                className="xhs-btn xhs-btn-outline xhs-btn-block"
                onClick={clearCache}
              >
                🗑️ 清除缓存
              </button>
            </div>
          </div>

          {/* AI功能提示 */}
          {openaiConfig.enableAIClassify && (
            <div className="xhs-card glass-card" style={{ background: 'linear-gradient(135deg, #FFF5F5 0%, #FFFFFF 100%)' }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                <span style={{ fontSize: '20px' }}>🤖</span>
                <div>
                  <div style={{ fontWeight: 600, fontSize: '14px' }}>AI智能分类已启用</div>
                  <div style={{ fontSize: '12px', color: 'var(--text-hint)' }}>将自动为同步内容添加智能标签</div>
                </div>
              </div>
            </div>
          )}
        </div>
      )}

      {/* 配置设置面板 */}
      {activeTab === 'config' && (
        <div className="p-4">
          {/* Notion配置 */}
          <div className="xhs-card glass-card">
            <div className="xhs-card-title">Notion 配置</div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: '14px' }}>
              <div>
                <label className="xhs-input-label">API Key</label>
                <input
                  type="password"
                  value={notionConfig.apiKey}
                  onChange={(e) => setNotionConfig({ ...notionConfig, apiKey: e.target.value })}
                  className="xhs-input"
                  placeholder="输入 Notion Integration Token"
                />
              </div>
              <div>
                <label className="xhs-input-label">数据库 ID</label>
                <input
                  type="text"
                  value={notionConfig.databaseId}
                  onChange={(e) => setNotionConfig({ ...notionConfig, databaseId: e.target.value })}
                  className="xhs-input"
                  placeholder="输入 Notion 数据库 ID"
                />
              </div>
            </div>
          </div>

          {/* AI配置 */}
          <div className="xhs-card glass-card">
            <div className="xhs-card-title">AI 智能分类</div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: '14px' }}>
              <div>
                <label className="xhs-input-label">OpenAI API Key</label>
                <input
                  type="password"
                  value={openaiConfig.apiKey}
                  onChange={(e) => setOpenaiConfig({ ...openaiConfig, apiKey: e.target.value })}
                  className="xhs-input"
                  placeholder="输入 OpenAI API Key（可选）"
                />
              </div>
              <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                <div>
                  <div style={{ fontWeight: 500, fontSize: '14px' }}>启用AI分类</div>
                  <div style={{ fontSize: '12px', color: 'var(--text-hint)' }}>自动为内容添加智能标签</div>
                </div>
                <div 
                  className={`xhs-switch ${openaiConfig.enableAIClassify ? 'active' : ''}`}
                  onClick={() => setOpenaiConfig({ ...openaiConfig, enableAIClassify: !openaiConfig.enableAIClassify })}
                />
              </div>
            </div>
          </div>

          {/* 保存按钮 */}
          <button 
            className={`xhs-btn xhs-btn-primary xhs-btn-block xhs-btn-lg ${loading ? 'loading' : ''}`}
            onClick={saveConfig}
            disabled={loading}
            style={{ marginTop: '8px' }}
          >
            {loading ? '保存中...' : '💾 保存配置'}
          </button>
        </div>
      )}

      {/* 底部版本信息 */}
      <div style={{ textAlign: 'center', padding: '20px', color: 'var(--text-hint)', fontSize: '12px' }}>
        Rednote2Notion v2.2.0 · Made with ❤️
      </div>

      {/* Toast提示 */}
      <Toast message={toast.message} type={toast.type} show={toast.show} />
    </div>
  );
};

export default SidePanel;

﻿import { encryptLicense, decryptLicense, sha256Hash, md5Hash } from './crypto';
import { v4 as uuidv4 } from 'uuid';

// ==================== 类型定义 ====================
export enum LicenseType {
  FREE = 'free',
  TRIAL = 'trial',
  PERMANENT = 'permanent'
}

export interface LicenseInfo {
  licenseCode: string;
  licenseType: LicenseType;
  activateTime: number;
  expireTime: number;
  deviceFingerprint: string;
  maxSyncCount: number;
  usedSyncCount: number;
  isValid: boolean;
  isActivated: boolean; // 新增：是否已激活
  errorMsg?: string;
}

export interface LicenseGenerateConfig {
  licenseType: LicenseType;
  validDays?: number; // 仅体验版需要
  deviceFingerprint?: string; // 绑定设备，为空则生成未激活卡密，用户激活时绑定
  batchCount?: number; // 批量生成数量
}

export interface LicenseParseResult {
  licenseId: string;
  licenseType: LicenseType;
  generateTime: number;
  expireTime: number;
  deviceFingerprint: string;
  isActivated: boolean;
  isValid: boolean;
  errorMsg?: string;
}

// ==================== 常量配置 ====================
// 免费版同步上限
export const FREE_VERSION_MAX_SYNC = 5;
// 体验版默认有效期7天
export const TRIAL_DEFAULT_DAYS = 7;
// 永久版有效期（99年）
export const PERMANENT_VALID_YEARS = 99;
// 未激活卡密标记
export const UNACTIVATED_DEVICE_FLAG = 'UNACTIVATED_CARD';
// 本地存储key
export const LICENSE_STORAGE_KEY = 'rednote_license_code';
export const LICENSE_USED_COUNT_KEY = 'license_used_sync_count';
export const LICENSE_ACTIVATED_KEY = 'rednote_license_activated';

// ==================== 工具函数 ====================
/**
 * 生成设备指纹（防倒卖核心，绑定浏览器环境）
 * @returns 设备唯一指纹
 */
export const generateDeviceFingerprint = async (): Promise<string> => {
  try {
    // 组合浏览器唯一标识+扩展ID+用户代理，生成不可逆指纹
    const runtimeId = chrome.runtime.id;
    const userAgent = navigator.userAgent;
    const platform = navigator.platform;
    const hardwareConcurrency = navigator.hardwareConcurrency;
    const language = navigator.language;
    const screenResolution = `${screen.width}x${screen.height}`;
    const rawFingerprint = `${runtimeId}_${userAgent}_${platform}_${hardwareConcurrency}_${language}_${screenResolution}`;
    
    // SHA256哈希生成16位指纹
    const hash = await sha256Hash(rawFingerprint);
    return hash.slice(0, 16);
  } catch (error) {
    console.error('生成设备指纹失败', error);
    // 异常时生成兜底指纹
    return md5Hash(`${chrome.runtime.id}_${Date.now()}`).slice(0, 16);
  }
};

/**
 * ==================== 卖家核心：生成授权码/卡密 ====================
 * 支持单条/批量生成，支持预生成未激活卡密
 */
export const generateLicenseCode = async (config: LicenseGenerateConfig): Promise<string[]> => {
  const { licenseType, validDays, deviceFingerprint, batchCount = 1 } = config;
  const generatedCodes: string[] = [];

  for (let i = 0; i < batchCount; i++) {
    const licenseId = uuidv4().replace(/-/g, '');
    const generateTime = Date.now();
    let expireTime = 0;

    // 计算过期时间
    if (licenseType === LicenseType.TRIAL) {
      // 体验版：激活后才开始计算有效期，预生成时先设置为生成时间+1年激活窗口期
      const days = validDays || TRIAL_DEFAULT_DAYS;
      expireTime = deviceFingerprint 
        ? generateTime + days * 24 * 60 * 60 * 1000 // 已绑定设备，直接计算有效期
        : generateTime + 365 * 24 * 60 * 60 * 1000; // 未激活卡密，1年激活窗口期
    } else if (licenseType === LicenseType.PERMANENT) {
      expireTime = generateTime + PERMANENT_VALID_YEARS * 365 * 24 * 60 * 60 * 1000;
    } else {
      expireTime = generateTime + 99 * 365 * 24 * 60 * 60 * 1000;
    }

    // 构建授权码原始数据
    const rawLicense = {
      licenseId,
      licenseType,
      generateTime,
      expireTime,
      // 未绑定设备则标记为未激活卡密，用户激活时替换为设备指纹
      deviceFingerprint: deviceFingerprint || UNACTIVATED_DEVICE_FLAG,
      validDays: licenseType === LicenseType.TRIAL ? validDays || TRIAL_DEFAULT_DAYS : 0,
      isPreGenerated: !deviceFingerprint // 是否为预生成卡密
    };

    // 专用加密生成授权码
    const licenseStr = JSON.stringify(rawLicense);
    const licenseCode = encryptLicense(licenseStr);
    generatedCodes.push(licenseCode);
  }

  return generatedCodes;
};

/**
 * 解析授权码信息（卖家售后校验用）
 * @param licenseCode 授权码
 * @returns 解析后的授权信息
 */
export const parseLicenseCode = async (licenseCode: string): Promise<LicenseParseResult> => {
  const defaultResult: LicenseParseResult = {
    licenseId: '',
    licenseType: LicenseType.FREE,
    generateTime: 0,
    expireTime: 0,
    deviceFingerprint: '',
    isActivated: false,
    isValid: false,
    errorMsg: '授权码格式错误'
  };

  if (!licenseCode || licenseCode.trim() === '') {
    return { ...defaultResult, errorMsg: '授权码不能为空' };
  }

  try {
    // 解密授权码
    const decryptedStr = decryptLicense(licenseCode);
    const licenseData = JSON.parse(decryptedStr);

    // 校验基础字段
    if (!licenseData.licenseId || !licenseData.licenseType) {
      return { ...defaultResult, errorMsg: '授权码无效，非官方生成' };
    }

    // 判断是否已激活
    const isActivated = licenseData.deviceFingerprint !== UNACTIVATED_DEVICE_FLAG;
    const now = Date.now();
    let isValid = true;
    let errorMsg = '';

    // 校验有效期
    if (licenseData.expireTime < now) {
      isValid = false;
      errorMsg = '授权码已过期';
    }

    return {
      licenseId: licenseData.licenseId,
      licenseType: licenseData.licenseType,
      generateTime: licenseData.generateTime,
      expireTime: licenseData.expireTime,
      deviceFingerprint: licenseData.deviceFingerprint,
      isActivated,
      isValid,
      errorMsg
    };

  } catch (error) {
    return { ...defaultResult, errorMsg: `解析失败：${error.message}` };
  }
};

/**
 * 激活预生成卡密，绑定当前设备
 * @param licenseCode 预生成授权码
 * @returns 激活后的授权信息
 */
export const activateLicenseCode = async (licenseCode: string): Promise<LicenseInfo> => {
  const deviceFingerprint = await generateDeviceFingerprint();
  const defaultFreeLicense: LicenseInfo = {
    licenseCode: '',
    licenseType: LicenseType.FREE,
    activateTime: Date.now(),
    expireTime: Date.now() + 99 * 365 * 24 * 60 * 60 * 1000,
    deviceFingerprint,
    maxSyncCount: FREE_VERSION_MAX_SYNC,
    usedSyncCount: 0,
    isValid: false,
    isActivated: false,
    errorMsg: '激活失败'
  };

  try {
    // 先解析授权码
    const parseResult = await parseLicenseCode(licenseCode);
    if (!parseResult.isValid) {
      return { ...defaultFreeLicense, errorMsg: parseResult.errorMsg };
    }

    // 检查是否已激活
    if (parseResult.isActivated) {
      return { ...defaultFreeLicense, errorMsg: '该授权码已被其他设备激活，禁止倒卖' };
    }

    // 解密原始数据
    const decryptedStr = decryptLicense(licenseCode);
    const licenseData = JSON.parse(decryptedStr);

    // 重新计算有效期（体验版激活后开始计时）
    const now = Date.now();
    let newExpireTime = licenseData.expireTime;
    if (licenseData.licenseType === LicenseType.TRIAL) {
      const validDays = licenseData.validDays || TRIAL_DEFAULT_DAYS;
      newExpireTime = now + validDays * 24 * 60 * 60 * 1000;
    }

    // 绑定当前设备指纹，生成新的授权码
    const newLicenseData = {
      ...licenseData,
      deviceFingerprint,
      expireTime: newExpireTime,
      activateTime: now,
      isPreGenerated: false
    };

    const newLicenseStr = JSON.stringify(newLicenseData);
    const newLicenseCode = encryptLicense(newLicenseStr);

    // 保存激活后的授权码到本地存储
    await saveLicenseCode(newLicenseCode);
    await chrome.storage.local.set({
      [LICENSE_ACTIVATED_KEY]: true,
      [LICENSE_USED_COUNT_KEY]: 0
    });

    // 读取已同步数量
    const storageData = await chrome.storage.local.get(LICENSE_USED_COUNT_KEY);
    const usedSyncCount = storageData[LICENSE_USED_COUNT_KEY] || 0;

    // 计算最大同步数量
    let maxSyncCount = Infinity;
    if (newLicenseData.licenseType === LicenseType.FREE) {
      maxSyncCount = FREE_VERSION_MAX_SYNC;
    }

    return {
      licenseCode: newLicenseCode,
      licenseType: newLicenseData.licenseType,
      activateTime: now,
      expireTime: newExpireTime,
      deviceFingerprint,
      maxSyncCount,
      usedSyncCount,
      isValid: true,
      isActivated: true
    };

  } catch (error) {
    return { ...defaultFreeLicense, errorMsg: `激活失败：${error.message}` };
  }
};

/**
 * 校验授权码（插件核心校验逻辑，兼容新旧模式）
 * @param licenseCode 授权码
 * @returns 授权信息
 */
export const verifyLicenseCode = async (licenseCode: string): Promise<LicenseInfo> => {
  const deviceFingerprint = await generateDeviceFingerprint();
  const defaultFreeLicense: LicenseInfo = {
    licenseCode: '',
    licenseType: LicenseType.FREE,
    activateTime: Date.now(),
    expireTime: Date.now() + 99 * 365 * 24 * 60 * 60 * 1000,
    deviceFingerprint,
    maxSyncCount: FREE_VERSION_MAX_SYNC,
    usedSyncCount: 0,
    isValid: true,
    isActivated: false
  };

  // 无授权码，返回免费版授权
  if (!licenseCode || licenseCode.trim() === '') {
    const storageData = await chrome.storage.local.get(LICENSE_USED_COUNT_KEY);
    defaultFreeLicense.usedSyncCount = storageData[LICENSE_USED_COUNT_KEY] || 0;
    return defaultFreeLicense;
  }

  try {
    // 解密授权码
    const decryptedStr = decryptLicense(licenseCode);
    const licenseData = JSON.parse(decryptedStr);

    // 校验是否为未激活卡密
    if (licenseData.deviceFingerprint === UNACTIVATED_DEVICE_FLAG) {
      return {
        ...defaultFreeLicense,
        licenseCode,
        licenseType: licenseData.licenseType,
        isValid: false,
        isActivated: false,
        errorMsg: '该授权码未激活，请先点击激活按钮绑定设备'
      };
    }

    // 校验设备绑定
    if (licenseData.deviceFingerprint !== deviceFingerprint) {
      return {
        ...defaultFreeLicense,
        isValid: false,
        errorMsg: '授权码已绑定其他设备，禁止倒卖'
      };
    }

    // 校验有效期
    const now = Date.now();
    if (licenseData.expireTime < now) {
      return {
        ...defaultFreeLicense,
        isValid: false,
        errorMsg: '授权码已过期，请续费'
      };
    }

    // 读取已同步数量
    const storageData = await chrome.storage.local.get(LICENSE_USED_COUNT_KEY);
    const usedSyncCount = storageData[LICENSE_USED_COUNT_KEY] || 0;

    // 构建授权信息
    const licenseType = licenseData.licenseType as LicenseType;
    let maxSyncCount = Infinity;
    if (licenseType === LicenseType.FREE) {
      maxSyncCount = FREE_VERSION_MAX_SYNC;
    }

    return {
      licenseCode,
      licenseType,
      activateTime: licenseData.activateTime || licenseData.generateTime,
      expireTime: licenseData.expireTime,
      deviceFingerprint,
      maxSyncCount,
      usedSyncCount,
      isValid: true,
      isActivated: true
    };

  } catch (error) {
    return {
      ...defaultFreeLicense,
      isValid: false,
      errorMsg: '授权码格式错误，非官方生成'
    };
  }
};

/**
 * 更新已同步数量计数
 * @param addCount 新增同步数量
 */
export const updateSyncCount = async (addCount: number = 1) => {
  const storageData = await chrome.storage.local.get(LICENSE_USED_COUNT_KEY);
  const currentCount = storageData[LICENSE_USED_COUNT_KEY] || 0;
  await chrome.storage.local.set({
    [LICENSE_USED_COUNT_KEY]: currentCount + addCount
  });
};

/**
 * 重置同步计数（仅管理员可用）
 */
export const resetSyncCount = async () => {
  await chrome.storage.local.set({
    [LICENSE_USED_COUNT_KEY]: 0
  });
};

/**
 * 保存授权码到本地存储
 * @param licenseCode 授权码
 */
export const saveLicenseCode = async (licenseCode: string) => {
  await chrome.storage.local.set({
    [LICENSE_STORAGE_KEY]: licenseCode
  });
};

/**
 * 从本地存储读取授权码
 * @returns 授权码
 */
export const getLicenseCode = async (): Promise<string> => {
  const storageData = await chrome.storage.local.get(LICENSE_STORAGE_KEY);
  return storageData[LICENSE_STORAGE_KEY] || '';
};

/**
 * 获取当前有效授权信息
 * @returns 授权信息
 */
export const getCurrentLicense = async (): Promise<LicenseInfo> => {
  const licenseCode = await getLicenseCode();
  return await verifyLicenseCode(licenseCode);
};

/**
 * 检查是否有权限执行同步
 * @returns 是否有权限
 */
export const checkSyncPermission = async (): Promise<{ hasPermission: boolean; errorMsg?: string }> => {
  const license = await getCurrentLicense();

  // 必须先输入授权码
  if (!license.licenseCode || license.licenseCode.trim() === '') {
    return { hasPermission: false, errorMsg: '请先输入并激活授权码' };
  }

  // 授权无效
  if (!license.isValid) {
    return { hasPermission: false, errorMsg: license.errorMsg || '授权无效，请重新激活' };
  }

  // 必须激活后才能使用（所有版本都需激活）
  if (!license.isActivated) {
    return { hasPermission: false, errorMsg: '授权码未激活，请先绑定设备' };
  }

  // 免费版超出同步上限
  if (license.licenseType === LicenseType.FREE && license.usedSyncCount >= license.maxSyncCount) {
    return { hasPermission: false, errorMsg: `免费版仅支持同步${FREE_VERSION_MAX_SYNC}篇笔记，请升级永久版` };
  }

  return { hasPermission: true };
};

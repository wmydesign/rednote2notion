﻿// ==================== 原有基础类型 ====================
// 消息类型枚举
export enum MessageType {
  SYNC_TO_NOTION = 'sync-to-notion',
  GET_COOKIE = 'get-cookie',
  ACCOUNT_SWITCH = 'account-switch',
  STOP_ALL_SYNC = 'stop-all-sync',
  CLEAR_CACHE = 'clear-cache',
  GET_ALBUM_LIST = 'get-album-list',
  GET_NOTE_DETAIL = 'get-note-detail',
  SYNC_ERROR = 'sync-error'
}

// 知识类型枚举
export enum KnowledgeType {
  BOOKMARK = '收藏',
  POST = '个人帖子',
  LIKE = '点赞',
  ALBUM = '指定专辑'
}

// 平台配置类型
export interface PlatformConfig {
  name: string;
  knowledgeType: KnowledgeType;
  url: string;
  storage: {
    syncStatusKey: string;
    nextPos: string;
    prevPos: string;
    allSync: string;
  };
}

// 小红书用户信息
export interface RednoteUser {
  userId: string;
  nickname: string;
  avatar: string;
}

// ==================== 新增类型 ====================
// 小红书收藏专辑类型
export interface RednoteAlbum {
  albumId: string;
  albumName: string;
  coverUrl: string;
  noteCount: number;
  updateTime: number;
  isDefault: boolean;
}

// 高级筛选规则类型
export interface FilterRule {
  id: string;
  field: 'title' | 'desc' | 'tags' | 'publishTime' | 'collectTime' | 'likeCount' | 'collectCount' | 'commentCount' | 'noteType' | 'authorName';
  operator: 'contains' | 'notContains' | 'equals' | 'notEquals' | 'greaterThan' | 'lessThan' | 'between' | 'in' | 'notIn' | 'tagContains';
  value: any;
  logic: 'and' | 'or';
}

// AI加工模板类型
export interface AIProcessTemplate {
  id: string;
  name: string;
  fieldName: string;
  prompt: string;
  enable: boolean;
  isCustom?: boolean;
}

// AI加工结果类型
export interface AIProcessResult {
  fieldName: string;
  content: string;
}

// 笔记评论类型
export interface NoteComment {
  commentId: string;
  content: string;
  authorName: string;
  isAuthor: boolean;
  likeCount: number;
  publishTime: number;
}

// OCR结果类型
export interface NoteOCRResult {
  imageUrl: string;
  text: string;
}

// 升级后的小红书笔记数据
export interface RednoteNote {
  id: string;
  title: string;
  desc: string;
  coverUrl: string;
  allImages: string[]; // 新增：所有图片列表
  authorName: string;
  authorId: string;
  publishTime: number;
  collectTime?: number; // 新增：收藏时间
  likeCount: number;
  collectCount: number;
  commentCount: number;
  shareCount: number;
  noteUrl: string;
  noteType: 'normal' | 'video' | 'image'; // 新增：笔记类型
  tags: string[];
  albumId?: string; // 新增：所属专辑ID
  albumName?: string; // 新增：所属专辑名称
  aiCategory?: string;
  aiProcessResults?: AIProcessResult[]; // 新增：AI深度加工结果
  ocrResults?: NoteOCRResult[]; // 新增：图片OCR结果
  comments?: NoteComment[]; // 新增：评论列表
  authorComments?: NoteComment[]; // 新增：作者评论
}

// 同步状态
export interface SyncStatus {
  isRunning: boolean;
  total: number;
  synced: number;
  lastSyncTime: number;
  error?: string;
}

// 账号状态快照
export interface AccountState {
  userId: string;
  static: Record<string, any>;
  bookmarkCateAllSync: Record<string, boolean>;
  selectedAlbums?: string[];
  albumCategoryMap?: Record<string, string>;
}

// 同步配置
export interface SyncConfig {
  platform: keyof typeof platformConfig;
  notionApiKey: string;
  notionDatabaseId: string;
  openaiApiKey?: string;
  enableAIClassify?: boolean;
  // 新增配置
  selectedAlbums: string[];
  albumCategoryMap: Record<string, string>;
  filterRules: FilterRule[];
  enableAIProcess: boolean;
  aiProcessTemplates: AIProcessTemplate[];
  enableOCR: boolean;
  ocrConfig?: any;
  syncAuthorComments: boolean;
  syncTopComments: number;
}

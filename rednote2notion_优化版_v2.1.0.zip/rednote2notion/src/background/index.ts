import { MessageType, KnowledgeType, PlatformConfig, AccountState, RednoteNote } from '../lib/types';
import { classifyNoteWithAI } from '../lib/openai';
import { writeNoteToNotion, checkNoteIsSynced } from '../lib/notion';
import { encryptAES, decryptAES } from '../lib/crypto';
import { checkSyncPermission, updateSyncCount } from '../lib/license';

// ==================== 全局配置 ====================
// 同步间隔（5分钟，与拆解报告一致）
const SYNC_INTERVAL_MINUTES = 5;
// 平台配置
export const platformConfig: Record<string, PlatformConfig> = {
  rednotePost: {
    name: 'rednotePost',
    knowledgeType: KnowledgeType.POST,
    url: 'https://www.xiaohongshu.com',
    storage: {
      syncStatusKey: 'sync-rednote-post-to-notion',
      nextPos: 'rednote_post_next_cursor',
      prevPos: 'rednote_post_prev_cursor',
      allSync: 'rednote_post_all_sync'
    }
  },
  rednoteBookmark: {
    name: 'rednoteBookmark',
    knowledgeType: KnowledgeType.BOOKMARK,
    url: 'https://www.xiaohongshu.com',
    storage: {
      syncStatusKey: 'sync-rednote-bookmark-to-notion',
      nextPos: 'rednote_bookmark_next_cursor',
      prevPos: 'rednote_bookmark_prev_cursor',
      allSync: 'rednote_bookmark_all_sync'
    }
  },
  rednoteLike: {
    name: 'rednoteLike',
    knowledgeType: KnowledgeType.LIKE,
    url: 'https://www.xiaohongshu.com',
    storage: {
      syncStatusKey: 'sync-rednote-like-to-notion',
      nextPos: 'rednote_like_next_cursor',
      prevPos: 'rednote_like_prev_cursor',
      allSync: 'rednote_like_all_sync'
    }
  }
};
// 单账号状态键列表
const PER_ACCOUNT_STATIC_KEYS = [
  'rednote_post_next_cursor',
  'rednote_post_prev_cursor',
  'rednote_post_all_sync',
  'rednote_bookmark_next_cursor',
  'rednote_bookmark_prev_cursor',
  'rednote_bookmark_all_sync',
  'rednote_like_next_cursor',
  'rednote_like_prev_cursor',
  'rednote_like_all_sync'
];

// 当前登录用户
let currentUser: { userId: string; nickname: string } | null = null;

// ==================== 插件安装初始化 ====================
chrome.runtime.onInstalled.addListener(async () => {
  console.log('Rednote2Notion 插件已安装');
  // 初始化跨域规则
  await chrome.declarativeNetRequest.updateEnabledRulesets({
    enableRulesetIds: ['ruleset_1']
  });
});

// ==================== 消息监听核心处理 ====================
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  switch (message.name) {
    case MessageType.ACCOUNT_SWITCH:
      handleAccountSwitch(message.data);
      sendResponse({ success: true });
      break;
    case MessageType.CLEAR_CACHE:
      handleClearCache();
      sendResponse({ success: true });
      break;
    case MessageType.GET_COOKIE:
      handleGetCookie(sender.tab?.id);
      sendResponse({ success: true });
      break;
    case MessageType.STOP_ALL_SYNC:
      handleStopAllSync();
      sendResponse({ success: true });
      break;
    case MessageType.SYNC_TO_NOTION:
      handleSyncToNotion(message.data);
      sendResponse({ success: true });
      break;
    case MessageType.SYNC_ERROR:
      // 处理同步错误，传递给前端展示
      console.error('同步错误:', message.data?.error);
      sendResponse({ success: true, error: message.data?.error });
      break;
    default:
      break;
  }
  return true;
});

// ==================== 账号切换处理 ====================
const handleAccountSwitch = async (userInfo: { userId: string; nickname: string; avatar: string }) => {
  console.log('检测到账号切换', userInfo.userId);
  // 保存当前账号状态快照
  if (currentUser?.userId) {
    await snapshotAccountState(currentUser.userId);
  }
  // 更新当前用户
  currentUser = userInfo;
  // 恢复新账号的状态
  await restoreAccountState(userInfo.userId);
};

// 账号状态快照
const snapshotAccountState = async (userId: string) => {
  const state: AccountState = {
    userId,
    static: {},
    bookmarkCateAllSync: {}
  };

  // 读取所有单账号状态键
  for (const key of PER_ACCOUNT_STATIC_KEYS) {
    const result = await chrome.storage.local.get(key);
    state.static[key] = result[key];
  }

  // 保存到本地存储
  const allState = await chrome.storage.local.get('rednote_per_account_state');
  const perAccountState = allState.rednote_per_account_state || {};
  perAccountState[userId] = state;
  await chrome.storage.local.set({ rednote_per_account_state: perAccountState });
};

// 账号状态恢复
const restoreAccountState = async (userId: string) => {
  const allState = await chrome.storage.local.get('rednote_per_account_state');
  const perAccountState = allState.rednote_per_account_state || {};
  const state = perAccountState[userId] as AccountState;

  if (!state) return;

  // 恢复单账号状态键
  for (const key of PER_ACCOUNT_STATIC_KEYS) {
    if (state.static[key] !== undefined) {
      await chrome.storage.local.set({ [key]: state.static[key] });
    }
  }
};

// ==================== 同步核心处理 ====================
// 启动同步
const handleSyncToNotion = async (config: {
  platform: keyof typeof platformConfig;
  notionApiKey: string;
  notionDatabaseId: string;
  openaiApiKey?: string;
  enableAIClassify?: boolean;
}) => {
  const { platform, notionApiKey, notionDatabaseId, openaiApiKey, enableAIClassify } = config;
  const platformCfg = platformConfig[platform];

  if (!platformCfg) {
    console.error('无效的平台配置');
    return;
  }

  // 标记同步状态为运行中
  await chrome.storage.local.set({ [platformCfg.storage.syncStatusKey]: true });

  // 启动定时同步
  await startSync(platform, SYNC_INTERVAL_MINUTES, notionApiKey, notionDatabaseId, openaiApiKey, enableAIClassify);
};

// 停止所有同步
const handleStopAllSync = async () => {
  // 清除所有定时任务
  const allAlarms = await chrome.alarms.getAll();
  for (const alarm of allAlarms) {
    if (alarm.name.startsWith('rednote-sync-')) {
      await chrome.alarms.clear(alarm.name);
    }
  }

  // 标记所有同步状态为停止
  for (const key of Object.values(platformConfig)) {
    await chrome.storage.local.set({ [key.storage.syncStatusKey]: false });
  }

  console.log('所有同步任务已停止');
};

// 清除缓存
const handleClearCache = async () => {
  // 清除所有同步进度缓存
  for (const key of PER_ACCOUNT_STATIC_KEYS) {
    await chrome.storage.local.remove(key);
  }
  console.log('同步缓存已清除');
};

// 获取Cookie
const handleGetCookie = async (tabId: number | undefined) => {
  if (!tabId) return;
  await chrome.scripting.executeScript({
    target: { tabId },
    func: () => document.cookie
  });
};

// 启动定时同步任务
const startSync = async (
  platform: keyof typeof platformConfig,
  intervalMinutes: number,
  notionApiKey: string,
  notionDatabaseId: string,
  openaiApiKey?: string,
  enableAIClassify?: boolean
) => {
  const alarmName = `rednote-sync-${platform}`;
  // 先清除已存在的同类型闹钟
  await chrome.alarms.clear(alarmName);

  // 创建定时闹钟
  chrome.alarms.create(alarmName, {
    periodInMinutes: intervalMinutes,
    delayInMinutes: 0 // 立即执行一次
  });

  // 监听闹钟触发
  chrome.alarms.onAlarm.addListener(async (alarm) => {
    if (alarm.name === alarmName) {
      await fetchDataSyncToNotion({
        platform,
        notionApiKey,
        notionDatabaseId,
        openaiApiKey,
        enableAIClassify
      });
    }
  });
};

// 核心数据拉取与同步到Notion
const fetchDataSyncToNotion = async (config: {
  platform: keyof typeof platformConfig;
  notionApiKey: string;
  notionDatabaseId: string;
  openaiApiKey?: string;
  enableAIClassify?: boolean;
}) => {
  const { platform, notionApiKey, notionDatabaseId, openaiApiKey, enableAIClassify } = config;
  const platformCfg = platformConfig[platform];

  // ========== 授权检查 ==========
  try {
    const permission = await checkSyncPermission();
    if (!permission.hasPermission) {
      console.error('同步权限校验失败:', permission.errorMsg);
      // 通知用户授权问题
      chrome.runtime.sendMessage({
        name: MessageType.SYNC_ERROR,
        data: { error: permission.errorMsg }
      }).catch(() => {});
      return;
    }
  } catch (error) {
    console.error('授权检查异常:', error);
    return;
  }
  // ========== 授权检查结束 ==========

  try {
    // 获取同步游标
    const storageData = await chrome.storage.local.get(platformCfg.storage.nextPos);
    const cursor = storageData[platformCfg.storage.nextPos] || '';

    // 构建API地址
    let apiUrl = '';
    let requestMethod = 'GET';
    let requestBody = null;

    switch (platformCfg.knowledgeType) {
      case KnowledgeType.POST:
        // 个人帖子API
        apiUrl = `https://edith.xiaohongshu.com/api/sns/web/v1/user/notes?cursor=${cursor}&num=20&user_id=${currentUser?.userId}`;
        break;
      case KnowledgeType.BOOKMARK:
        // 收藏API
        apiUrl = 'https://edith.xiaohongshu.com/api/sns/web/v2/note/collect/page';
        requestMethod = 'POST';
        requestBody = JSON.stringify({ cursor, num: 20 });
        break;
      case KnowledgeType.LIKE:
        // 点赞API
        apiUrl = 'https://edith.xiaohongshu.com/api/sns/web/v1/note/like/page';
        requestMethod = 'POST';
        requestBody = JSON.stringify({ cursor, num: 20 });
        break;
    }

    // 请求小红书API
    const response = await fetch(apiUrl, {
      method: requestMethod,
      credentials: 'include',
      headers: {
        'Content-Type': 'application/json',
        'Referer': 'https://www.xiaohongshu.com/',
        'User-Agent': navigator.userAgent
      },
      body: requestBody
    });

    if (!response.ok) {
      throw new Error(`API请求失败: ${response.status}`);
    }

    const data = await response.json();
    if (data.code !== 0) {
      throw new Error(`API返回错误: ${data.msg}`);
    }

    const notes = data.data?.notes || data.data?.items || [];
    const nextCursor = data.data?.cursor || '';
    const hasMore = data.data?.has_more || false;

    // 遍历帖子，同步到Notion
    for (const note of notes) {
      const noteId = note.note_id || note.id;
      // 检查是否已同步
      const isSynced = await checkNoteIsSynced(notionApiKey, notionDatabaseId, noteId);
      if (isSynced) continue;

      // 格式化帖子数据
      const formattedNote: RednoteNote = {
        id: noteId,
        title: note.title || '',
        desc: note.desc || note.content || '',
        coverUrl: note.cover?.url || note.images?.[0]?.url || '',
        authorName: note.user?.nickname || note.author?.nickname || '',
        authorId: note.user?.user_id || note.author?.user_id || '',
        publishTime: note.time || note.publish_time || Date.now(),
        likeCount: note.like_count || note.liked_count || 0,
        collectCount: note.collect_count || note.collected_count || 0,
        commentCount: note.comment_count || 0,
        shareCount: note.share_count || 0,
        noteUrl: `https://www.xiaohongshu.com/discovery/item/${noteId}`,
        tags: note.tags?.map((tag: any) => tag.name) || []
      };

      // AI分类
      if (enableAIClassify && openaiApiKey) {
        formattedNote.aiCategory = await classifyNoteWithAI(openaiApiKey, formattedNote);
      }

      // 写入Notion
      await writeNoteToNotion(notionApiKey, notionDatabaseId, formattedNote);

      // ========== 更新同步计数 ==========
      await updateSyncCount(1);
      // ========== 计数更新结束 ==========

      // 延迟避免API限流
      await new Promise(resolve => setTimeout(resolve, 500));
    }

    // 更新游标
    if (hasMore && nextCursor) {
      await chrome.storage.local.set({ [platformCfg.storage.nextPos]: nextCursor });
    } else {
      // 全部同步完成
      await chrome.storage.local.set({ [platformCfg.storage.allSync]: true });
    }

    // 更新最后同步时间
    await chrome.storage.local.set({
      [`${platformCfg.storage.syncStatusKey}_last_time`]: Date.now()
    });

    console.log(`${platformCfg.knowledgeType}同步完成，本次同步${notes.length}条`);

  } catch (error) {
    console.error('同步失败', error);
    // 标记同步错误
    await chrome.storage.local.set({
      [`${platformCfg.storage.syncStatusKey}_error`]: error.message
    });
  }
};


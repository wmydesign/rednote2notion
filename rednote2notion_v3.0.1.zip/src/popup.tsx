import React, { useState, useEffect } from 'react';
import { getCurrentLicense, activateLicenseCode, LicenseType } from './lib/license';
import './style.css';

// ==================== 类型定义 ====================
type SetupStep = 'license' | 'notion' | 'main';

// Toast组件
const Toast = ({ message, type = 'default', show }: { 
  message: string; 
  type?: 'default' | 'success' | 'error' | 'warning';
  show: boolean;
}) => {
  if (!message) return null;
  
  const icons = {
    default: '💡',
    success: '✅',
    error: '❌',
    warning: '⚠️'
  };
  
  return (
    <div className={`xhs-toast ${show ? 'show' : ''} ${type !== 'default' ? `xhs-toast-${type}` : ''}`}>
      <span className="xhs-toast-icon">{icons[type]}</span>
      <span>{message}</span>
    </div>
  );
};

// 骨架屏组件
const SkeletonLoader = () => (
  <div style={{ padding: '16px' }}>
    {/* 头部骨架 */}
    <div className="skeleton-card" style={{ marginBottom: '12px', padding: '16px' }}>
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
        <div>
          <div className="skeleton skeleton-text" style={{ width: '80px', height: '16px' }} />
          <div className="skeleton skeleton-text" style={{ width: '120px', height: '12px' }} />
        </div>
        <div className="skeleton" style={{ width: '40px', height: '40px', borderRadius: '50%' }} />
      </div>
    </div>
    
    {/* 状态卡片骨架 */}
    <div className="skeleton-card" style={{ marginBottom: '12px', padding: '16px' }}>
      <div style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
        {[1, 2].map((i) => (
          <div key={i} style={{ display: 'flex', justifyContent: 'space-between' }}>
            <div className="skeleton skeleton-text" style={{ width: '60px', height: '12px' }} />
            <div className="skeleton skeleton-text" style={{ width: '50px', height: '20px', borderRadius: '10px' }} />
          </div>
        ))}
      </div>
    </div>
    
    {/* 按钮骨架 */}
    <div style={{ display: 'flex', flexDirection: 'column', gap: '10px' }}>
      <div className="skeleton" style={{ height: '42px', borderRadius: '12px' }} />
      <div className="skeleton" style={{ height: '42px', borderRadius: '12px', opacity: 0.6 }} />
    </div>
  </div>
);

// 空状态组件
const EmptyState = ({ 
  icon = '📭', 
  title = '暂无数据', 
  description = '这里什么都没有'
}: {
  icon?: string;
  title?: string;
  description?: string;
}) => (
  <div className="empty-state animate-fade-in" style={{ padding: '24px 16px' }}>
    <div className="empty-state-icon" style={{ fontSize: '40px' }}>{icon}</div>
    <div className="empty-state-title" style={{ fontSize: '14px' }}>{title}</div>
    <div className="empty-state-desc" style={{ fontSize: '12px' }}>{description}</div>
  </div>
);

const Popup = () => {
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [syncStatus, setSyncStatus] = useState(false);
  const [licenseInfo, setLicenseInfo] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [isDarkMode, setIsDarkMode] = useState(false);
  const [toast, setToast] = useState({ show: false, message: '', type: 'default' as 'default' | 'success' | 'error' | 'warning' });
  
  // 引导流程状态
  const [currentStep, setCurrentStep] = useState<SetupStep>('license');
  const [licenseCode, setLicenseCode] = useState('');
  const [notionConfig, setNotionConfig] = useState({ apiKey: '', databaseId: '' });
  const [setupLoading, setSetupLoading] = useState(false);

  useEffect(() => {
    initDarkMode();
    checkSetupStatus();
  }, []);

  // 深色模式初始化
  const initDarkMode = () => {
    const stored = localStorage.getItem('darkMode');
    if (stored !== null) {
      setIsDarkMode(stored === 'true');
      document.body.classList.toggle('dark', stored === 'true');
    } else {
      const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
      setIsDarkMode(prefersDark);
      document.body.classList.toggle('dark', prefersDark);
    }
  };

  // 切换深色模式
  const toggleDarkMode = () => {
    const newMode = !isDarkMode;
    setIsDarkMode(newMode);
    localStorage.setItem('darkMode', String(newMode));
    document.body.classList.toggle('dark', newMode);
  };

  // 显示提示
  const showToast = (msg: string, type: 'default' | 'success' | 'error' | 'warning' = 'default') => {
    setToast({ show: true, message: msg, type });
    setTimeout(() => setToast({ show: false, message: '', type: 'default' }), 2500);
  };

  // 检查初始设置状态
  const checkSetupStatus = async () => {
    setLoading(true);
    
    // 模拟加载延迟以展示骨架屏
    await new Promise(resolve => setTimeout(resolve, 600));
    
    const license = await getCurrentLicense();
    setLicenseInfo(license);
    
    const storageData = await chrome.storage.local.get([
      'notion_api_key',
      'notion_database_id',
      'current_user',
      'sync-rednote-bookmark-to-notion',
      'sync-rednote-album-to-notion'
    ]);
    
    setIsLoggedIn(!!storageData.current_user);
    setSyncStatus(
      storageData['sync-rednote-bookmark-to-notion'] || 
      storageData['sync-rednote-album-to-notion'] || false
    );
    
    // 判断当前步骤
    if (!license.isActivated) {
      setCurrentStep('license');
    } else if (!storageData.notion_api_key || !storageData.notion_database_id) {
      setCurrentStep('notion');
    } else {
      setCurrentStep('main');
    }
    
    setNotionConfig({
      apiKey: storageData.notion_api_key || '',
      databaseId: storageData.notion_database_id || ''
    });
    
    setLoading(false);
  };

  // 激活授权码
  const handleActivateLicense = async () => {
    if (!licenseCode.trim()) {
      showToast('请输入授权码', 'warning');
      return;
    }
    setSetupLoading(true);
    const result = await activateLicenseCode(licenseCode);
    if (result.isValid) {
      setLicenseInfo(result);
      showToast('授权码激活成功', 'success');
      setCurrentStep('notion');
    } else {
      showToast(`激活失败：${result.errorMsg}`, 'error');
    }
    setSetupLoading(false);
  };

  // 保存Notion配置
  const handleSaveNotionConfig = async () => {
    if (!notionConfig.apiKey || !notionConfig.databaseId) {
      showToast('请填写完整的Notion配置', 'warning');
      return;
    }
    setSetupLoading(true);
    await chrome.storage.local.set({
      'notion_api_key': notionConfig.apiKey,
      'notion_database_id': notionConfig.databaseId
    });
    showToast('配置保存成功', 'success');
    setCurrentStep('main');
    setSetupLoading(false);
  };

  const openSidePanel = async () => {
    await chrome.sidePanel.open({ windowId: chrome.windows.WINDOW_ID_CURRENT });
    window.close();
  };

  const openOptionsPage = () => {
    chrome.runtime.openOptionsPage();
    window.close();
  };

  const formatLicenseType = (type: LicenseType) => {
    const map = {
      [LicenseType.FREE]: '免费版',
      [LicenseType.TRIAL]: '体验版',
      [LicenseType.PERMANENT]: '永久版'
    };
    return map[type] || '免费版';
  };

  // 显示骨架屏
  if (loading) {
    return (
      <div style={{ width: '280px', background: 'var(--bg-light)' }}>
        <div className="xhs-header" style={{ borderRadius: '0 0 var(--radius-lg) var(--radius-lg)' }}>
          <h1 style={{ fontSize: '18px' }}>Rednote2Notion</h1>
          <p style={{ fontSize: '12px' }}>小红书同步到Notion</p>
        </div>
        <SkeletonLoader />
      </div>
    );
  }

  // ========== 渲染授权码步骤 ==========
  if (currentStep === 'license') {
    return (
      <div className="setup-container" style={{ width: '320px', background: 'var(--bg-light)' }}>
        <div className="xhs-header" style={{ borderRadius: '0 0 var(--radius-xl) var(--radius-xl)' }}>
          <h1 style={{ fontSize: '20px' }}>欢迎使用 Rednote2Notion</h1>
          <p style={{ fontSize: '13px' }}>第一步：激活授权码</p>
        </div>
        <div className="setup-content" style={{ padding: '20px' }}>
          {/* 步骤指示器 */}
          <div className="step-indicator" style={{ 
            display: 'flex', 
            justifyContent: 'space-between', 
            marginBottom: '24px', 
            padding: '0 10px' 
          }}>
            <span style={{ fontSize: '12px', color: 'var(--primary-color)', fontWeight: 600 }}>1. 授权码</span>
            <span style={{ fontSize: '12px', color: 'var(--text-hint)' }}>2. Notion配置</span>
            <span style={{ fontSize: '12px', color: 'var(--text-hint)' }}>3. 开始使用</span>
          </div>
          
          {/* 授权码输入卡片 */}
          <div className="xhs-card glass-card" style={{ marginBottom: '16px' }}>
            <label style={{ 
              display: 'block', 
              fontSize: '13px', 
              fontWeight: 500, 
              color: 'var(--text-secondary)', 
              marginBottom: '8px' 
            }}>
              授权码
            </label>
            <input
              type="text"
              className="xhs-input"
              placeholder="请输入授权码"
              value={licenseCode}
              onChange={(e) => setLicenseCode(e.target.value)}
              style={{ marginBottom: '12px' }}
            />
            <button 
              className="xhs-btn xhs-btn-primary xhs-btn-block"
              onClick={handleActivateLicense}
              disabled={setupLoading}
            >
              {setupLoading ? '激活中...' : '激活授权码'}
            </button>
          </div>
          
          {/* 提示信息 */}
          <div style={{ 
            textAlign: 'center', 
            fontSize: '12px', 
            color: 'var(--text-hint)',
            marginTop: '16px'
          }}>
            <p>没有授权码？</p>
            <p style={{ marginTop: '4px' }}>
              <a 
                href="#" 
                onClick={(e) => { e.preventDefault(); showToast('请联系开发者获取授权码', 'info'); }}
                style={{ color: 'var(--primary-color)', textDecoration: 'none' }}
              >
                联系开发者获取
              </a>
            </p>
          </div>
        </div>
        
        {/* Toast提示 */}
        <Toast message={toast.message} type={toast.type} show={toast.show} />
      </div>
    );
  }

  // ========== 渲染Notion配置步骤 ==========
  if (currentStep === 'notion') {
    return (
      <div className="setup-container" style={{ width: '320px', background: 'var(--bg-light)' }}>
        <div className="xhs-header" style={{ borderRadius: '0 0 var(--radius-xl) var(--radius-xl)' }}>
          <h1 style={{ fontSize: '20px' }}>配置 Notion</h1>
          <p style={{ fontSize: '13px' }}>第二步：连接你的Notion数据库</p>
        </div>
        <div className="setup-content" style={{ padding: '20px' }}>
          {/* 步骤指示器 */}
          <div className="step-indicator" style={{ 
            display: 'flex', 
            justifyContent: 'space-between', 
            marginBottom: '24px', 
            padding: '0 10px' 
          }}>
            <span style={{ fontSize: '12px', color: 'var(--success-color)', fontWeight: 600 }}>✓ 授权码</span>
            <span style={{ fontSize: '12px', color: 'var(--primary-color)', fontWeight: 600 }}>2. Notion配置</span>
            <span style={{ fontSize: '12px', color: 'var(--text-hint)' }}>3. 开始使用</span>
          </div>
          
          {/* API Key输入 */}
          <div className="xhs-card glass-card" style={{ marginBottom: '12px' }}>
            <label style={{ 
              display: 'block', 
              fontSize: '13px', 
              fontWeight: 500, 
              color: 'var(--text-secondary)', 
              marginBottom: '8px' 
            }}>
              Notion API Key
            </label>
            <input
              type="password"
              className="xhs-input"
              placeholder="secret_..."
              value={notionConfig.apiKey}
              onChange={(e) => setNotionConfig({...notionConfig, apiKey: e.target.value})}
            />
          </div>
          
          {/* 数据库ID输入 */}
          <div className="xhs-card glass-card" style={{ marginBottom: '16px' }}>
            <label style={{ 
              display: 'block', 
              fontSize: '13px', 
              fontWeight: 500, 
              color: 'var(--text-secondary)', 
              marginBottom: '8px' 
            }}>
              数据库 ID
            </label>
            <input
              type="text"
              className="xhs-input"
              placeholder="32位数据库ID"
              value={notionConfig.databaseId}
              onChange={(e) => setNotionConfig({...notionConfig, databaseId: e.target.value})}
            />
          </div>
          
          {/* 完成按钮 */}
          <button 
            className="xhs-btn xhs-btn-primary xhs-btn-block"
            onClick={handleSaveNotionConfig}
            disabled={setupLoading}
            style={{ marginBottom: '16px' }}
          >
            {setupLoading ? '保存中...' : '完成配置'}
          </button>
          
          {/* 帮助链接 */}
          <div style={{ 
            textAlign: 'center', 
            fontSize: '12px', 
            color: 'var(--text-hint)'
          }}>
            <a 
              href="#" 
              onClick={(e) => { e.preventDefault(); showToast('请参考说明文档创建Notion集成', 'info'); }}
              style={{ color: 'var(--primary-color)', textDecoration: 'none' }}
            >
              如何获取API Key和数据库ID？
            </a>
          </div>
        </div>
        
        {/* Toast提示 */}
        <Toast message={toast.message} type={toast.type} show={toast.show} />
      </div>
    );
  }

  // ========== 渲染主界面 ==========
  return (
    <div style={{ width: '280px', background: 'var(--bg-light)' }}>
      {/* 小红书风格头部 */}
      <div className="xhs-header micro-glow" style={{ borderRadius: '0 0 var(--radius-lg) var(--radius-lg)' }}>
        <h1 style={{ fontSize: '18px' }}>Rednote2Notion</h1>
        <p style={{ fontSize: '12px' }}>小红书同步到Notion</p>
      </div>

      <div style={{ padding: '16px' }}>
        {/* 深色模式切换 */}
        <div style={{ 
          display: 'flex', 
          alignItems: 'center', 
          justifyContent: 'space-between',
          padding: '10px 14px',
          background: 'var(--bg-card)',
          borderRadius: 'var(--radius-md)',
          marginBottom: '12px',
          boxShadow: 'var(--shadow-sm)'
        }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
            <span style={{ fontSize: '16px' }}>{isDarkMode ? '🌙' : '☀️'}</span>
            <span style={{ fontSize: '13px', fontWeight: 500, color: 'var(--text-primary)' }}>
              {isDarkMode ? '深色模式' : '浅色模式'}
            </span>
          </div>
          <div 
            className={`dark-mode-switch ${isDarkMode ? 'active' : ''}`}
            onClick={toggleDarkMode}
            style={{ transform: 'scale(0.85)' }}
          />
        </div>

        {/* 授权状态卡片 */}
        {licenseInfo ? (
          <div className="xhs-card glass-card" style={{ marginBottom: '12px' }}>
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
              <div>
                <div style={{ fontSize: '13px', fontWeight: 500 }}>
                  版本：<span style={{ 
                    color: licenseInfo.licenseType === LicenseType.PERMANENT 
                      ? 'var(--success-color)' 
                      : 'var(--primary-color)' 
                  }}>
                    {formatLicenseType(licenseInfo.licenseType)}
                  </span>
                </div>
                <div style={{ fontSize: '11px', color: 'var(--text-hint)', marginTop: '4px' }}>
                  已同步 {licenseInfo.usedSyncCount} 篇
                  {licenseInfo.maxSyncCount !== Infinity && ` / ${licenseInfo.maxSyncCount} 篇`}
                </div>
              </div>
              <div style={{ 
                width: '40px', 
                height: '40px', 
                borderRadius: '50%',
                background: 'var(--primary-gradient)',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                fontSize: '18px',
                boxShadow: 'var(--shadow-primary)',
                animation: 'pulse 2s ease-in-out infinite'
              }}>
                ✨
              </div>
            </div>
            {!licenseInfo.isValid && (
              <div style={{ 
                marginTop: '10px', 
                padding: '8px 10px', 
                background: 'rgba(255, 77, 79, 0.1)', 
                borderRadius: 'var(--radius-sm)',
                fontSize: '12px',
                color: 'var(--error-color)'
              }}>
                ⚠️ {licenseInfo.errorMsg}
              </div>
            )}
          </div>
        ) : (
          <EmptyState
            icon="📋"
            title="加载授权信息"
            description="正在获取您的授权状态..."
          />
        )}

        {/* 状态信息 */}
        <div className="xhs-card glass-card" style={{ marginBottom: '12px' }}>
          <div style={{ display: 'flex', flexDirection: 'column', gap: '10px' }}>
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
              <span style={{ fontSize: '13px', color: 'var(--text-secondary)' }}>账号状态</span>
              {isLoggedIn ? (
                <span className="xhs-badge xhs-badge-success">已登录</span>
              ) : (
                <span className="xhs-badge xhs-badge-warning">未登录</span>
              )}
            </div>
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
              <span style={{ fontSize: '13px', color: 'var(--text-secondary)' }}>同步状态</span>
              {syncStatus ? (
                <span className="xhs-badge xhs-badge-primary">
                  <span className="animate-pulse" style={{ marginRight: '4px' }}>●</span>
                  运行中
                </span>
              ) : (
                <span style={{ fontSize: '12px', color: 'var(--text-hint)' }}>未运行</span>
              )}
            </div>
          </div>
        </div>

        {/* 操作按钮 - 添加涟漪效果 */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: '10px' }}>
          <button
            onClick={openSidePanel}
            className="xhs-btn xhs-btn-primary xhs-btn-block"
          >
            📥 打开同步面板
          </button>
          <button
            onClick={openOptionsPage}
            className="xhs-btn xhs-btn-secondary xhs-btn-block"
          >
            ⚙️ 全局设置
          </button>
        </div>

        {/* 快捷同步入口 */}
        {isLoggedIn && (
          <div style={{ 
            marginTop: '12px',
            padding: '12px',
            background: 'linear-gradient(135deg, rgba(255, 36, 66, 0.05) 0%, transparent 100%)',
            borderRadius: 'var(--radius-md)',
            border: '1px solid rgba(255, 36, 66, 0.1)'
          }}>
            <div style={{ fontSize: '11px', color: 'var(--text-hint)', marginBottom: '6px' }}>
              快速同步
            </div>
            <div style={{ display: 'flex', gap: '8px' }}>
              <button 
                className="xhs-btn xhs-btn-sm xhs-btn-outline"
                onClick={() => showToast('收藏同步已开启', 'success')}
                style={{ flex: 1 }}
              >
                ⭐ 收藏
              </button>
              <button 
                className="xhs-btn xhs-btn-sm xhs-btn-outline"
                onClick={() => showToast('点赞同步已开启', 'success')}
                style={{ flex: 1 }}
              >
                ❤️ 点赞
              </button>
              <button 
                className="xhs-btn xhs-btn-sm xhs-btn-outline"
                onClick={() => showToast('帖子同步已开启', 'success')}
                style={{ flex: 1 }}
              >
                📝 帖子
              </button>
            </div>
          </div>
        )}

        {/* 底部信息 */}
        <div style={{ 
          marginTop: '16px', 
          textAlign: 'center', 
          fontSize: '11px', 
          color: 'var(--text-hint)' 
        }}>
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '8px' }}>
            <span>❤️ 小红书</span>
            <span style={{ color: 'var(--primary-color)' }}>→</span>
            <span>📝 Notion</span>
          </div>
          <div style={{ marginTop: '4px', opacity: 0.7 }}>
            v2.2.0
          </div>
        </div>
      </div>

      {/* Toast提示 */}
      <Toast message={toast.message} type={toast.type} show={toast.show} />
    </div>
  );
};

export default Popup;

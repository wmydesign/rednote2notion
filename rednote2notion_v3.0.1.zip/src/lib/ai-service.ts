import OpenAI from 'openai';
import { AIProvider, AIModelConfig, AI_MODEL_PRESETS } from './types';
import type { RednoteNote, AIProcessTemplate, AIProcessResult } from './types';

// 预设分类标签（可自定义）
const DEFAULT_CATEGORIES = [
  '职场干货',
  '学习成长',
  '生活方式',
  '美食探店',
  '旅行攻略',
  '美妆护肤',
  '穿搭时尚',
  '家居好物',
  '科技数码',
  '财经理财',
  '情感心理',
  '健身运动',
  '母婴育儿',
  '兴趣爱好',
  '其他'
];

/**
 * 创建AI客户端（统一接口）
 * 支持 OpenAI 兼容接口的模型提供商
 */
export const createAIClient = (config: AIModelConfig) => {
  const preset = AI_MODEL_PRESETS[config.provider];
  
  return new OpenAI({
    apiKey: config.apiKey,
    baseURL: config.baseUrl || preset.baseUrl,
    dangerouslyAllowBrowser: true
  });
};

/**
 * 测试AI连接
 * @returns 测试结果信息
 */
export const testAIConnection = async (config: AIModelConfig): Promise<{ success: boolean; message: string }> => {
  if (!config.apiKey) {
    return { success: false, message: 'API Key 不能为空' };
  }

  try {
    const client = createAIClient(config);
    const model = config.model || AI_MODEL_PRESETS[config.provider].defaultModel;
    
    // 发送一个简单的测试请求
    const response = await client.chat.completions.create({
      model: model,
      messages: [
        { role: 'user', content: 'Hi' }
      ],
      max_tokens: 5
    });

    if (response.choices[0]?.message?.content) {
      return { success: true, message: '连接成功！' };
    } else {
      return { success: false, message: '响应格式异常' };
    }
  } catch (error: any) {
    // 根据不同错误类型返回友好提示
    if (error?.status === 401) {
      return { success: false, message: 'API Key 无效或已过期' };
    }
    if (error?.status === 403) {
      return { success: false, message: '无访问权限，请检查 API Key 权限设置' };
    }
    if (error?.status === 429) {
      return { success: false, message: '请求过于频繁，请稍后重试' };
    }
    if (error?.message?.includes('fetch failed') || error?.cause?.message?.includes('fetch failed')) {
      return { success: false, message: '网络连接失败，请检查网络或 API 地址' };
    }
    return { success: false, message: `连接失败: ${error?.message || '未知错误'}` };
  }
};

/**
 * AI智能分类小红书帖子（支持多模型）
 */
export const classifyNoteWithAI = async (
  config: AIModelConfig,
  note: RednoteNote,
  customCategories: string[] = DEFAULT_CATEGORIES
): Promise<string> => {
  if (!config.apiKey) throw new Error('API Key 未配置');
  if (!note.title && !note.desc) return '其他';

  const client = createAIClient(config);
  const model = config.model || AI_MODEL_PRESETS[config.provider].defaultModel;
  
  const prompt = `
你是一个专业的内容分类助手，需要根据小红书帖子的标题和正文，将其归类到最合适的分类中。
可选分类：${customCategories.join('、')}

帖子标题：${note.title || '无'}
帖子正文：${note.desc || '无'}
帖子标签：${note.tags.join('、') || '无'}

要求：
1. 只返回一个最匹配的分类名称，不要返回任何其他内容
2. 如果没有匹配的分类，返回"其他"
3. 严格使用提供的分类列表中的名称，不要自创分类
`;

  try {
    const response = await client.chat.completions.create({
      model: model,
      messages: [
        { role: 'system', content: '你是一个专业的内容分类助手，严格按照要求执行分类任务' },
        { role: 'user', content: prompt }
      ],
      temperature: 0.3,
      max_tokens: 20
    });

    const category = response.choices[0]?.message?.content?.trim() || '其他';
    return customCategories.includes(category) ? category : '其他';
  } catch (error) {
    console.error('AI分类失败', error);
    return '其他';
  }
};

/**
 * AI深度知识加工（支持多模型）
 */
export const processNoteWithAI = async (
  config: AIModelConfig,
  note: RednoteNote,
  template: AIProcessTemplate
): Promise<AIProcessResult> => {
  if (!config.apiKey) throw new Error('API Key 未配置');
  if (!template.enable) {
    return {
      fieldName: template.fieldName,
      content: ''
    };
  }

  const client = createAIClient(config);
  const model = config.model || AI_MODEL_PRESETS[config.provider].defaultModel;
  
  // 替换Prompt中的变量
  let prompt = template.prompt
    .replace(/{title}/g, note.title || '无')
    .replace(/{desc}/g, note.desc || '无')
    .replace(/{tags}/g, note.tags.join('、') || '无');

  // 补充OCR内容
  if (note.ocrResults && note.ocrResults.length > 0) {
    const ocrText = note.ocrResults.map(item => item.text).join('\n');
    prompt += `\n图片中的文字内容：${ocrText}`;
  }

  try {
    const response = await client.chat.completions.create({
      model: model,
      messages: [
        { role: 'system', content: '你是一个专业的知识整理助手，严格按照用户的要求处理内容，只输出处理后的结果，不要多余的解释和内容' },
        { role: 'user', content: prompt }
      ],
      temperature: 0.4,
      max_tokens: 2000
    });

    const content = response.choices[0]?.message?.content?.trim() || '';
    return {
      fieldName: template.fieldName,
      content
    };
  } catch (error: any) {
    console.error(`AI加工失败 [${template.name}]`, error);
    return {
      fieldName: template.fieldName,
      content: `加工失败：${error.message}`
    };
  }
};

/**
 * 批量执行AI加工模板
 */
export const batchProcessNoteWithAI = async (
  config: AIModelConfig,
  note: RednoteNote,
  templates: AIProcessTemplate[]
): Promise<AIProcessResult[]> => {
  const enableTemplates = templates.filter(t => t.enable);
  if (enableTemplates.length === 0) return [];

  const results: AIProcessResult[] = [];
  for (const template of enableTemplates) {
    const result = await processNoteWithAI(config, note, template);
    results.push(result);
    // 延迟避免API限流
    await new Promise(resolve => setTimeout(resolve, 200));
  }
  return results;
};

// 导出默认分类常量供外部使用
export { DEFAULT_CATEGORIES };

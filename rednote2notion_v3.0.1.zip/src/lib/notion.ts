import { Client } from '@notionhq/client';
import type { RednoteNote, AIProcessResult, DatabaseCompletenessResult, DatabaseCreateResult, LearningViewTemplate, SmartKnowledgeNote, RelationDatabaseConfig, AuthorInfo, TagInfo, AlbumInfo, RelationDatabaseResult, SmartKnowledgeStats, KnowledgeTopic, LearningStatus, LearningPriority } from './types';
import { isFullDatabase } from '@notionhq/client';

// 初始化Notion客户端
const createNotionClient = (apiKey: string) => {
  return new Client({
    auth: apiKey,
    // 新增：自动重试配置
    retryOptions: {
      maxRetries: 3,
      retryInterval: 1000,
    }
  });
};

// ==================== 学习场景字段配置 ====================

// 学习场景专属字段定义
export const LEARNING_FIELDS = {
  学习进度: {
    select: {
      options: [
        { name: '未开始', color: 'gray' },
        { name: '学习中', color: 'yellow' },
        { name: '已掌握', color: 'green' },
        { name: '需复习', color: 'orange' }
      ]
    }
  },
  学习优先级: {
    select: {
      options: [
        { name: '高', color: 'red' },
        { name: '中', color: 'yellow' },
        { name: '低', color: 'gray' }
      ]
    }
  },
  预计学习时长: { number: { format: 'number' } },
  实际学习时长: { number: { format: 'number' } },
  学习笔记: { rich_text: {} },
  复习日期: { date: {} },
  复习次数: { number: { format: 'number' } },
  知识领域: {
    select: {
      options: [
        { name: '编程', color: 'blue' },
        { name: '设计', color: 'pink' },
        { name: '职场', color: 'orange' },
        { name: '语言', color: 'green' },
        { name: '理财', color: 'purple' },
        { name: '生活技能', color: 'yellow' },
        { name: '其他', color: 'gray' }
      ]
    }
  },
  难度等级: {
    select: {
      options: [
        { name: '入门', color: 'green' },
        { name: '进阶', color: 'blue' },
        { name: '高级', color: 'purple' },
        { name: '专家', color: 'red' }
      ]
    }
  },
  学习类型: {
    select: {
      options: [
        { name: '教程', color: 'blue' },
        { name: '案例', color: 'green' },
        { name: '理论', color: 'purple' },
        { name: '工具', color: 'orange' },
        { name: '经验分享', color: 'pink' }
      ]
    }
  },
  是否已实践: { checkbox: {} },
  实践链接: { url: {} }
};

// 学习场景必需字段列表
export const LEARNING_REQUIRED_FIELDS = [
  '学习进度',
  '学习优先级',
  '预计学习时长',
  '实际学习时长',
  '学习笔记',
  '复习日期',
  '复习次数',
  '知识领域',
  '难度等级',
  '学习类型',
  '是否已实践',
  '实践链接'
];

/**
 * 检查并自动创建数据库缺失字段
 * @param apiKey Notion API Key
 * @param databaseId 数据库ID
 * @param fieldNames 需要检查的字段名列表
 * @param fieldType 字段类型，默认富文本
 */
export const ensureDatabaseFields = async (
  apiKey: string,
  databaseId: string,
  fieldConfigs: { name: string; type: any; options?: any[] }[]
) => {
  try {
    const notion = createNotionClient(apiKey);
    const database = await notion.databases.retrieve({ database_id: databaseId });
    
    if (!isFullDatabase(database)) return;
    const existingFields = Object.keys(database.properties);
    const propertiesToAdd: Record<string, any> = {};

    // 遍历需要创建的字段
    for (const config of fieldConfigs) {
      if (!existingFields.includes(config.name)) {
        propertiesToAdd[config.name] = { [config.type]: config.options || {} };
      }
    }

    // 有缺失字段则更新数据库
    if (Object.keys(propertiesToAdd).length > 0) {
      await notion.databases.update({
        database_id: databaseId,
        properties: propertiesToAdd
      });
      console.log('自动创建Notion缺失字段：', Object.keys(propertiesToAdd));
    }

  } catch (error) {
    console.error('检查/创建Notion字段失败', error);
  }
};

/**
 * 创建小红书同步专用数据库（V2.0全字段适配）
 * @param apiKey Notion API Key
 * @param pageId 父页面ID
 * @param customFields 自定义字段（AI加工模板）
 * @returns 数据库ID
 */
export const createNotionDatabase = async (
  apiKey: string,
  pageId: string,
  customFields: { name: string; type: any }[] = []
): Promise<string> => {
  const notion = createNotionClient(apiKey);
  
  // 基础字段配置
  const baseProperties: Record<string, any> = {
    标题: { title: {} },
    分类: { select: {} },
    所属专辑: { select: {} },
    发布时间: { date: {} },
    收藏时间: { date: {} },
    作者: { rich_text: {} },
    作者ID: { rich_text: {} },
    点赞数: { number: { format: 'number' } },
    收藏数: { number: { format: 'number' } },
    评论数: { number: { format: 'number' } },
    分享数: { number: { format: 'number' } },
    原文链接: { url: {} },
    笔记类型: { 
      select: { 
        options: [
          { name: '图文', color: 'blue' },
          { name: '视频', color: 'red' },
          { name: '合集', color: 'purple' },
          { name: '其他', color: 'gray' }
        ] 
      } 
    },
    封面图: { files: {} },
    内容摘要: { rich_text: {} },
    作者评论补充: { rich_text: {} },
    高赞评论: { rich_text: {} },
    标签: { multi_select: {} },
    同步时间: { date: {} },
    笔记ID: { rich_text: {} },
    同步状态: {
      select: {
        options: [
          { name: '已同步', color: 'green' },
          { name: '同步失败', color: 'red' },
          { name: '待同步', color: 'yellow' }
        ]
      }
    }
  };

  // 合并自定义字段
  customFields.forEach(field => {
    if (!baseProperties[field.name]) {
      baseProperties[field.name] = { [field.type]: {} };
    }
  });

  // 创建数据库
  const response = await notion.databases.create({
    parent: { type: 'page_id', page_id: pageId },
    title: [{ type: 'text', text: { content: '小红书收藏同步库' } }],
    properties: baseProperties
  });
  return response.id;
};

/**
 * 拆分超长文本为多个Notion块（解决Notion单块1000字符限制）
 * @param text 原始文本
 * @param maxLength 单块最大长度，默认900
 * @returns Notion块数组
 */
const splitTextToBlocks = (text: string, maxLength: number = 900): any[] => {
  if (!text || text.trim() === '') return [];
  
  const blocks: any[] = [];
  const textChunks = text.match(new RegExp(`.{1,${maxLength}}`, 'g')) || [];
  
  textChunks.forEach(chunk => {
    blocks.push({
      object: 'block',
      type: 'paragraph',
      paragraph: {
        rich_text: [{ type: 'text', text: { content: chunk } }]
      }
    });
  });
  
  return blocks;
};

/**
 * 写入单条小红书帖子到Notion数据库（V2.0全量适配+异常兜底）
 * @param apiKey Notion API Key
 * @param databaseId 数据库ID
 * @param note 小红书笔记数据
 * @param autoCreateField 是否自动创建缺失字段
 * @returns 页面ID
 */
export const writeNoteToNotion = async (
  apiKey: string,
  databaseId: string,
  note: RednoteNote,
  autoCreateField: boolean = true
): Promise<string> => {
  const notion = createNotionClient(apiKey);
  const now = new Date().toISOString();

  // ==================== 1. 自动创建AI加工字段 ====================
  if (autoCreateField && note.aiProcessResults && note.aiProcessResults.length > 0) {
    const fieldConfigs = note.aiProcessResults.map(result => ({
      name: result.fieldName,
      type: 'rich_text'
    }));
    await ensureDatabaseFields(apiKey, databaseId, fieldConfigs);
  }

  // ==================== 2. 构建数据库属性 ====================
  const properties: any = {
    标题: {
      title: [{ type: 'text', text: { content: note.title?.trim() || '无标题' } }]
    },
    分类: {
      select: { name: note.aiCategory?.trim() || '未分类' }
    },
    发布时间: {
      date: { start: new Date(note.publishTime).toISOString() }
    },
    作者: {
      rich_text: [{ type: 'text', text: { content: note.authorName?.trim() || '未知作者' } }]
    },
    作者ID: {
      rich_text: [{ type: 'text', text: { content: note.authorId || '未知ID' } }]
    },
    点赞数: {
      number: note.likeCount || 0
    },
    收藏数: {
      number: note.collectCount || 0
    },
    评论数: {
      number: note.commentCount || 0
    },
    分享数: {
      number: note.shareCount || 0
    },
    原文链接: {
      url: note.noteUrl
    },
    笔记类型: {
      select: { 
        name: note.noteType === 'video' ? '视频' : 
              note.noteType === 'image' ? '图文' : '其他' 
      }
    },
    标签: {
      multi_select: note.tags?.map(tag => ({ name: tag.trim().slice(0, 90) })).filter(tag => tag.name) || []
    },
    同步时间: {
      date: { start: now }
    },
    笔记ID: {
      rich_text: [{ type: 'text', text: { content: note.id } }]
    },
    同步状态: {
      select: { name: '已同步' }
    }
  };

  // 可选字段处理（无内容则不写入，避免字段报错）
  if (note.albumName) {
    properties.所属专辑 = { select: { name: note.albumName.trim().slice(0, 90) } };
  }
  if (note.collectTime) {
    properties.收藏时间 = { date: { start: new Date(note.collectTime).toISOString() } };
  }
  if (note.coverUrl) {
    try {
      properties.封面图 = {
        files: [{ type: 'external', name: 'cover', external: { url: note.coverUrl } }]
      };
    } catch (e) {
      console.warn('封面图URL无效，跳过', note.coverUrl);
    }
  }
  if (note.desc) {
    properties.内容摘要 = {
      rich_text: [{ type: 'text', text: { content: note.desc.trim().slice(0, 2000) } }]
    };
  }
  if (note.authorComments && note.authorComments.length > 0) {
    const authorCommentText = note.authorComments
      .map(item => `[${new Date(item.publishTime).toLocaleString()}]：${item.content}`)
      .join('\n\n')
      .slice(0, 2000);
    properties.作者评论补充 = {
      rich_text: [{ type: 'text', text: { content: authorCommentText } }]
    };
  }
  if (note.comments && note.comments.length > 0) {
    const commentText = note.comments
      .map(item => `@${item.authorName}（点赞${item.likeCount}）：${item.content}`)
      .join('\n\n')
      .slice(0, 2000);
    properties.高赞评论 = {
      rich_text: [{ type: 'text', text: { content: commentText } }]
    };
  }

  // AI加工结果写入属性
  if (note.aiProcessResults && note.aiProcessResults.length > 0) {
    note.aiProcessResults.forEach(result => {
      if (result.fieldName && result.content) {
        properties[result.fieldName] = {
          rich_text: [{ type: 'text', text: { content: result.content.slice(0, 2000) } }]
        };
      }
    });
  }

  // ==================== 3. 构建页面内容块 ====================
  const children: any[] = [];

  // 笔记标题
  children.push({
    object: 'block',
    type: 'heading_1',
    heading_1: {
      rich_text: [{ type: 'text', text: { content: note.title?.trim() || '无标题' } }]
    }
  });

  // 基础信息栏
  children.push({
    object: 'block',
    type: 'callout',
    callout: {
      icon: { type: 'emoji', emoji: '📌' },
      color: 'gray_background',
      rich_text: [
        { type: 'text', text: { content: `作者：${note.authorName} | 发布时间：${new Date(note.publishTime).toLocaleString()}\n` } },
        { type: 'text', text: { content: `点赞：${note.likeCount} | 收藏：${note.collectCount} | 评论：${note.commentCount}\n` } },
        { type: 'text', text: { content: `原文链接：`, link: { url: note.noteUrl } } }
      ]
    }
  });

  // 笔记正文
  if (note.desc) {
    children.push({
      object: 'block',
      type: 'heading_2',
      heading_2: {
        rich_text: [{ type: 'text', text: { content: '📝 笔记正文' } }]
      }
    });
    // 超长正文拆分
    children.push(...splitTextToBlocks(note.desc));
  }

  // 所有图片插入（使用 Toggle 折叠，优化长内容展示）
  if (note.allImages && note.allImages.length > 0) {
    const imageBlocks: any[] = [];
    for (const imageUrl of note.allImages) {
      try {
        imageBlocks.push({
          object: 'block',
          type: 'image',
          image: {
            type: 'external',
            external: { url: imageUrl }
          }
        });
      } catch (e) {
        console.warn('图片URL无效，跳过', imageUrl);
      }
    }
    
    // 使用 Toggle 折叠图片区
    children.push({
      object: 'block',
      type: 'toggle',
      toggle: {
        rich_text: [{ 
          type: 'text', 
          text: { content: `🖼️ 查看全部 ${note.allImages.length} 张笔记原图` } 
        }],
        children: imageBlocks
      }
    });
  }


  // 作者补充评论（使用 Toggle 折叠）
  if (note.authorComments && note.authorComments.length > 0) {
    const authorCommentText = note.authorComments
      .map(item => `[${new Date(item.publishTime).toLocaleString()}]：${item.content}`)
      .join('\n\n');
    
    children.push({
      object: 'block',
      type: 'toggle',
      toggle: {
        rich_text: [{ 
          type: 'text', 
          text: { content: `💬 作者补充评论 (${note.authorComments.length}条)` } 
        }],
        children: splitTextToBlocks(authorCommentText)
      }
    });
  }

  // 高赞评论（使用 Toggle 折叠）
  if (note.comments && note.comments.length > 0) {
    const commentText = note.comments
      .map(item => `@${item.authorName}（点赞${item.likeCount}）：\n${item.content}`)
      .join('\n\n');
    
    children.push({
      object: 'block',
      type: 'toggle',
      toggle: {
        rich_text: [{ 
          type: 'text', 
          text: { content: `🔥 高赞评论 (${note.comments.length}条)` } 
        }],
        children: splitTextToBlocks(commentText)
      }
    });
  }

  // AI深度加工内容
  if (note.aiProcessResults && note.aiProcessResults.length > 0) {
    children.push({
      object: 'block',
      type: 'heading_2',
      heading_2: {
        rich_text: [{ type: 'text', text: { content: '🤖 AI深度加工内容' } }]
      }
    });
    note.aiProcessResults.forEach(result => {
      children.push({
        object: 'block',
        type: 'heading_3',
        heading_3: {
          rich_text: [{ type: 'text', text: { content: result.fieldName } }]
        }
      });
      children.push(...splitTextToBlocks(result.content));
    });
  }

  // 原文链接兜底
  children.push({
    object: 'block',
    type: 'divider',
    divider: {}
  });
  children.push({
    object: 'block',
    type: 'paragraph',
    paragraph: {
      rich_text: [{ type: 'text', text: { content: '🔗 小红书原文链接：', link: { url: note.noteUrl } } }]
    }
  });

  // ==================== 4. 分块写入Notion（解决100块限制） ====================
  const MAX_BLOCKS_PER_REQUEST = 100;
  let pageId = '';

  // 第一步：创建页面基础信息（添加封面图）
  const firstBatchBlocks = children.slice(0, MAX_BLOCKS_PER_REQUEST);
  const remainingBlocks = children.slice(MAX_BLOCKS_PER_REQUEST);

  // 设置页面封面：优先使用第一张图片，其次使用封面图
  const coverImage = note.allImages?.[0] || note.coverUrl;
  
  const pageResponse = await notion.pages.create({
    parent: { type: 'database_id', database_id: databaseId },
    // 添加封面图
    cover: coverImage ? {
      type: 'external',
      external: { url: coverImage }
    } : undefined,
    // 添加页面图标
    icon: { 
      type: 'emoji', 
      emoji: note.noteType === 'video' ? '🎬' : '📄' 
    },
    properties,
    children: firstBatchBlocks
  });
  pageId = pageResponse.id;

  // 第二步：分批写入剩余内容块
  if (remainingBlocks.length > 0) {
    for (let i = 0; i < remainingBlocks.length; i += MAX_BLOCKS_PER_REQUEST) {
      const batch = remainingBlocks.slice(i, i + MAX_BLOCKS_PER_REQUEST);
      await notion.blocks.children.append({
        block_id: pageId,
        children: batch
      });
      // 限流延迟
      await new Promise(resolve => setTimeout(resolve, 300));
    }
  }

  return pageId;
};

/**
 * 检查帖子是否已同步到Notion（优化：支持多字段查重）
 * @param apiKey Notion API Key
 * @param databaseId 数据库ID
 * @param noteId 小红书帖子ID
 * @returns 是否已同步
 */
export const checkNoteIsSynced = async (
  apiKey: string,
  databaseId: string,
  noteId: string
): Promise<boolean> => {
  try {
    const notion = createNotionClient(apiKey);
    const response = await notion.databases.query({
      database_id: databaseId,
      filter: {
        or: [
          { property: '原文链接', url: { contains: noteId } },
          { property: '笔记ID', rich_text: { equals: noteId } }
        ]
      },
      page_size: 1
    });
    return response.results.length > 0;
  } catch (error) {
    console.error('检查同步状态失败', error);
    // 异常时返回false，重新同步，避免漏同步
    return false;
  }
};

/**
 * 批量更新笔记同步状态
 * @param apiKey Notion API Key
 * @param databaseId 数据库ID
 * @param pageId 页面ID
 * @param status 同步状态
 * @param errorMsg 错误信息
 */
export const updateNoteSyncStatus = async (
  apiKey: string,
  databaseId: string,
  pageId: string,
  status: '已同步' | '同步失败' | '待同步',
  errorMsg?: string
) => {
  try {
    const notion = createNotionClient(apiKey);
    const properties: any = {
      同步状态: { select: { name: status } }
    };
    if (errorMsg) {
      properties.同步错误信息 = { rich_text: [{ type: 'text', text: { content: errorMsg.slice(0, 2000) } }] };
    }
    await notion.pages.update({
      page_id: pageId,
      properties
    });
  } catch (error) {
    console.error('更新同步状态失败', error);
  }
};

/**
 * 一键创建完整的小红书同步数据库（含学习场景支持）
 * @param apiKey Notion API Key
 * @param pageId 父页面ID
 * @param enableLearningMode 是否启用学习模式，默认false
 * @returns 数据库ID和URL
 */
export const createCompleteDatabase = async (
  apiKey: string,
  pageId: string,
  enableLearningMode: boolean = false
): Promise<DatabaseCreateResult> => {
  const notion = createNotionClient(apiKey);
  
  // 完整的数据库字段定义（含15种分类、3种公式、阅读状态等）
  const properties: Record<string, any> = {
    // 主键字段
    标题: { title: {} },
    
    // 分类字段（15种分类）
    分类: { 
      select: { 
        options: [
          { name: '职场干货', color: 'blue' },
          { name: '学习成长', color: 'green' },
          { name: '生活方式', color: 'pink' },
          { name: '美食探店', color: 'orange' },
          { name: '旅行攻略', color: 'yellow' },
          { name: '美妆护肤', color: 'red' },
          { name: '穿搭时尚', color: 'purple' },
          { name: '家居好物', color: 'brown' },
          { name: '科技数码', color: 'gray' },
          { name: '财经理财', color: 'default' },
          { name: '情感心理', color: 'pink' },
          { name: '健身运动', color: 'green' },
          { name: '母婴育儿', color: 'blue' },
          { name: '兴趣爱好', color: 'purple' },
          { name: '其他', color: 'gray' }
        ]
      }
    },
    
    // 作者信息
    作者: { rich_text: {} },
    作者ID: { rich_text: {} },
    
    // 时间字段
    发布时间: { date: {} },
    收藏时间: { date: {} },
    同步时间: { date: {} },
    
    // 互动数据
    点赞数: { number: { format: 'number' } },
    收藏数: { number: { format: 'number' } },
    评论数: { number: { format: 'number' } },
    分享数: { number: { format: 'number' } },
    
    // 公式字段（自动计算）
    互动率: {
      formula: {
        expression: 'if(prop("点赞数") + prop("收藏数") + prop("评论数") > 0, round((prop("点赞数") + prop("收藏数") * 2 + prop("评论数") * 3) / 100) / 10, 0)'
      }
    },
    热度指数: {
      formula: {
        expression: 'round(prop("点赞数") * 0.3 + prop("收藏数") * 0.5 + prop("评论数") * 0.2)'
      }
    },
    是否爆款: {
      formula: {
        expression: 'if(prop("点赞数") + prop("收藏数") > 10000, "🔥爆款", if(prop("点赞数") + prop("收藏数") > 5000, "⭐优质", "📄普通"))'
      }
    },
    
    // 内容信息
    原文链接: { url: {} },
    笔记类型: { 
      select: { 
        options: [
          { name: '图文', color: 'blue' },
          { name: '视频', color: 'red' },
          { name: '合集', color: 'purple' },
          { name: '其他', color: 'gray' }
        ]
      }
    },
    封面图: { files: {} },
    内容摘要: { rich_text: {} },
    标签: { multi_select: {} },
    
    // 管理字段
    笔记ID: { rich_text: {} },
    所属专辑: { select: {} },
    同步状态: {
      select: {
        options: [
          { name: '已同步', color: 'green' },
          { name: '同步失败', color: 'red' },
          { name: '待同步', color: 'yellow' }
        ]
      }
    },
    阅读状态: {
      select: {
        options: [
          { name: '待阅读', color: 'yellow' },
          { name: '已阅读', color: 'green' },
          { name: '精读', color: 'blue' },
          { name: '收藏备查', color: 'gray' }
        ]
      }
    },
    重要程度: {
      select: {
        options: [
          { name: '⭐⭐⭐ 重要', color: 'red' },
          { name: '⭐⭐ 一般', color: 'yellow' },
          { name: '⭐ 参考', color: 'gray' }
        ]
      }
    }
  };

  // 如果启用学习模式，添加学习场景专属字段
  if (enableLearningMode) {
    Object.assign(properties, LEARNING_FIELDS);
    
    // 添加学习进度统计公式
    properties.学习统计 = {
      formula: {
        expression: 'if(prop("学习进度") == "已掌握", "🎉", if(prop("学习进度") == "需复习", "📝", if(prop("学习进度") == "学习中", "📖", "⏳")))'
      }
    };
  }
  
  // 创建数据库
  const databaseTitle = enableLearningMode ? '📚 小红书学习库' : '📚 小红书收藏库';
  const databaseDescription = enableLearningMode 
    ? '小红书收藏同步 + 学习进度管理，支持按知识领域、复习计划追踪学习成果'
    : '自动同步小红书收藏、点赞、发布的笔记，支持AI智能分类';
    
  const database = await notion.databases.create({
    parent: { type: 'page_id', page_id: pageId },
    title: [{ type: 'text', text: { content: databaseTitle } }],
    description: [{ type: 'text', text: { content: databaseDescription } }],
    properties
  });
  
  console.log(`✅ 数据库创建成功: ${database.id} (学习模式: ${enableLearningMode})`);
  
  return {
    databaseId: database.id,
    databaseUrl: database.url
  };
};

/**
 * 获取用户的所有Notion页面列表
 * @param apiKey Notion API Key
 * @returns 页面列表
 */
export const getNotionPages = async (apiKey: string): Promise<NotionPage[]> => {
  const notion = createNotionClient(apiKey);
  
  const response = await notion.search({
    filter: {
      property: 'object',
      value: 'page'
    },
    page_size: 50
  });
  
  return response.results.map((page: any) => ({
    id: page.id,
    title: page.properties?.title?.title?.[0]?.plain_text || 
           page.properties?.Name?.title?.[0]?.plain_text ||
           '无标题页面',
    url: page.url,
    icon: page.icon?.emoji || '📄'
  }));
};

/**
 * 检测数据库是否已配置完整（支持学习场景字段检测）
 * @param apiKey Notion API Key
 * @param databaseId 数据库ID
 * @returns 完整性检查结果
 */
export const checkDatabaseCompleteness = async (
  apiKey: string,
  databaseId: string
): Promise<DatabaseCompletenessResult> => {
  const notion = createNotionClient(apiKey);
  
  try {
    const database = await notion.databases.retrieve({ database_id: databaseId });
    const existingFields = Object.keys(database.properties);
    
    // 基础必需字段
    const requiredFields = [
      '标题', '分类', '作者', '发布时间', '收藏时间',
      '点赞数', '收藏数', '评论数', '原文链接', '笔记类型',
      '标签', '同步状态', '阅读状态'
    ];
    
    // 学习场景必需字段
    const missingLearningFields = LEARNING_REQUIRED_FIELDS.filter(field => !existingFields.includes(field));
    
    const missingFields = requiredFields.filter(field => !existingFields.includes(field));
    
    return {
      isComplete: missingFields.length === 0,
      missingFields,
      missingLearningFields,
      isLearningMode: missingLearningFields.length === 0 && existingFields.includes('学习进度')
    };
  } catch (error) {
    return {
      isComplete: false,
      missingFields: ['数据库不存在或无权限访问'],
      missingLearningFields: [],
      isLearningMode: false
    };
  }
};

/**
 * 为现有数据库补齐缺失字段（支持学习场景）
 * @param apiKey Notion API Key
 * @param databaseId 数据库ID
 * @param includeLearningFields 是否包含学习场景字段
 */
export const completeDatabaseFields = async (
  apiKey: string,
  databaseId: string,
  includeLearningFields: boolean = false
): Promise<void> => {
  const notion = createNotionClient(apiKey);
  
  const fieldDefinitions: Record<string, any> = {
    分类: { 
      select: { 
        options: [
          { name: '职场干货', color: 'blue' },
          { name: '学习成长', color: 'green' },
          { name: '其他', color: 'gray' }
        ]
      }
    },
    作者: { rich_text: {} },
    发布时间: { date: {} },
    收藏时间: { date: {} },
    点赞数: { number: { format: 'number' } },
    收藏数: { number: { format: 'number' } },
    评论数: { number: { format: 'number' } },
    原文链接: { url: {} },
    笔记类型: { 
      select: { 
        options: [
          { name: '图文', color: 'blue' },
          { name: '视频', color: 'red' },
          { name: '其他', color: 'gray' }
        ]
      }
    },
    标签: { multi_select: {} },
    同步状态: { 
      select: {
        options: [
          { name: '已同步', color: 'green' },
          { name: '同步失败', color: 'red' },
          { name: '待同步', color: 'yellow' }
        ]
      }
    },
    阅读状态: { 
      select: {
        options: [
          { name: '待阅读', color: 'yellow' },
          { name: '已阅读', color: 'green' },
          { name: '收藏备查', color: 'gray' }
        ]
      }
    }
  };

  // 如果包含学习字段，合并学习字段定义
  if (includeLearningFields) {
    Object.assign(fieldDefinitions, LEARNING_FIELDS);
  }
  
  // 获取现有字段
  const database = await notion.databases.retrieve({ database_id: databaseId });
  const existingFields = Object.keys(database.properties);
  
  const propertiesToAdd: Record<string, any> = {};
  Object.keys(fieldDefinitions).forEach(field => {
    if (!existingFields.includes(field)) {
      propertiesToAdd[field] = fieldDefinitions[field];
    }
  });
  
  if (Object.keys(propertiesToAdd).length > 0) {
    await notion.databases.update({
      database_id: databaseId,
      properties: propertiesToAdd
    });
    console.log('已补齐缺失字段:', Object.keys(propertiesToAdd));
  }
};

/**
 * 学习场景视图模板配置
 */
export const LEARNING_VIEW_TEMPLATES: LearningViewTemplate[] = [
  {
    id: 'progress-board',
    name: '按学习进度',
    icon: '📚',
    description: '看板视图，按学习进度分组',
    viewType: 'board',
    config: {
      groupProperty: '学习进度'
    },
    usage: '帮助用户直观了解所有内容的学习状态：哪些还没开始、哪些正在学、哪些已经掌握、哪些需要复习'
  },
  {
    id: 'domain-board',
    name: '按知识领域',
    icon: '🎯',
    description: '看板视图，按知识领域分组',
    viewType: 'board',
    config: {
      groupProperty: '知识领域'
    },
    usage: '按领域归类内容，方便系统化学习：编程、设计、职场等一目了然'
  },
  {
    id: 'review-calendar',
    name: '复习计划',
    icon: '📅',
    description: '日历视图，按复习日期显示',
    viewType: 'calendar',
    config: {
      dateProperty: '复习日期'
    },
    usage: '设置复习日期，帮助制定周期性复习计划，防止遗忘'
  },
  {
    id: 'pending-queue',
    name: '待学习队列',
    icon: '⏰',
    description: '表格视图，筛选未开始的内容',
    viewType: 'table',
    config: {
      filters: [
        { property: '学习进度', condition: 'equals', value: '未开始' }
      ],
      sorts: [
        { property: '学习优先级', direction: 'descending' }
      ]
    },
    usage: '快速找到下一项要学习的内容，按优先级排序，提高学习效率'
  },
  {
    id: 'mastered-gallery',
    name: '学习精华库',
    icon: '⭐',
    description: '画廊视图，显示已掌握的内容',
    viewType: 'gallery',
    config: {
      coverProperty: '封面图',
      filters: [
        { property: '学习进度', condition: 'equals', value: '已掌握' }
      ]
    },
    usage: '回顾学过的内容精华，以封面图形式展示学习成果，激励持续学习'
  }
];

/**
 * 配置数据库视图指南（Notion API限制：无法直接创建视图，提供操作指引）
 * @param includeLearningViews 是否包含学习场景视图
 * 返回视图创建提示信息
 */
export const getViewConfigurationGuide = (includeLearningViews: boolean = false): Record<string, { name: string; steps: string[]; icon: string; usage: string }> => {
  const baseViews = {
    calendar: {
      name: '📅 日历视图',
      icon: '📅',
      steps: [
        '1. 点击数据库右上角的"+ 添加视图"',
        '2. 输入视图名称：日历视图',
        '3. 选择视图类型：日历',
        '4. 选择日期属性：发布时间',
        '5. 点击创建'
      ],
      usage: '按发布时间展示内容，便于了解内容的时间分布'
    },
    board: {
      name: '📊 看板视图',
      icon: '📊',
      steps: [
        '1. 点击数据库右上角的"+ 添加视图"',
        '2. 输入视图名称：分类看板',
        '3. 选择视图类型：看板',
        '4. 选择分组属性：分类',
        '5. 点击创建'
      ],
      usage: '按分类分组展示，便于按主题浏览内容'
    },
    gallery: {
      name: '🖼️ 画廊视图',
      icon: '🖼️',
      steps: [
        '1. 点击数据库右上角的"+ 添加视图"',
        '2. 输入视图名称：封面画廊',
        '3. 选择视图类型：画廊',
        '4. 设置卡片预览：封面图',
        '5. 点击创建'
      ],
      usage: '以封面图为主展示内容，直观浏览视觉效果'
    },
    timeline: {
      name: '📋 时间轴视图',
      icon: '📋',
      steps: [
        '1. 点击数据库右上角的"+ 添加视图"',
        '2. 输入视图名称：时间轴',
        '3. 选择视图类型：时间轴',
        '4. 选择日期属性：收藏时间',
        '5. 点击创建'
      ],
      usage: '按收藏时间展示内容，了解内容收集的时间线'
    }
  };

  // 如果需要包含学习场景视图
  if (includeLearningViews) {
    return {
      ...baseViews,
      'learning-progress-board': {
        name: '📚 学习进度看板',
        icon: '📚',
        steps: [
          '1. 点击数据库右上角的"+ 添加视图"',
          '2. 输入视图名称：学习进度',
          '3. 选择视图类型：看板',
          '4. 选择分组属性：学习进度',
          '5. 分组将自动显示：未开始 | 学习中 | 已掌握 | 需复习'
        ],
        usage: '帮助用户直观了解所有内容的学习状态，快速找到需要关注的条目'
      },
      'learning-domain-board': {
        name: '🎯 知识领域看板',
        icon: '🎯',
        steps: [
          '1. 点击数据库右上角的"+ 添加视图"',
          '2. 输入视图名称：知识领域',
          '3. 选择视图类型：看板',
          '4. 选择分组属性：知识领域',
          '5. 分组将自动显示：编程 | 设计 | 职场 | 语言 | 理财 | 生活技能'
        ],
        usage: '按领域归类内容，方便系统化学习，构建完整的知识体系'
      },
      'learning-review-calendar': {
        name: '📝 复习日历',
        icon: '📅',
        steps: [
          '1. 点击数据库右上角的"+ 添加视图"',
          '2. 输入视图名称：复习计划',
          '3. 选择视图类型：日历',
          '4. 选择日期属性：复习日期',
          '5. 点击创建'
        ],
        usage: '设置复习日期后，自动在日历上显示复习任务，帮助制定周期性复习计划'
      },
      'learning-pending-table': {
        name: '⏰ 待学习队列',
        icon: '⏰',
        steps: [
          '1. 点击数据库右上角的"+ 添加视图"',
          '2. 输入视图名称：待学习',
          '3. 选择视图类型：表格',
          '4. 点击筛选器 → 添加筛选条件',
          '5. 设置：学习进度 = 未开始，按学习优先级降序排列'
        ],
        usage: '快速找到下一项要学习的内容，按优先级排序，提高学习效率'
      },
      'learning-mastered-gallery': {
        name: '⭐ 学习精华库',
        icon: '⭐',
        steps: [
          '1. 点击数据库右上角的"+ 添加视图"',
          '2. 输入视图名称：精华库',
          '3. 选择视图类型：画廊',
          '4. 设置卡片预览：封面图',
          '5. 点击筛选器 → 添加筛选条件：学习进度 = 已掌握'
        ],
        usage: '以封面图形式展示已掌握的内容，回顾学习成果，激励持续学习'
      }
    };
  }

  return baseViews;
};

/**
 * 获取数据库中的学习统计信息
 * @param apiKey Notion API Key
 * @param databaseId 数据库ID
 * @returns 学习统计数据
 */
export const getLearningStats = async (
  apiKey: string,
  databaseId: string
): Promise<{
  total: number;
  byProgress: Record<string, number>;
  byDomain: Record<string, number>;
  byDifficulty: Record<string, number>;
  totalEstimatedMinutes: number;
  totalActualMinutes: number;
}> => {
  const notion = createNotionClient(apiKey);
  
  try {
    // 获取所有页面
    const response = await notion.databases.query({
      database_id: databaseId,
      page_size: 100
    });

    const stats = {
      total: response.results.length,
      byProgress: {
        '未开始': 0,
        '学习中': 0,
        '已掌握': 0,
        '需复习': 0
      } as Record<string, number>,
      byDomain: {} as Record<string, number>,
      byDifficulty: {} as Record<string, number>,
      totalEstimatedMinutes: 0,
      totalActualMinutes: 0
    };

    for (const page of response.results) {
      const props = (page as any).properties;
      
      // 统计学习进度
      if (props['学习进度']?.select?.name) {
        const progress = props['学习进度'].select.name;
        stats.byProgress[progress] = (stats.byProgress[progress] || 0) + 1;
      }
      
      // 统计知识领域
      if (props['知识领域']?.select?.name) {
        const domain = props['知识领域'].select.name;
        stats.byDomain[domain] = (stats.byDomain[domain] || 0) + 1;
      }
      
      // 统计难度等级
      if (props['难度等级']?.select?.name) {
        const difficulty = props['难度等级'].select.name;
        stats.byDifficulty[difficulty] = (stats.byDifficulty[difficulty] || 0) + 1;
      }
      
      // 累加学习时长
      if (props['预计学习时长']?.number) {
        stats.totalEstimatedMinutes += props['预计学习时长'].number;
      }
      if (props['实际学习时长']?.number) {
        stats.totalActualMinutes += props['实际学习时长'].number;
      }
    }

    return stats;
  } catch (error) {
    console.error('获取学习统计失败', error);
    return {
      total: 0,
      byProgress: { '未开始': 0, '学习中': 0, '已掌握': 0, '需复习': 0 },
      byDomain: {},
      byDifficulty: {},
      totalEstimatedMinutes: 0,
      totalActualMinutes: 0
    };
  }
};

/**
 * 创建智能知识库数据库
 * 整合四个方案：主题归类 + 智能标签 + 内容索引 + 学习路径
 * @param apiKey Notion API Key
 * @param pageId 父页面ID
 * @returns 数据库ID和URL
 */
export const createSmartKnowledgeDatabase = async (
  apiKey: string,
  pageId: string
): Promise<DatabaseCreateResult> => {
  const notion = createNotionClient(apiKey);
  
  const properties: Record<string, any> = {
    // === 基础信息字段 ===
    标题: { title: {} },
    作者: { rich_text: {} },
    发布时间: { date: {} },
    收藏时间: { date: {} },
    原文链接: { url: {} },
    笔记类型: { 
      select: { 
        options: [
          { name: '图文', color: 'blue' },
          { name: '视频', color: 'red' }
        ]
      }
    },
    封面图: { files: {} },
    
    // === 主题归档（AI自动） ===
    知识主题: {
      select: {
        options: [
          { name: '编程开发', color: 'blue' },
          { name: '设计美学', color: 'pink' },
          { name: '理财投资', color: 'green' },
          { name: '职场成长', color: 'yellow' },
          { name: '健康生活', color: 'orange' },
          { name: '语言学习', color: 'purple' },
          { name: '效率工具', color: 'gray' },
          { name: '兴趣爱好', color: 'brown' },
          { name: '其他', color: 'default' }
        ]
      }
    },
    子主题: { rich_text: {} },
    
    // === 智能标签 ===
    AI标签: { multi_select: {} },
    用户标签: { multi_select: {} },
    原始标签: { multi_select: {} },
    
    // === 内容索引（AI生成） ===
    一句话摘要: { rich_text: {} },
    关键词: { multi_select: {} },
    适用场景: { rich_text: {} },
    
    // === 互动数据 ===
    点赞数: { number: { format: 'number' } },
    收藏数: { number: { format: 'number' } },
    评论数: { number: { format: 'number' } },
    
    // === 公式字段 ===
    互动率: {
      formula: {
        expression: 'if(prop("点赞数") + prop("收藏数") + prop("评论数") > 0, round((prop("点赞数") + prop("收藏数") * 2 + prop("评论数") * 3) / 10) / 10, 0)'
      }
    },
    是否爆款: {
      formula: {
        expression: 'if(prop("点赞数") + prop("收藏数") > 10000, "🔥爆款", if(prop("点赞数") + prop("收藏数") > 5000, "⭐优质", "📄普通"))'
      }
    },
    
    // === 学习管理（用户设置） ===
    学习状态: {
      select: {
        options: [
          { name: '未学', color: 'gray' },
          { name: '学习中', color: 'blue' },
          { name: '已掌握', color: 'green' },
          { name: '待复习', color: 'yellow' }
        ]
      }
    },
    学习优先级: {
      select: {
        options: [
          { name: '高', color: 'red' },
          { name: '中', color: 'yellow' },
          { name: '低', color: 'gray' }
        ]
      }
    },
    学习笔记: { rich_text: {} },
    
    // === 路径关联 ===
    相关笔记: { relation: {} },
    学习路径: { rich_text: {} },
    
    // === 管理字段 ===
    笔记ID: { rich_text: {} },
    同步状态: {
      select: {
        options: [
          { name: '已同步', color: 'green' },
          { name: '同步失败', color: 'red' },
          { name: '待同步', color: 'yellow' }
        ]
      }
    },
    同步时间: { date: {} }
  };
  
  const database = await notion.databases.create({
    parent: { type: 'page_id', page_id: pageId },
    title: [{ type: 'text', text: { content: '📚 智能知识库' } }],
    description: [{ 
      type: 'text', 
      text: { content: 'AI智能分析 + 主题归档 + 学习管理 | 让收藏变成知识' } 
    }],
    properties
  });
  
  return {
    databaseId: database.id,
    databaseUrl: database.url
  };
};

/**
 * 写入智能知识库笔记到Notion
 * @param apiKey Notion API Key
 * @param databaseId 数据库ID
 * @param note 智能知识库笔记数据
 * @param analysisResult AI分析结果
 * @returns 页面ID
 */
export const writeSmartKnowledgeNote = async (
  apiKey: string,
  databaseId: string,
  note: SmartKnowledgeNote,
  analysisResult?: AIAnalysisResult
): Promise<string> => {
  const notion = createNotionClient(apiKey);
  const now = new Date().toISOString();

  // 构建数据库属性
  const properties: any = {
    标题: {
      title: [{ type: 'text', text: { content: note.title?.trim() || '无标题' } }]
    },
    作者: {
      rich_text: [{ type: 'text', text: { content: note.authorName?.trim() || '未知作者' } }]
    },
    发布时间: {
      date: { start: new Date(note.publishTime).toISOString() }
    },
    收藏时间: {
      date: { start: now }
    },
    原文链接: {
      url: note.noteUrl
    },
    笔记类型: {
      select: { 
        name: note.noteType === 'video' ? '视频' : '图文'
      }
    },
    笔记ID: {
      rich_text: [{ type: 'text', text: { content: note.id } }]
    },
    同步状态: {
      select: { name: '已同步' }
    },
    同步时间: {
      date: { start: now }
    },
    点赞数: {
      number: note.likeCount || 0
    },
    收藏数: {
      number: note.collectCount || 0
    },
    评论数: {
      number: note.commentCount || 0
    },
    
    // 智能知识库字段
    知识主题: {
      select: { name: analysisResult?.topic || note.knowledgeTopic || '其他' }
    },
    子主题: {
      rich_text: [{ type: 'text', text: { content: analysisResult?.subTopic || note.subTopic || '' } }]
    },
    AI标签: {
      multi_select: (analysisResult?.tags || note.aiTags || []).map(tag => ({ 
        name: tag.startsWith('#') ? tag.slice(1) : tag 
      }))
    },
    用户标签: {
      multi_select: (note.userTags || []).map(tag => ({ 
        name: tag.startsWith('#') ? tag.slice(1) : tag 
      }))
    },
    原始标签: {
      multi_select: note.tags?.map(tag => ({ name: tag.trim().slice(0, 90) })).filter(tag => tag.name) || []
    },
    一句话摘要: {
      rich_text: [{ type: 'text', text: { content: analysisResult?.summary || note.oneLineSummary || '' } }]
    },
    关键词: {
      multi_select: (analysisResult?.keywords || note.keywords || []).slice(0, 10).map(kw => ({ name: kw.slice(0, 90) }))
    },
    适用场景: {
      rich_text: [{ type: 'text', text: { content: analysisResult?.applicableScenarios || note.applicableScenarios || '' } }]
    },
    学习状态: {
      select: { name: note.learningStatus || '未学' }
    },
    学习优先级: {
      select: { name: note.learningPriority || '中' }
    },
    学习笔记: {
      rich_text: [{ type: 'text', text: { content: note.learningNotes || '' } }]
    },
    学习路径: {
      rich_text: [{ type: 'text', text: { content: note.learningPathId || '' } }]
    }
  };

  // 处理封面图
  if (note.coverUrl) {
    try {
      properties.封面图 = {
        files: [{ type: 'external', name: 'cover', external: { url: note.coverUrl } }]
      };
    } catch (e) {
      console.warn('封面图URL无效，跳过', note.coverUrl);
    }
  }

  // 构建页面内容块
  const children: any[] = [];

  // 基础信息栏
  children.push({
    object: 'block',
    type: 'callout',
    callout: {
      icon: { type: 'emoji', emoji: '📌' },
      color: 'gray_background',
      rich_text: [
        { type: 'text', text: { content: `作者：${note.authorName} | 发布时间：${new Date(note.publishTime).toLocaleString()}\n` } },
        { type: 'text', text: { content: `点赞：${note.likeCount} | 收藏：${note.collectCount} | 评论：${note.commentCount}\n` } },
        { type: 'text', text: { content: `原文链接：`, link: { url: note.noteUrl } } }
      ]
    }
  });

  // AI分析结果展示
  if (analysisResult) {
    children.push({
      object: 'block',
      type: 'heading_2',
      heading_2: {
        rich_text: [{ type: 'text', text: { content: '🤖 AI智能分析' } }]
      }
    });

    // 主题信息
    children.push({
      object: 'block',
      type: 'paragraph',
      paragraph: {
        rich_text: [
          { type: 'text', text: { content: '📂 知识主题：', bold: true } },
          { type: 'text', text: { content: `${analysisResult.topic} / ${analysisResult.subTopic}` } }
        ]
      }
    });

    // 摘要
    if (analysisResult.summary) {
      children.push({
        object: 'block',
        type: 'paragraph',
        paragraph: {
          rich_text: [
            { type: 'text', text: { content: '💡 一句话摘要：', bold: true } },
            { type: 'text', text: { content: analysisResult.summary } }
          ]
        }
      });
    }

    // 适用场景
    if (analysisResult.applicableScenarios) {
      children.push({
        object: 'block',
        type: 'paragraph',
        paragraph: {
          rich_text: [
            { type: 'text', text: { content: '🎯 适用场景：', bold: true } },
            { type: 'text', text: { content: analysisResult.applicableScenarios } }
          ]
        }
      });
    }

    // 学习路径建议
    if (analysisResult.learningPathSuggestion) {
      children.push({
        object: 'block',
        type: 'callout',
        callout: {
          icon: { type: 'emoji', emoji: '🛤️' },
          color: 'blue_background',
          rich_text: [
            { type: 'text', text: { content: analysisResult.learningPathSuggestion } }
          ]
        }
      });
    }
  }

  // 笔记正文
  if (note.desc) {
    children.push({
      object: 'block',
      type: 'heading_2',
      heading_2: {
        rich_text: [{ type: 'text', text: { content: '📝 笔记正文' } }]
      }
    });
    children.push(...splitTextToBlocks(note.desc));
  }

  // 所有图片插入（使用 Toggle 折叠）
  if (note.allImages && note.allImages.length > 0) {
    const imageBlocks: any[] = [];
    for (const imageUrl of note.allImages) {
      try {
        imageBlocks.push({
          object: 'block',
          type: 'image',
          image: {
            type: 'external',
            external: { url: imageUrl }
          }
        });
      } catch (e) {
        console.warn('图片URL无效，跳过', imageUrl);
      }
    }
    
    children.push({
      object: 'block',
      type: 'toggle',
      toggle: {
        rich_text: [{ 
          type: 'text', 
          text: { content: `🖼️ 查看全部 ${note.allImages.length} 张笔记原图` } 
        }],
        children: imageBlocks
      }
    });
  }

  // 作者补充评论（使用 Toggle 折叠）
  if (note.authorComments && note.authorComments.length > 0) {
    const authorCommentText = note.authorComments
      .map(item => `[${new Date(item.publishTime).toLocaleString()}]：${item.content}`)
      .join('\n\n');
    
    children.push({
      object: 'block',
      type: 'toggle',
      toggle: {
        rich_text: [{ 
          type: 'text', 
          text: { content: `💬 作者补充评论 (${note.authorComments.length}条)` } 
        }],
        children: splitTextToBlocks(authorCommentText)
      }
    });
  }

  // 高赞评论（使用 Toggle 折叠）
  if (note.comments && note.comments.length > 0) {
    const commentText = note.comments
      .map(item => `@${item.authorName}（点赞${item.likeCount}）：\n${item.content}`)
      .join('\n\n');
    
    children.push({
      object: 'block',
      type: 'toggle',
      toggle: {
        rich_text: [{ 
          type: 'text', 
          text: { content: `🔥 高赞评论 (${note.comments.length}条)` } 
        }],
        children: splitTextToBlocks(commentText)
      }
    });
  }

  // 原文链接
  children.push({
    object: 'block',
    type: 'divider',
    divider: {}
  });
  children.push({
    object: 'block',
    type: 'paragraph',
    paragraph: {
      rich_text: [{ type: 'text', text: { content: '🔗 小红书原文链接：', link: { url: note.noteUrl } } }]
    }
  });

  // 设置页面封面：优先使用第一张图片，其次使用封面图
  const coverImage = note.allImages?.[0] || note.coverUrl;

  // 创建页面（添加封面和图标）
  const pageResponse = await notion.pages.create({
    parent: { type: 'database_id', database_id: databaseId },
    // 添加封面图
    cover: coverImage ? {
      type: 'external',
      external: { url: coverImage }
    } : undefined,
    // 添加页面图标
    icon: { 
      type: 'emoji', 
      emoji: note.noteType === 'video' ? '🎬' : '📄' 
    },
    properties,
    children: children.slice(0, 100) // 限制第一批次的块数量
  });

  return pageResponse.id;
};

/**
 * 获取智能知识库统计信息
 */
export const getSmartKnowledgeStats = async (
  apiKey: string,
  databaseId: string
): Promise<SmartKnowledgeStats> => {
  const notion = createNotionClient(apiKey);
  
  try {
    const response = await notion.databases.query({
      database_id: databaseId,
      page_size: 100
    });

    const stats: SmartKnowledgeStats = {
      totalNotes: response.results.length,
      byTopic: {} as Record<KnowledgeTopic, number>,
      byStatus: { '未学': 0, '学习中': 0, '已掌握': 0, '待复习': 0 },
      byPriority: { '高': 0, '中': 0, '低': 0 },
      learningPaths: 0
    };

    response.results.forEach((page: any) => {
      const properties = page.properties;
      
      // 统计主题
      if (properties.知识主题?.select?.name) {
        const topic = properties.知识主题.select.name as KnowledgeTopic;
        stats.byTopic[topic] = (stats.byTopic[topic] || 0) + 1;
      }
      
      // 统计学习状态
      if (properties.学习状态?.select?.name) {
        const status = properties.学习状态.select.name as LearningStatus;
        if (stats.byStatus[status] !== undefined) {
          stats.byStatus[status]++;
        }
      }
      
      // 统计优先级
      if (properties.学习优先级?.select?.name) {
        const priority = properties.学习优先级.select.name as LearningPriority;
        if (stats.byPriority[priority] !== undefined) {
          stats.byPriority[priority]++;
        }
      }
    });

    return stats;
  } catch (error) {
    console.error('获取智能知识库统计失败:', error);
    return {
      totalNotes: 0,
      byTopic: {} as Record<KnowledgeTopic, number>,
      byStatus: { '未学': 0, '学习中': 0, '已掌握': 0, '待复习': 0 },
      byPriority: { '高': 0, '中': 0, '低': 0 },
      learningPaths: 0
    };
  }
};

// ==================== 页面模板生成 ====================

/**
 * 工具函数：将数组拆分为指定大小的块
 */
const chunk = <T>(array: T[], size: number): T[][] => {
  const result: T[][] = [];
  for (let i = 0; i < array.length; i += size) {
    result.push(array.slice(i, i + size));
  }
  return result;
};

/**
 * 工具函数：格式化数字
 */
const formatNumber = (num: number): string => {
  if (num >= 10000) {
    return (num / 10000).toFixed(1) + 'w';
  }
  return num.toString();
};

/**
 * 工具函数：格式化日期
 */
const formatDate = (timestamp: number): string => {
  const date = new Date(timestamp);
  return date.toLocaleDateString('zh-CN', {
    year: 'numeric',
    month: '2-digit',
    day: '2-digit'
  });
};

/**
 * 生成美观的笔记页面内容
 * 使用Notion的block格式构建页面
 * @param apiKey Notion API Key
 * @param pageId 页面ID
 * @param note 笔记数据
 */
export const createNotePageContent = async (
  apiKey: string,
  pageId: string,
  note: SmartKnowledgeNote
): Promise<void> => {
  const notion = createNotionClient(apiKey);
  const blocks: any[] = [];
  
  // 1. 基础信息卡片
  blocks.push({
    object: 'block',
    type: 'callout',
    callout: {
      rich_text: [{ type: 'text', text: { content: '📊 基础信息' } }],
      icon: { type: 'emoji', emoji: '📊' },
      color: 'blue_background'
    }
  });
  
  blocks.push({
    object: 'block',
    type: 'paragraph',
    paragraph: {
      rich_text: [
        { type: 'text', text: { content: `作者：${note.authorName}  |  发布：${formatDate(note.publishTime)}` } }
      ]
    }
  });
  
  blocks.push({
    object: 'block',
    type: 'paragraph',
    paragraph: {
      rich_text: [
        { type: 'text', text: { content: `💬 ${formatNumber(note.likeCount)}  ❤️ ${formatNumber(note.collectCount)}  📌 ${formatNumber(note.commentCount)}` } }
      ]
    }
  });
  
  // 2. 一句话摘要
  if (note.oneLineSummary) {
    blocks.push({
      object: 'block',
      type: 'heading_3',
      heading_3: {
        rich_text: [{ type: 'text', text: { content: '📝 一句话摘要' } }]
      }
    });
    blocks.push({
      object: 'block',
      type: 'callout',
      callout: {
        rich_text: [{ type: 'text', text: { content: note.oneLineSummary } }],
        icon: { type: 'emoji', emoji: '💡' },
        color: 'yellow_background'
      }
    });
  }
  
  // 3. 标签云
  if (note.aiTags?.length > 0 || note.userTags?.length > 0) {
    blocks.push({
      object: 'block',
      type: 'heading_3',
      heading_3: {
        rich_text: [{ type: 'text', text: { content: '🏷️ 标签云' } }]
      }
    });
    
    const allTags = [...(note.aiTags || []), ...(note.userTags || [])];
    blocks.push({
      object: 'block',
      type: 'paragraph',
      paragraph: {
        rich_text: allTags.map(tag => ({
          type: 'text',
          text: { content: `${tag}  ` }
        }))
      }
    });
  }
  
  // 4. 适用场景
  if (note.applicableScenarios) {
    blocks.push({
      object: 'block',
      type: 'heading_3',
      heading_3: {
        rich_text: [{ type: 'text', text: { content: '💡 适用场景' } }]
      }
    });
    blocks.push({
      object: 'block',
      type: 'paragraph',
      paragraph: {
        rich_text: [{ type: 'text', text: { content: note.applicableScenarios } }]
      }
    });
  }
  
  // 5. 原文内容
  blocks.push({
    object: 'block',
    type: 'heading_3',
    heading_3: {
      rich_text: [{ type: 'text', text: { content: '📖 原文内容' } }]
    }
  });
  
  const content = note.desc || '（无正文内容）';
  // 拆分超长文本
  const contentBlocks = splitTextToBlocks(content);
  blocks.push(...contentBlocks);
  
  // 6. 图片画廊（如果有图片）
  if (note.allImages && note.allImages.length > 0) {
    blocks.push({
      object: 'block',
      type: 'heading_3',
      heading_3: {
        rich_text: [{ type: 'text', text: { content: '🖼️ 图片画廊' } }]
      }
    });
    
    // 每行最多3张图片
    const imageGroups = chunk(note.allImages, 3);
    for (const group of imageGroups) {
      blocks.push({
        object: 'block',
        type: 'column_list',
        column_list: {}
      });
      
      for (const imgUrl of group) {
        blocks.push({
          object: 'block',
          type: 'column',
          column: {},
          children: [{
            object: 'block',
            type: 'image',
            image: {
              type: 'external',
              external: { url: imgUrl }
            }
          }]
        });
      }
    }
  }
  
  // 7. 原文链接
  blocks.push({
    object: 'block',
    type: 'heading_3',
    heading_3: {
      rich_text: [{ type: 'text', text: { content: '🔗 原文链接' } }]
    }
  });
  blocks.push({
    object: 'block',
    type: 'bookmark',
    bookmark: {
      url: note.noteUrl
    }
  });
  
  // 8. 学习笔记区域（用户填写）
  blocks.push({
    object: 'block',
    type: 'divider',
    divider: {}
  });
  blocks.push({
    object: 'block',
    type: 'heading_3',
    heading_3: {
      rich_text: [{ type: 'text', text: { content: '✏️ 我的学习笔记' } }]
    }
  });
  blocks.push({
    object: 'block',
    type: 'paragraph',
    paragraph: {
      rich_text: [{ type: 'text', text: { content: '（在这里写下你的学习心得...）' } }]
    }
  });
  
  // 将blocks追加到页面（分批处理）
  const MAX_BLOCKS_PER_REQUEST = 100;
  for (let i = 0; i < blocks.length; i += MAX_BLOCKS_PER_REQUEST) {
    const batch = blocks.slice(i, i + MAX_BLOCKS_PER_REQUEST);
    await notion.blocks.children.append({
      block_id: pageId,
      children: batch
    });
    // 限流延迟
    if (i + MAX_BLOCKS_PER_REQUEST < blocks.length) {
      await new Promise(resolve => setTimeout(resolve, 300));
    }
  }
};

// ==================== 关联数据库功能 ====================

/**
 * 创建关联数据库（作者库、标签库、专辑库）
 * @param apiKey Notion API Key
 * @param pageId 父页面ID
 * @param mainDatabaseId 主数据库ID
 * @param config 关联库配置
 * @returns 关联数据库ID和URL
 */
export const createRelationDatabases = async (
  apiKey: string,
  pageId: string,
  mainDatabaseId: string,
  config: RelationDatabaseConfig
): Promise<RelationDatabaseResult> => {
  const notion = createNotionClient(apiKey);
  const result: RelationDatabaseResult = {};
  
  // 1. 创建作者库
  if (config.enableAuthorDB) {
    try {
      const authorDB = await notion.databases.create({
        parent: { type: 'page_id', page_id: pageId },
        title: [{ type: 'text', text: { content: '👤 作者库' } }],
        properties: {
          昵称: { title: {} },
          作者ID: { rich_text: {} },
          头像: { files: {} },
          笔记数: { number: { format: 'number' } },
          粉丝数: { number: { format: 'number' } },
          最后更新: { date: {} },
          笔记: {
            relation: {
              database_id: mainDatabaseId,
              dual_property: { name: '作者关联' }
            }
          }
        }
      });
      result.authorDBId = authorDB.id;
      result.authorDBUrl = `https://notion.so/${authorDB.id.replace(/-/g, '')}`;
      console.log('作者库创建成功:', authorDB.id);
    } catch (error) {
      console.error('创建作者库失败:', error);
    }
  }
  
  // 2. 创建标签库
  if (config.enableTagDB) {
    try {
      const tagDB = await notion.databases.create({
        parent: { type: 'page_id', page_id: pageId },
        title: [{ type: 'text', text: { content: '🏷️ 标签库' } }],
        properties: {
          标签名: { title: {} },
          笔记数: { number: { format: 'number' } },
          热度: { number: { format: 'number' } },
          相关标签: { multi_select: {} },
          最后更新: { date: {} },
          笔记: {
            relation: {
              database_id: mainDatabaseId,
              dual_property: { name: '标签关联' }
            }
          }
        }
      });
      result.tagDBId = tagDB.id;
      result.tagDBUrl = `https://notion.so/${tagDB.id.replace(/-/g, '')}`;
      console.log('标签库创建成功:', tagDB.id);
    } catch (error) {
      console.error('创建标签库失败:', error);
    }
  }
  
  // 3. 创建专辑库
  if (config.enableAlbumDB) {
    try {
      const albumDB = await notion.databases.create({
        parent: { type: 'page_id', page_id: pageId },
        title: [{ type: 'text', text: { content: '📁 专辑库' } }],
        properties: {
          专辑名: { title: {} },
          专辑ID: { rich_text: {} },
          封面: { files: {} },
          笔记数: { number: { format: 'number' } },
          最后更新: { date: {} },
          笔记: {
            relation: {
              database_id: mainDatabaseId,
              dual_property: { name: '专辑关联' }
            }
          }
        }
      });
      result.albumDBId = albumDB.id;
      result.albumDBUrl = `https://notion.so/${albumDB.id.replace(/-/g, '')}`;
      console.log('专辑库创建成功:', albumDB.id);
    } catch (error) {
      console.error('创建专辑库失败:', error);
    }
  }
  
  return result;
};

/**
 * 同步作者信息到作者库
 * @param apiKey Notion API Key
 * @param authorDBId 作者库ID
 * @param author 作者信息
 * @returns 作者页面ID
 */
export const syncAuthorToDatabase = async (
  apiKey: string,
  authorDBId: string,
  author: AuthorInfo
): Promise<string | null> => {
  const notion = createNotionClient(apiKey);
  
  try {
    // 检查作者是否已存在
    const existing = await notion.databases.query({
      database_id: authorDBId,
      filter: {
        property: '作者ID',
        rich_text: { equals: author.authorId }
      }
    });
    
    if (existing.results.length > 0) {
      // 更新现有作者
      const page = existing.results[0] as any;
      await notion.pages.update({
        page_id: page.id,
        properties: {
          笔记数: { number: author.noteCount },
          最后更新: { date: { start: new Date().toISOString() } }
        }
      });
      return page.id;
    } else {
      // 创建新作者
      const page = await notion.pages.create({
        parent: { database_id: authorDBId },
        properties: {
          昵称: { title: [{ type: 'text', text: { content: author.authorName } }] },
          作者ID: { rich_text: [{ type: 'text', text: { content: author.authorId } }] },
          笔记数: { number: author.noteCount },
          粉丝数: { number: author.followerCount || 0 },
          最后更新: { date: { start: new Date().toISOString() } }
        }
      });
      return page.id;
    }
  } catch (error) {
    console.error('同步作者信息失败:', error);
    return null;
  }
};

/**
 * 同步标签到标签库
 * @param apiKey Notion API Key
 * @param tagDBId 标签库ID
 * @param tag 标签名称
 * @param noteId 关联笔记ID
 */
export const syncTagToDatabase = async (
  apiKey: string,
  tagDBId: string,
  tag: string,
  noteId?: string
): Promise<void> => {
  const notion = createNotionClient(apiKey);
  
  try {
    // 检查标签是否已存在
    const existing = await notion.databases.query({
      database_id: tagDBId,
      filter: {
        property: '标签名',
        title: { equals: tag }
      }
    });
    
    if (existing.results.length > 0) {
      // 更新标签计数
      const page = existing.results[0] as any;
      const currentCount = page.properties.笔记数?.number || 0;
      await notion.pages.update({
        page_id: page.id,
        properties: {
          笔记数: { number: currentCount + 1 },
          热度: { number: (page.properties.热度?.number || 0) + 1 },
          最后更新: { date: { start: new Date().toISOString() } }
        }
      });
    } else {
      // 创建新标签
      await notion.pages.create({
        parent: { database_id: tagDBId },
        properties: {
          标签名: { title: [{ type: 'text', text: { content: tag } }] },
          笔记数: { number: 1 },
          热度: { number: 1 },
          最后更新: { date: { start: new Date().toISOString() } }
        }
      });
    }
  } catch (error) {
    console.error('同步标签信息失败:', error);
  }
};

/**
 * 同步专辑到专辑库
 * @param apiKey Notion API Key
 * @param albumDBId 专辑库ID
 * @param album 专辑信息
 */
export const syncAlbumToDatabase = async (
  apiKey: string,
  albumDBId: string,
  album: AlbumInfo
): Promise<string | null> => {
  const notion = createNotionClient(apiKey);
  
  try {
    // 检查专辑是否已存在
    const existing = await notion.databases.query({
      database_id: albumDBId,
      filter: {
        property: '专辑ID',
        rich_text: { equals: album.albumId }
      }
    });
    
    if (existing.results.length > 0) {
      // 更新专辑信息
      const page = existing.results[0] as any;
      await notion.pages.update({
        page_id: page.id,
        properties: {
          笔记数: { number: album.noteCount },
          最后更新: { date: { start: new Date().toISOString() } }
        }
      });
      return page.id;
    } else {
      // 创建新专辑
      const page = await notion.pages.create({
        parent: { database_id: albumDBId },
        properties: {
          专辑名: { title: [{ type: 'text', text: { content: album.albumName } }] },
          专辑ID: { rich_text: [{ type: 'text', text: { content: album.albumId } }] },
          笔记数: { number: album.noteCount },
          最后更新: { date: { start: new Date().toISOString() } }
        },
        cover: album.coverUrl ? {
          type: 'external',
          external: { url: album.coverUrl }
        } : undefined
      });
      return page.id;
    }
  } catch (error) {
    console.error('同步专辑信息失败:', error);
    return null;
  }
};

/**
 * 更新主数据库，添加关联字段
 * @param apiKey Notion API Key
 * @param databaseId 主数据库ID
 * @param relationDBIds 关联数据库ID列表
 */
export const updateDatabaseWithRelations = async (
  apiKey: string,
  databaseId: string,
  relationDBIds: {
    authorDBId?: string;
    tagDBId?: string;
    albumDBId?: string;
  }
): Promise<void> => {
  const notion = createNotionClient(apiKey);
  
  try {
    const propertiesToAdd: Record<string, any> = {};
    
    // 添加作者关联字段
    if (relationDBIds.authorDBId) {
      propertiesToAdd.作者关联 = {
        relation: {
          database_id: relationDBIds.authorDBId
        }
      };
    }
    
    // 添加标签关联字段
    if (relationDBIds.tagDBId) {
      propertiesToAdd.标签关联 = {
        relation: {
          database_id: relationDBIds.tagDBId
        }
      };
    }
    
    // 添加专辑关联字段
    if (relationDBIds.albumDBId) {
      propertiesToAdd.专辑关联 = {
        relation: {
          database_id: relationDBIds.albumDBId
        }
      };
    }
    
    if (Object.keys(propertiesToAdd).length > 0) {
      await notion.databases.update({
        database_id: databaseId,
        properties: propertiesToAdd
      });
      console.log('主数据库关联字段添加成功');
    }
  } catch (error) {
    console.error('更新主数据库关联字段失败:', error);
  }
};

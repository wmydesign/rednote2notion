/**
 * PostCSS配置文件
 * 适配Tailwind CSS编译
 */
module.exports = {
  plugins: {
    tailwindcss: {},
    autoprefixer: {},
  },
}

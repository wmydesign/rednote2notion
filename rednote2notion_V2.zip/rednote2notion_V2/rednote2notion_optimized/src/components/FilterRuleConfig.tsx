import React, { useState } from 'react';
import { FilterRule } from '../lib/types';

interface FilterRuleConfigProps {
  rules: FilterRule[];
  onChange: (rules: FilterRule[]) => void;
}

const FilterRuleConfig: React.FC<FilterRuleConfigProps> = ({ rules, onChange }) => {
  const [showConfig, setShowConfig] = useState(false);

  // 字段选项
  const fieldOptions = [
    { label: '笔记标题', value: 'title' },
    { label: '笔记正文', value: 'desc' },
    { label: '笔记标签', value: 'tags' },
    { label: '发布时间', value: 'publishTime' },
    { label: '收藏时间', value: 'collectTime' },
    { label: '点赞数', value: 'likeCount' },
    { label: '收藏数', value: 'collectCount' },
    { label: '评论数', value: 'commentCount' },
    { label: '笔记类型', value: 'noteType' },
    { label: '作者名称', value: 'authorName' }
  ];

  // 运算符选项
  const operatorOptions = [
    { label: '包含', value: 'contains' },
    { label: '不包含', value: 'notContains' },
    { label: '等于', value: 'equals' },
    { label: '不等于', value: 'notEquals' },
    { label: '大于', value: 'greaterThan' },
    { label: '小于', value: 'lessThan' },
    { label: '区间内', value: 'between' },
    { label: '在列表中', value: 'in' },
    { label: '不在列表中', value: 'notIn' },
    { label: '标签包含', value: 'tagContains' }
  ];

  // 逻辑选项
  const logicOptions = [
    { label: '并且(and)', value: 'and' },
    { label: '或者(or)', value: 'or' }
  ];

  // 新增规则
  const addRule = () => {
    const newRule: FilterRule = {
      id: Date.now().toString(),
      field: 'title',
      operator: 'contains',
      value: '',
      logic: 'and'
    };
    onChange([...rules, newRule]);
  };

  // 删除规则
  const deleteRule = (id: string) => {
    onChange(rules.filter(rule => rule.id !== id));
  };

  // 更新规则
  const updateRule = (id: string, key: keyof FilterRule, value: any) => {
    const newRules = rules.map(rule => {
      if (rule.id === id) {
        return { ...rule, [key]: value };
      }
      return rule;
    });
    onChange(newRules);
  };

  return (
    <div className="bg-white dark:bg-gray-800 rounded-lg p-4 mb-4 shadow-sm">
      <div className="flex items-center justify-between mb-3">
        <h2 className="text-lg font-semibold text-gray-800 dark:text-white">高级筛选同步规则</h2>
        <button
          onClick={() => setShowConfig(!showConfig)}
          className="text-sm text-blue-500 hover:text-blue-600"
        >
          {showConfig ? '收起' : '展开配置'}
        </button>
      </div>

      {!showConfig && (
        <p className="text-sm text-gray-600 dark:text-gray-400">
          已配置 {rules.length} 条筛选规则
        </p>
      )}

      {showConfig && (
        <div className="space-y-3">
          {rules.length === 0 ? (
            <p className="text-center text-sm text-gray-500 py-2">暂无筛选规则，将同步所有符合条件的笔记</p>
          ) : (
            <div className="space-y-2">
              {rules.map((rule, index) => (
                <div key={rule.id} className="p-3 border border-gray-200 dark:border-gray-700 rounded-lg">
                  <div className="flex items-center gap-2 mb-2 flex-wrap">
                    {index > 0 && (
                      <div className="w-20">
                        <select
                          value={rule.logic}
                          onChange={(e) => updateRule(rule.id, 'logic', e.target.value)}
                          className="w-full px-2 py-1 text-sm border border-gray-300 rounded-md dark:bg-gray-700 dark:border-gray-600 dark:text-white"
                        >
                          {logicOptions.map(opt => (
                            <option key={opt.value} value={opt.value}>{opt.label}</option>
                          ))}
                        </select>
                      </div>
                    )}
                    <div className="flex-1 min-w-[120px]">
                      <select
                        value={rule.field}
                        onChange={(e) => updateRule(rule.id, 'field', e.target.value)}
                        className="w-full px-2 py-1 text-sm border border-gray-300 rounded-md dark:bg-gray-700 dark:border-gray-600 dark:text-white"
                      >
                        {fieldOptions.map(opt => (
                          <option key={opt.value} value={opt.value}>{opt.label}</option>
                        ))}
                      </select>
                    </div>
                    <div className="flex-1 min-w-[120px]">
                      <select
                        value={rule.operator}
                        onChange={(e) => updateRule(rule.id, 'operator', e.target.value)}
                        className="w-full px-2 py-1 text-sm border border-gray-300 rounded-md dark:bg-gray-700 dark:border-gray-600 dark:text-white"
                      >
                        {operatorOptions.map(opt => (
                          <option key={opt.value} value={opt.value}>{opt.label}</option>
                        ))}
                      </select>
                    </div>
                    <button
                      onClick={() => deleteRule(rule.id)}
                      className="px-2 py-1 text-sm text-red-500 hover:text-red-600"
                    >
                      删除
                    </button>
                  </div>
                  <div>
                    <input
                      type="text"
                      value={rule.value}
                      onChange={(e) => updateRule(rule.id, 'value', e.target.value)}
                      className="w-full px-2 py-1 text-sm border border-gray-300 rounded-md dark:bg-gray-700 dark:border-gray-600 dark:text-white"
                      placeholder="请输入规则值，多个值用英文逗号分隔，时间请输入时间戳"
                    />
                  </div>
                </div>
              ))}
            </div>
          )}

          <button
            onClick={addRule}
            className="w-full py-2 border border-dashed border-gray-300 dark:border-gray-600 rounded-md text-sm text-blue-500 hover:text-blue-600 hover:border-blue-500"
          >
            + 新增筛选规则
          </button>

          <div className="text-xs text-gray-500 dark:text-gray-400 space-y-1">
            <p>⚠️ 规则说明：所有「并且」规则必须全部满足，「或者」规则满足其一即可</p>
            <p>⚠️ 区间内/列表规则：多个值请用英文逗号分隔，如 1000,10000</p>
            <p>⚠️ 时间规则：请输入13位时间戳，如 2024-01-01 对应 1704067200000</p>
          </div>
        </div>
      )}
    </div>
  );
};

export default FilterRuleConfig;

import React, { useState } from 'react';
import { AIProcessTemplate } from '../lib/types';

interface AIProcessTemplateConfigProps {
  templates: AIProcessTemplate[];
  enableAIProcess: boolean;
  onTemplateChange: (templates: AIProcessTemplate[]) => void;
  onEnableChange: (enable: boolean) => void;
}

const AIProcessTemplateConfig: React.FC<AIProcessTemplateConfigProps> = ({
  templates,
  enableAIProcess,
  onTemplateChange,
  onEnableChange
}) => {
  const [showConfig, setShowConfig] = useState(false);

  // 预设模板
  const presetTemplates: AIProcessTemplate[] = [
    {
      id: 'core_knowledge',
      name: '核心知识点提炼',
      fieldName: '核心知识点',
      prompt: '请提炼这篇小红书笔记的核心知识点，用分点形式输出，每个知识点不超过50字，只输出知识点，不要其他多余内容',
      enable: true
    },
    {
      id: 'action_list',
      name: '行动清单/SOP',
      fieldName: '行动清单',
      prompt: '请把这篇小红书笔记的内容，提炼为可执行的步骤清单，用分点形式输出，只输出步骤，不要其他多余内容',
      enable: false
    },
    {
      id: 'avoid_pit',
      name: '避坑指南',
      fieldName: '避坑指南',
      prompt: '请提炼这篇小红书笔记里提到的避坑点、注意事项、雷区，用分点形式输出，只输出内容，不要其他多余内容',
      enable: false
    },
    {
      id: 'golden_sentence',
      name: '金句摘抄',
      fieldName: '金句摘抄',
      prompt: '请摘抄这篇小红书笔记里的金句、经典语录、有感染力的句子，用分点形式输出，只输出句子，不要其他多余内容',
      enable: false
    },
    {
      id: 'mind_map',
      name: '思维导图大纲',
      fieldName: '思维导图大纲',
      prompt: '请把这篇小红书笔记的内容整理为层级清晰的思维导图大纲，用markdown无序列表输出，最多3级层级',
      enable: false
    }
  ];

  // 初始化加载预设模板
  React.useEffect(() => {
    if (templates.length === 0) {
      onTemplateChange(presetTemplates);
    }
  }, []);

  // 切换模板启用状态
  const toggleTemplateEnable = (id: string) => {
    const newTemplates = templates.map(template => {
      if (template.id === id) {
        return { ...template, enable: !template.enable };
      }
      return template;
    });
    onTemplateChange(newTemplates);
  };

  // 更新模板
  const updateTemplate = (id: string, key: keyof AIProcessTemplate, value: any) => {
    const newTemplates = templates.map(template => {
      if (template.id === id) {
        return { ...template, [key]: value };
      }
      return template;
    });
    onTemplateChange(newTemplates);
  };

  // 新增自定义模板
  const addCustomTemplate = () => {
    const newTemplate: AIProcessTemplate = {
      id: `custom_${Date.now()}`,
      name: '自定义模板',
      fieldName: '自定义字段',
      prompt: '请处理这篇小红书笔记',
      enable: true,
      isCustom: true
    };
    onTemplateChange([...templates, newTemplate]);
  };

  // 删除模板
  const deleteTemplate = (id: string) => {
    onTemplateChange(templates.filter(template => template.id !== id));
  };

  return (
    <div className="bg-white dark:bg-gray-800 rounded-lg p-4 mb-4 shadow-sm">
      <div className="flex items-center justify-between mb-3">
        <h2 className="text-lg font-semibold text-gray-800 dark:text-white">AI深度知识加工</h2>
        <div className="flex items-center gap-2">
          <input
            type="checkbox"
            id="enableAIProcess"
            checked={enableAIProcess}
            onChange={(e) => onEnableChange(e.target.checked)}
            className="w-4 h-4 text-red-500 rounded"
          />
          <label htmlFor="enableAIProcess" className="text-sm text-gray-700 dark:text-gray-300">
            启用深度加工
          </label>
          <button
            onClick={() => setShowConfig(!showConfig)}
            className="text-sm text-blue-500 hover:text-blue-600 ml-2"
          >
            {showConfig ? '收起' : '展开配置'}
          </button>
        </div>
      </div>

      {!showConfig && (
        <p className="text-sm text-gray-600 dark:text-gray-400">
          已启用 {templates.filter(t => t.enable).length} 个AI加工模板
        </p>
      )}

      {showConfig && enableAIProcess && (
        <div className="space-y-3">
          <div className="border border-gray-200 dark:border-gray-700 rounded-lg overflow-hidden">
            <div className="max-h-80 overflow-y-auto">
              {templates.map(template => (
                <div key={template.id} className="p-3 border-b border-gray-100 dark:border-gray-700 last:border-b-0">
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center gap-2 flex-1">
                      <input
                        type="checkbox"
                        id={`template_${template.id}`}
                        checked={template.enable}
                        onChange={() => toggleTemplateEnable(template.id)}
                        className="w-4 h-4 text-red-500 rounded"
                      />
                      <label htmlFor={`template_${template.id}`} className="text-sm font-medium text-gray-800 dark:text-white cursor-pointer flex-1">
                        {template.name}
                        {template.isCustom && <span className="ml-2 text-xs text-blue-500">自定义</span>}
                      </label>
                    </div>
                    {template.isCustom && (
                      <button
                        onClick={() => deleteTemplate(template.id)}
                        className="text-xs text-red-500 hover:text-red-600"
                      >
                        删除
                      </button>
                    )}
                  </div>
                  <div className="ml-6 space-y-2">
                    <div>
                      <label className="block text-xs text-gray-600 dark:text-gray-400 mb-1">
                        Notion字段名称
                      </label>
                      <input
                        type="text"
                        value={template.fieldName}
                        onChange={(e) => updateTemplate(template.id, 'fieldName', e.target.value)}
                        className="w-full px-2 py-1 text-sm border border-gray-300 rounded-md dark:bg-gray-700 dark:border-gray-600 dark:text-white"
                        placeholder="请输入Notion数据库字段名称"
                      />
                    </div>
                    <div>
                      <label className="block text-xs text-gray-600 dark:text-gray-400 mb-1">
                        Prompt提示词
                      </label>
                      <textarea
                        value={template.prompt}
                        onChange={(e) => updateTemplate(template.id, 'prompt', e.target.value)}
                        className="w-full px-2 py-1 text-sm border border-gray-300 rounded-md dark:bg-gray-700 dark:border-gray-600 dark:text-white"
                        rows={3}
                        placeholder="请输入AI处理的Prompt，变量{title}为笔记标题，{desc}为笔记正文，{tags}为笔记标签"
                      />
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <button
            onClick={addCustomTemplate}
            className="w-full py-2 border border-dashed border-gray-300 dark:border-gray-600 rounded-md text-sm text-blue-500 hover:text-blue-600 hover:border-blue-500"
          >
            + 新增自定义加工模板
          </button>

          <div className="text-xs text-gray-500 dark:text-gray-400">
            <p>⚠️ 请确保Notion数据库中已创建对应名称的字段，字段类型为「富文本」</p>
            <p>⚠️ Prompt中可使用变量：{title}（笔记标题）、{desc}（笔记正文）、{tags}（笔记标签）</p>
          </div>
        </div>
      )}
    </div>
  );
};

export default AIProcessTemplateConfig;

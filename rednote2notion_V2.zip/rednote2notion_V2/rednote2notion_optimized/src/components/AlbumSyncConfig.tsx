import React, { useState, useEffect } from 'react';
import { getUserAlbumList, RednoteAlbum } from '../lib/album';

interface AlbumSyncConfigProps {
  selectedAlbums: string[];
  categoryMap: Record<string, string>;
  onChange: (selectedAlbums: string[], categoryMap: Record<string, string>) => void;
}

const AlbumSyncConfig: React.FC<AlbumSyncConfigProps> = ({ selectedAlbums, categoryMap, onChange }) => {
  const [albumList, setAlbumList] = useState<RednoteAlbum[]>([]);
  const [loading, setLoading] = useState(false);
  const [showConfig, setShowConfig] = useState(false);

  // 加载专辑列表
  const loadAlbumList = async () => {
    setLoading(true);
    const albums = await getUserAlbumList();
    setAlbumList(albums);
    setLoading(false);
  };

  useEffect(() => {
    if (showConfig) {
      loadAlbumList();
    }
  }, [showConfig]);

  // 处理专辑选择
  const handleAlbumSelect = (albumId: string, checked: boolean) => {
    let newSelected = [...selectedAlbums];
    if (checked) {
      if (!newSelected.includes(albumId)) {
        newSelected.push(albumId);
      }
    } else {
      newSelected = newSelected.filter(id => id !== albumId);
      // 同步删除分类映射
      const newCategoryMap = { ...categoryMap };
      delete newCategoryMap[albumId];
      onChange(newSelected, newCategoryMap);
      return;
    }
    onChange(newSelected, categoryMap);
  };

  // 处理分类映射修改
  const handleCategoryChange = (albumId: string, category: string) => {
    const newCategoryMap = { ...categoryMap, [albumId]: category };
    onChange(selectedAlbums, newCategoryMap);
  };

  // 全选/取消全选
  const handleSelectAll = (checked: boolean) => {
    if (checked) {
      const allIds = albumList.map(album => album.albumId);
      onChange(allIds, categoryMap);
    } else {
      onChange([], {});
    }
  };

  return (
    <div className="bg-white dark:bg-gray-800 rounded-lg p-4 mb-4 shadow-sm">
      <div className="flex items-center justify-between mb-3">
        <h2 className="text-lg font-semibold text-gray-800 dark:text-white">收藏专辑定向同步</h2>
        <button
          onClick={() => setShowConfig(!showConfig)}
          className="text-sm text-blue-500 hover:text-blue-600"
        >
          {showConfig ? '收起' : '展开配置'}
        </button>
      </div>

      {!showConfig && (
        <p className="text-sm text-gray-600 dark:text-gray-400">
          已选择 {selectedAlbums.length} 个专辑进行同步
        </p>
      )}

      {showConfig && (
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <button
              onClick={loadAlbumList}
              disabled={loading}
              className="text-sm text-blue-500 hover:text-blue-600 disabled:text-gray-400"
            >
              {loading ? '刷新中...' : '刷新专辑列表'}
            </button>
            <div className="flex items-center">
              <input
                type="checkbox"
                id="selectAllAlbum"
                checked={albumList.length > 0 && selectedAlbums.length === albumList.length}
                onChange={(e) => handleSelectAll(e.target.checked)}
                className="w-4 h-4 text-red-500 rounded"
              />
              <label htmlFor="selectAllAlbum" className="ml-1 text-sm text-gray-700 dark:text-gray-300">
                全选
              </label>
            </div>
          </div>

          {loading ? (
            <p className="text-center text-sm text-gray-500 py-4">加载中...</p>
          ) : albumList.length === 0 ? (
            <p className="text-center text-sm text-gray-500 py-4">未获取到收藏专辑，请先登录小红书网页版</p>
          ) : (
            <div className="border border-gray-200 dark:border-gray-700 rounded-lg overflow-hidden">
              <div className="max-h-60 overflow-y-auto">
                {albumList.map(album => (
                  <div key={album.albumId} className="p-3 border-b border-gray-100 dark:border-gray-700 last:border-b-0">
                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center gap-2 flex-1">
                        <input
                          type="checkbox"
                          id={`album_${album.albumId}`}
                          checked={selectedAlbums.includes(album.albumId)}
                          onChange={(e) => handleAlbumSelect(album.albumId, e.target.checked)}
                          className="w-4 h-4 text-red-500 rounded"
                        />
                        <label htmlFor={`album_${album.albumId}`} className="text-sm font-medium text-gray-800 dark:text-white cursor-pointer flex-1">
                          {album.albumName}
                          <span className="ml-2 text-xs text-gray-500">({album.noteCount}篇)</span>
                        </label>
                      </div>
                    </div>
                    {selectedAlbums.includes(album.albumId) && (
                      <div className="ml-6">
                        <label className="block text-xs text-gray-600 dark:text-gray-400 mb-1">
                          映射到Notion分类
                        </label>
                        <input
                          type="text"
                          value={categoryMap[album.albumId] || ''}
                          onChange={(e) => handleCategoryChange(album.albumId, e.target.value)}
                          className="w-full px-2 py-1 text-sm border border-gray-300 rounded-md dark:bg-gray-700 dark:border-gray-600 dark:text-white"
                          placeholder="请输入Notion分类名称，不填则使用专辑名"
                        />
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </div>
          )}

          <p className="text-xs text-gray-500 dark:text-gray-400">
            ⚠️ 未选择任何专辑时，默认同步所有收藏内容
          </p>
        </div>
      )}
    </div>
  );
};

export default AlbumSyncConfig;

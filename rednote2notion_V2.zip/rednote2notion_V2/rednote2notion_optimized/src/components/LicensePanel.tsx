import React, { useState, useEffect } from 'react';
import { 
  getCurrentLicense, 
  saveLicenseCode, 
  generateDeviceFingerprint, 
  LicenseType,
  activateLicenseCode,
  resetSyncCount
} from '../lib/license';

const LicensePanel = () => {
  const [licenseCode, setLicenseCode] = useState('');
  const [licenseInfo, setLicenseInfo] = useState<any>(null);
  const [deviceFingerprint, setDeviceFingerprint] = useState('');
  const [loading, setLoading] = useState(false);
  const [activating, setActivating] = useState(false);

  // 初始化加载授权信息
  useEffect(() => {
    loadLicenseInfo();
    loadDeviceFingerprint();
  }, []);

  const loadLicenseInfo = async () => {
    const info = await getCurrentLicense();
    setLicenseInfo(info);
    setLicenseCode(info.licenseCode);
  };

  const loadDeviceFingerprint = async () => {
    const fingerprint = await generateDeviceFingerprint();
    setDeviceFingerprint(fingerprint);
  };

  // 激活授权码
  const handleActivateLicense = async () => {
    if (!licenseCode || licenseCode.trim() === '') {
      alert('请输入授权码');
      return;
    }
    setActivating(true);
    const result = await activateLicenseCode(licenseCode);
    if (result.isValid) {
      alert('授权码激活成功！已绑定当前设备');
      await loadLicenseInfo();
    } else {
      alert(`激活失败：${result.errorMsg}`);
    }
    setActivating(false);
  };

  // 保存授权码
  const handleSaveLicense = async () => {
    setLoading(true);
    await saveLicenseCode(licenseCode);
    await loadLicenseInfo();
    setLoading(false);
    alert('授权码已保存，请点击激活按钮绑定设备');
  };

  // 复制设备指纹
  const handleCopyFingerprint = async () => {
    await navigator.clipboard.writeText(deviceFingerprint);
    alert('设备指纹已复制到剪贴板');
  };

  // 复制授权码
  const handleCopyLicenseCode = async () => {
    await navigator.clipboard.writeText(licenseCode);
    alert('授权码已复制到剪贴板');
  };

  // 重置同步计数
  const handleResetSyncCount = async () => {
    if (!licenseInfo || licenseInfo.licenseType !== LicenseType.PERMANENT) {
      alert('仅永久版可重置同步计数');
      return;
    }
    if (confirm('确定要重置同步计数吗？仅重置计数，不会删除已同步的内容')) {
      await resetSyncCount();
      await loadLicenseInfo();
      alert('同步计数已重置');
    }
  };

  // 格式化授权类型文本
  const formatLicenseType = (type: LicenseType) => {
    const map = {
      [LicenseType.FREE]: '免费版',
      [LicenseType.TRIAL]: '体验版',
      [LicenseType.PERMANENT]: '永久版'
    };
    return map[type] || '未知版本';
  };

  // 格式化有效期
  const formatExpireTime = (timestamp: number) => {
    if (timestamp > Date.now() + 30 * 365 * 24 * 60 * 60 * 1000) {
      return '永久有效';
    }
    return new Date(timestamp).toLocaleString();
  };

  return (
    <div className="bg-white dark:bg-gray-800 rounded-lg p-4 mb-4 shadow-sm">
      <h2 className="text-lg font-semibold mb-3 text-gray-800 dark:text-white">授权管理</h2>
      
      {/* 授权状态展示 */}
      {licenseInfo && (
        <div className="mb-4 p-3 border border-gray-200 dark:border-gray-700 rounded-lg">
          <div className="grid grid-cols-2 gap-2 text-sm mb-2">
            <div>
              <span className="text-gray-500 dark:text-gray-400">当前版本：</span>
              <span className={`font-medium ${licenseInfo.licenseType === LicenseType.PERMANENT ? 'text-green-500' : licenseInfo.licenseType === LicenseType.TRIAL ? 'text-blue-500' : 'text-gray-600'}`}>
                {formatLicenseType(licenseInfo.licenseType)}
              </span>
            </div>
            <div>
              <span className="text-gray-500 dark:text-gray-400">激活状态：</span>
              <span className={`font-medium ${licenseInfo.isActivated ? 'text-green-500' : 'text-orange-500'}`}>
                {licenseInfo.isActivated ? '已激活' : '未激活'}
              </span>
            </div>
            <div>
              <span className="text-gray-500 dark:text-gray-400">有效期至：</span>
              <span className="font-medium text-gray-800 dark:text-white">{formatExpireTime(licenseInfo.expireTime)}</span>
            </div>
            <div>
              <span className="text-gray-500 dark:text-gray-400">已同步数量：</span>
              <span className="font-medium text-gray-800 dark:text-white">
                {licenseInfo.usedSyncCount} / {licenseInfo.maxSyncCount === Infinity ? '无限制' : licenseInfo.maxSyncCount}
              </span>
            </div>
          </div>
          {!licenseInfo.isValid && licenseInfo.errorMsg && (
            <p className="text-sm text-red-500 mb-2">{licenseInfo.errorMsg}</p>
          )}
          {licenseInfo.licenseType === LicenseType.PERMANENT && (
            <button
              onClick={handleResetSyncCount}
              className="text-xs text-blue-500 hover:text-blue-600"
            >
              重置同步计数
            </button>
          )}
        </div>
      )}

      {/* 授权码输入与激活 */}
      <div className="space-y-3 mb-4">
        <div>
          <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
            授权码/卡密
          </label>
          <div className="flex flex-wrap gap-2">
            <input
              type="text"
              value={licenseCode}
              onChange={(e) => setLicenseCode(e.target.value)}
              className="flex-1 min-w-[200px] px-3 py-2 border border-gray-300 rounded-md dark:bg-gray-700 dark:border-gray-600 dark:text-white"
              placeholder="请输入授权码/卡密"
            />
            <button
              onClick={handleSaveLicense}
              disabled={loading}
              className="px-4 py-2 bg-gray-500 text-white rounded-md hover:bg-gray-600 disabled:bg-gray-400"
            >
              保存
            </button>
            <button
              onClick={handleActivateLicense}
              disabled={activating || !licenseCode}
              className="px-4 py-2 bg-red-500 text-white rounded-md hover:bg-red-600 disabled:bg-gray-400"
            >
              {activating ? '激活中' : '激活绑定设备'}
            </button>
            {licenseCode && (
              <button
                onClick={handleCopyLicenseCode}
                className="px-4 py-2 bg-blue-500 text-white rounded-md hover:bg-blue-600"
              >
                复制
              </button>
            )}
          </div>
        </div>

        {/* 设备指纹 */}
        <div>
          <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
            设备指纹（一码一机，禁止倒卖）
          </label>
          <div className="flex gap-2">
            <input
              type="text"
              value={deviceFingerprint}
              readOnly
              className="flex-1 px-3 py-2 border border-gray-300 rounded-md dark:bg-gray-700 dark:border-gray-600 dark:text-white bg-gray-100"
            />
            <button
              onClick={handleCopyFingerprint}
              className="px-4 py-2 bg-blue-500 text-white rounded-md hover:bg-blue-600"
            >
              复制
            </button>
          </div>
        </div>
      </div>

      <div className="text-xs text-gray-500 dark:text-gray-400 space-y-1">
        <p>⚠️ 授权码与当前设备绑定，更换设备/浏览器/重装浏览器需要重新激活</p>
        <p>⚠️ 禁止将授权码分享给他人使用，一经发现将永久封禁授权</p>
      </div>
    </div>
  );
};

export default LicensePanel;

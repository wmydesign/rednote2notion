import React, { useState, useEffect } from 'react';
import { getCurrentLicense, LicenseType } from './lib/license';
import './style.css';

const Popup = () => {
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [syncStatus, setSyncStatus] = useState(false);
  const [licenseInfo, setLicenseInfo] = useState<any>(null);

  useEffect(() => {
    checkStatus();
  }, []);

  const checkStatus = async () => {
    // 加载用户状态
    const storageData = await chrome.storage.local.get([
      'current_user',
      'sync-rednote-bookmark-to-notion',
      'sync-rednote-album-to-notion'
    ]);
    setIsLoggedIn(!!storageData.current_user);
    setSyncStatus(
      storageData['sync-rednote-bookmark-to-notion'] || 
      storageData['sync-rednote-album-to-notion'] || false
    );

    // 加载授权信息
    const license = await getCurrentLicense();
    setLicenseInfo(license);
  };

  const openSidePanel = async () => {
    await chrome.sidePanel.open({ windowId: chrome.windows.WINDOW_ID_CURRENT });
    window.close();
  };

  const openOptionsPage = () => {
    chrome.runtime.openOptionsPage();
    window.close();
  };

  // 格式化授权类型
  const formatLicenseType = (type: LicenseType) => {
    const map = {
      [LicenseType.FREE]: '免费版',
      [LicenseType.TRIAL]: '体验版',
      [LicenseType.PERMANENT]: '永久版'
    };
    return map[type] || '免费版';
  };

  return (
    <div className="w-72 p-4 bg-white dark:bg-gray-900">
      <div className="text-center">
        <h2 className="text-lg font-bold text-red-500 mb-2">Rednote2Notion V2.0</h2>
        
        {/* 授权状态 */}
        {licenseInfo && (
          <div className="mb-3 p-2 bg-gray-50 dark:bg-gray-800 rounded-md">
            <p className="text-sm font-medium text-gray-800 dark:text-white">
              版本：<span className={`${licenseInfo.licenseType === LicenseType.PERMANENT ? 'text-green-500' : 'text-blue-500'}`}>
                {formatLicenseType(licenseInfo.licenseType)}
              </span>
            </p>
            <p className="text-xs text-gray-600 dark:text-gray-400">
              已同步：{licenseInfo.usedSyncCount} / {licenseInfo.maxSyncCount === Infinity ? '无限制' : licenseInfo.maxSyncCount} 篇
            </p>
            {!licenseInfo.isValid && (
              <p className="text-xs text-red-500 mt-1">{licenseInfo.errorMsg}</p>
            )}
          </div>
        )}

        {/* 运行状态 */}
        <div className="mb-4">
          <p className="text-sm text-gray-600 dark:text-gray-400">
            账号状态：{isLoggedIn ? <span className="text-green-500">已登录</span> : <span className="text-red-500">未登录</span>}
          </p>
          <p className="text-sm text-gray-600 dark:text-gray-400">
            同步状态：{syncStatus ? <span className="text-green-500">运行中</span> : <span className="text-gray-500">未运行</span>}
          </p>
        </div>

        {/* 操作按钮 */}
        <div className="space-y-2">
          <button
            onClick={openSidePanel}
            className="w-full py-2 bg-red-500 text-white rounded-md hover:bg-red-600 transition-colors font-medium"
          >
            打开同步控制面板
          </button>
          <button
            onClick={openOptionsPage}
            className="w-full py-2 bg-gray-200 dark:bg-gray-700 text-gray-800 dark:text-white rounded-md hover:bg-gray-300 dark:hover:bg-gray-600 transition-colors text-sm"
          >
            全局设置
          </button>
        </div>

        <div className="mt-4 text-xs text-gray-400">
          <p>© 2024 Rednote2Notion | 请先登录小红书网页版</p>
        </div>
      </div>
    </div>
  );
};

export default Popup;

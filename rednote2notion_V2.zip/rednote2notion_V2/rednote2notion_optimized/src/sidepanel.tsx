import React, { useState, useEffect } from 'react';
import { MessageType, platformConfig } from './lib/types';
import './style.css';

const SidePanel = () => {
  // 状态管理
  const [userInfo, setUserInfo] = useState<{ userId: string; nickname: string } | null>(null);
  const [notionConfig, setNotionConfig] = useState({
    apiKey: '',
    databaseId: ''
  });
  const [openaiConfig, setOpenaiConfig] = useState({
    apiKey: '',
    enableAIClassify: false
  });
  const [syncStatus, setSyncStatus] = useState<Record<string, boolean>>({});
  const [lastSyncTime, setLastSyncTime] = useState<Record<string, number>>({});
  const [loading, setLoading] = useState(false);

  // 初始化加载配置
  useEffect(() => {
    loadConfig();
  }, []);

  // 加载本地存储配置
  const loadConfig = async () => {
    const storageData = await chrome.storage.local.get([
      'notion_api_key',
      'notion_database_id',
      'openai_api_key',
      'openai_enable_classify',
      'sync-rednote-post-to-notion',
      'sync-rednote-bookmark-to-notion',
      'sync-rednote-like-to-notion',
      'sync-rednote-post-to-notion_last_time',
      'sync-rednote-bookmark-to-notion_last_time',
      'sync-rednote-like-to-notion_last_time',
      'current_user'
    ]);

    setNotionConfig({
      apiKey: storageData.notion_api_key || '',
      databaseId: storageData.notion_database_id || ''
    });

    setOpenaiConfig({
      apiKey: storageData.openai_api_key || '',
      enableAIClassify: storageData.openai_enable_classify || false
    });

    setSyncStatus({
      post: storageData['sync-rednote-post-to-notion'] || false,
      bookmark: storageData['sync-rednote-bookmark-to-notion'] || false,
      like: storageData['sync-rednote-like-to-notion'] || false
    });

    setLastSyncTime({
      post: storageData['sync-rednote-post-to-notion_last_time'] || 0,
      bookmark: storageData['sync-rednote-bookmark-to-notion_last_time'] || 0,
      like: storageData['sync-rednote-like-to-notion_last_time'] || 0
    });

    setUserInfo(storageData.current_user || null);
  };

  // 保存配置
  const saveConfig = async () => {
    setLoading(true);
    await chrome.storage.local.set({
      'notion_api_key': notionConfig.apiKey,
      'notion_database_id': notionConfig.databaseId,
      'openai_api_key': openaiConfig.apiKey,
      'openai_enable_classify': openaiConfig.enableAIClassify
    });
    setLoading(false);
    alert('配置保存成功');
  };

  // 启动同步
  const startSync = async (platform: 'rednotePost' | 'rednoteBookmark' | 'rednoteLike') => {
    if (!notionConfig.apiKey || !notionConfig.databaseId) {
      alert('请先配置Notion API Key和数据库ID');
      return;
    }

    await chrome.runtime.sendMessage({
      name: MessageType.SYNC_TO_NOTION,
      data: {
        platform,
        notionApiKey: notionConfig.apiKey,
        notionDatabaseId: notionConfig.databaseId,
        openaiApiKey: openaiConfig.apiKey,
        enableAIClassify: openaiConfig.enableAIClassify
      }
    });

    await loadConfig();
  };

  // 停止所有同步
  const stopAllSync = async () => {
    await chrome.runtime.sendMessage({
      name: MessageType.STOP_ALL_SYNC
    });
    await loadConfig();
  };

  // 清除缓存
  const clearCache = async () => {
    if (confirm('确定要清除所有同步缓存吗？清除后将从头开始同步')) {
      await chrome.runtime.sendMessage({
        name: MessageType.CLEAR_CACHE
      });
      await loadConfig();
      alert('缓存清除成功');
    }
  };

  // 格式化时间
  const formatTime = (timestamp: number) => {
    if (!timestamp) return '从未同步';
    return new Date(timestamp).toLocaleString();
  };

  return (
    <div className="w-full min-h-screen bg-gray-50 dark:bg-gray-900 p-4">
      <div className="max-w-full mx-auto">
        {/* 头部 */}
        <div className="text-center mb-6">
          <h1 className="text-2xl font-bold text-red-500 mb-2">Rednote2Notion</h1>
          <p className="text-sm text-gray-600 dark:text-gray-400">同步小红书内容到Notion，AI智能分类</p>
          {userInfo && (
            <p className="text-sm text-gray-600 dark:text-gray-400 mt-2">
              当前账号：{userInfo.nickname}
            </p>
          )}
        </div>

        {/* Notion配置 */}
        <div className="bg-white dark:bg-gray-800 rounded-lg p-4 mb-4 shadow-sm">
          <h2 className="text-lg font-semibold mb-3 text-gray-800 dark:text-white">Notion 配置</h2>
          <div className="space-y-3">
            <div>
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                Notion API Key
              </label>
              <input
                type="password"
                value={notionConfig.apiKey}
                onChange={(e) => setNotionConfig({ ...notionConfig, apiKey: e.target.value })}
                className="w-full px-3 py-2 border border-gray-300 rounded-md dark:bg-gray-700 dark:border-gray-600 dark:text-white"
                placeholder="请输入Notion Internal Integration Token"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                Notion 数据库ID
              </label>
              <input
                type="text"
                value={notionConfig.databaseId}
                onChange={(e) => setNotionConfig({ ...notionConfig, databaseId: e.target.value })}
                className="w-full px-3 py-2 border border-gray-300 rounded-md dark:bg-gray-700 dark:border-gray-600 dark:text-white"
                placeholder="请输入Notion数据库ID"
              />
            </div>
          </div>
        </div>

        {/* AI分类配置 */}
        <div className="bg-white dark:bg-gray-800 rounded-lg p-4 mb-4 shadow-sm">
          <h2 className="text-lg font-semibold mb-3 text-gray-800 dark:text-white">AI 分类配置</h2>
          <div className="space-y-3">
            <div>
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                OpenAI API Key
              </label>
              <input
                type="password"
                value={openaiConfig.apiKey}
                onChange={(e) => setOpenaiConfig({ ...openaiConfig, apiKey: e.target.value })}
                className="w-full px-3 py-2 border border-gray-300 rounded-md dark:bg-gray-700 dark:border-gray-600 dark:text-white"
                placeholder="请输入OpenAI API Key"
              />
            </div>
            <div className="flex items-center">
              <input
                type="checkbox"
                id="enableAI"
                checked={openaiConfig.enableAIClassify}
                onChange={(e) => setOpenaiConfig({ ...openaiConfig, enableAIClassify: e.target.checked })}
                className="w-4 h-4 text-red-500 rounded"
              />
              <label htmlFor="enableAI" className="ml-2 text-sm text-gray-700 dark:text-gray-300">
                启用AI智能分类
              </label>
            </div>
          </div>
        </div>

        {/* 同步管理 */}
        <div className="bg-white dark:bg-gray-800 rounded-lg p-4 mb-4 shadow-sm">
          <h2 className="text-lg font-semibold mb-3 text-gray-800 dark:text-white">同步管理</h2>
          <div className="space-y-4">
            {/* 个人帖子同步 */}
            <div className="flex items-center justify-between p-3 border border-gray-200 dark:border-gray-700 rounded-lg">
              <div>
                <h3 className="font-medium text-gray-800 dark:text-white">个人帖子</h3>
                <p className="text-xs text-gray-500 dark:text-gray-400">
                  最后同步：{formatTime(lastSyncTime.post)}
                </p>
              </div>
              <button
                onClick={() => startSync('rednotePost')}
                disabled={syncStatus.post}
                className={`px-4 py-2 rounded-md text-white ${syncStatus.post ? 'bg-gray-400 cursor-not-allowed' : 'bg-red-500 hover:bg-red-600'}`}
              >
                {syncStatus.post ? '同步中' : '启动同步'}
              </button>
            </div>

            {/* 收藏同步 */}
            <div className="flex items-center justify-between p-3 border border-gray-200 dark:border-gray-700 rounded-lg">
              <div>
                <h3 className="font-medium text-gray-800 dark:text-white">收藏内容</h3>
                <p className="text-xs text-gray-500 dark:text-gray-400">
                  最后同步：{formatTime(lastSyncTime.bookmark)}
                </p>
              </div>
              <button
                onClick={() => startSync('rednoteBookmark')}
                disabled={syncStatus.bookmark}
                className={`px-4 py-2 rounded-md text-white ${syncStatus.bookmark ? 'bg-gray-400 cursor-not-allowed' : 'bg-red-500 hover:bg-red-600'}`}
              >
                {syncStatus.bookmark ? '同步中' : '启动同步'}
              </button>
            </div>

            {/* 点赞同步 */}
            <div className="flex items-center justify-between p-3 border border-gray-200 dark:border-gray-700 rounded-lg">
              <div>
                <h3 className="font-medium text-gray-800 dark:text-white">点赞内容</h3>
                <p className="text-xs text-gray-500 dark:text-gray-400">
                  最后同步：{formatTime(lastSyncTime.like)}
                </p>
              </div>
              <button
                onClick={() => startSync('rednoteLike')}
                disabled={syncStatus.like}
                className={`px-4 py-2 rounded-md text-white ${syncStatus.like ? 'bg-gray-400 cursor-not-allowed' : 'bg-red-500 hover:bg-red-600'}`}
              >
                {syncStatus.like ? '同步中' : '启动同步'}
              </button>
            </div>
          </div>

          <div className="flex gap-2 mt-4">
            <button
              onClick={saveConfig}
              disabled={loading}
              className="flex-1 px-4 py-2 bg-blue-500 text-white rounded-md hover:bg-blue-600 disabled:bg-gray-400"
            >
              {loading ? '保存中...' : '保存配置'}
            </button>
            <button
              onClick={stopAllSync}
              className="flex-1 px-4 py-2 bg-gray-500 text-white rounded-md hover:bg-gray-600"
            >
              停止全部同步
            </button>
            <button
              onClick={clearCache}
              className="flex-1 px-4 py-2 bg-orange-500 text-white rounded-md hover:bg-orange-600"
            >
              清除缓存
            </button>
          </div>
        </div>

        {/* 底部说明 */}
        <div className="text-center text-xs text-gray-500 dark:text-gray-400 mt-6">
          <p>Rednote2Notion v1.0.3 | 请确保已登录小红书网页版</p>
        </div>
      </div>
    </div>
  );
};

export default SidePanel;

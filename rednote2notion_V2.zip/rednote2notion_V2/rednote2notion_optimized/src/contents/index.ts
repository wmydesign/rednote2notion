﻿import { MessageType, KnowledgeType } from '../lib/types';

// 页面加载完成后初始化
window.addEventListener('load', () => {
  initContentScript();
});

// 初始化内容脚本
const initContentScript = async () => {
  console.log('Rednote2Notion V2.0 Content Script 已加载');
  await checkUserLoginStatus();
  listenAccountSwitch();
  listenRuntimeMessage();
  injectRequestHeaderHook();
};

// 检查用户登录状态，获取当前登录用户信息
const checkUserLoginStatus = async () => {
  try {
    const response = await fetch('https://edith.xiaohongshu.com/api/sns/web/v2/user/me', {
      credentials: 'include',
      headers: {
        'Content-Type': 'application/json',
        'Referer': 'https://www.xiaohongshu.com/',
        'Origin': 'https://www.xiaohongshu.com'
      }
    });

    if (response.ok) {
      const data = await response.json();
      if (data.code === 0 && data.data) {
        const userInfo = {
          userId: data.data.user_id,
          nickname: data.data.nickname,
          avatar: data.data.imageb || data.data.images
        };
        // 通知后台用户登录信息
        chrome.runtime.sendMessage({
          name: MessageType.ACCOUNT_SWITCH,
          data: userInfo
        });
      }
    }
  } catch (error) {
    console.error('获取用户信息失败', error);
  }
};

// 监听账号切换+页面路由变化
const listenAccountSwitch = () => {
  let lastUserId = '';
  // 定时检测账号状态
  const checkAccountChange = setInterval(async () => {
    try {
      const response = await fetch('https://edith.xiaohongshu.com/api/sns/web/v2/user/me', {
        credentials: 'include',
        headers: {
          'Content-Type': 'application/json',
          'Referer': 'https://www.xiaohongshu.com/',
          'Origin': 'https://www.xiaohongshu.com'
        }
      });
      if (response.ok) {
        const data = await response.json();
        if (data.code === 0 && data.data) {
          const currentUserId = data.data.user_id;
          if (lastUserId && lastUserId !== currentUserId) {
            // 账号发生切换，通知后台
            chrome.runtime.sendMessage({
              name: MessageType.ACCOUNT_SWITCH,
              data: {
                userId: currentUserId,
                nickname: data.data.nickname,
                avatar: data.data.imageb || data.data.images
              }
            });
          }
          lastUserId = currentUserId;
        }
      }
    } catch (error) {
      console.error('账号切换检测失败', error);
    }
  }, 5000);

  // 页面卸载时清除定时器
  window.addEventListener('beforeunload', () => {
    clearInterval(checkAccountChange);
  });
};

// 注入请求头钩子，模拟原生请求，降低风控风险
const injectRequestHeaderHook = () => {
  // 重写XMLHttpRequest，添加真实浏览器请求头
  const originalXHROpen = XMLHttpRequest.prototype.open;
  XMLHttpRequest.prototype.open = function(...args) {
    this.addEventListener('readystatechange', () => {
      if (this.readyState === 1) {
        this.setRequestHeader('Accept', 'application/json, text/plain, */*');
        this.setRequestHeader('Accept-Language', 'zh-CN,zh;q=0.9,en;q=0.8');
        this.setRequestHeader('sec-ch-ua', '"Chromium";v="124", "Google Chrome";v="124", "Not-A.Brand";v="99"');
        this.setRequestHeader('sec-ch-ua-mobile', '?0');
        this.setRequestHeader('sec-ch-ua-platform', '"Windows"');
        this.setRequestHeader('Sec-Fetch-Dest', 'empty');
        this.setRequestHeader('Sec-Fetch-Mode', 'cors');
        this.setRequestHeader('Sec-Fetch-Site', 'same-site');
      }
    });
    return originalXHROpen.apply(this, args);
  };
};

// 监听来自后台的消息
const listenRuntimeMessage = () => {
  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    switch (message.name) {
      case MessageType.GET_COOKIE:
        // 获取小红书Cookie
        sendResponse(document.cookie);
        break;
      case MessageType.GET_ALBUM_LIST:
        // 获取收藏专辑列表
        fetch('https://edith.xiaohongshu.com/api/sns/web/v1/album/list', {
          method: 'POST',
          credentials: 'include',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ page_size: 100, cursor: '' })
        })
        .then(res => res.json())
        .then(data => sendResponse({ success: true, data }))
        .catch(err => sendResponse({ success: false, error: err.message }));
        break;
      case MessageType.GET_NOTE_DETAIL:
        // 获取笔记详情
        const noteId = message.data.noteId;
        fetch(`https://edith.xiaohongshu.com/api/sns/web/v1/feed/note_detail?note_id=${noteId}`, {
          method: 'GET',
          credentials: 'include',
          headers: { 'Content-Type': 'application/json' }
        })
        .then(res => res.json())
        .then(data => sendResponse({ success: true, data }))
        .catch(err => sendResponse({ success: false, error: err.message }));
        break;
      default:
        break;
    }
    return true;
  });
};

// 消息类型枚举
export enum MessageType {
  SYNC_TO_NOTION = 'sync-to-notion',
  GET_COOKIE = 'get-cookie',
  ACCOUNT_SWITCH = 'account-switch',
  STOP_ALL_SYNC = 'stop-all-sync',
  CLEAR_CACHE = 'clear-cache',
  GET_ALBUM_LIST = 'get-album-list',
  GET_NOTE_DETAIL = 'get-note-detail'
}

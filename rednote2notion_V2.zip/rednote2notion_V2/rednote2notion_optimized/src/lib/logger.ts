﻿export enum LogLevel {
  DEBUG = 'debug',
  INFO = 'info',
  WARN = 'warn',
  ERROR = 'error'
}

export interface LogItem {
  id: string;
  timestamp: number;
  level: LogLevel;
  module: string;
  message: string;
  data?: any;
}

// 日志存储上限
const MAX_LOG_COUNT = 1000;
// 日志存储key
const LOG_STORAGE_KEY = 'rednote2notion_logs';

/**
 * 写入日志
 * @param level 日志级别
 * @param module 模块名称
 * @param message 日志信息
 * @param data 附加数据
 */
export const writeLog = async (
  level: LogLevel,
  module: string,
  message: string,
  data?: any
) => {
  try {
    // 读取现有日志
    const storageData = await chrome.storage.local.get(LOG_STORAGE_KEY);
    const logs: LogItem[] = storageData[LOG_STORAGE_KEY] || [];

    // 新增日志
    const newLog: LogItem = {
      id: Date.now().toString() + Math.random().toString(36).slice(2, 8),
      timestamp: Date.now(),
      level,
      module,
      message,
      data: data ? JSON.stringify(data) : undefined
    };

    // 新增到头部，超出上限删除尾部
    logs.unshift(newLog);
    if (logs.length > MAX_LOG_COUNT) {
      logs.splice(MAX_LOG_COUNT);
    }

    // 保存到本地存储
    await chrome.storage.local.set({ [LOG_STORAGE_KEY]: logs });

    // 控制台输出
    const consoleMethod = {
      [LogLevel.DEBUG]: console.debug,
      [LogLevel.INFO]: console.info,
      [LogLevel.WARN]: console.warn,
      [LogLevel.ERROR]: console.error
    }[level];
    consoleMethod(`[${level.toUpperCase()}] [${module}] ${message}`, data || '');

  } catch (error) {
    console.error('日志写入失败', error);
  }
};

/**
 * 快捷日志方法
 */
export const logger = {
  debug: (module: string, message: string, data?: any) => writeLog(LogLevel.DEBUG, module, message, data),
  info: (module: string, message: string, data?: any) => writeLog(LogLevel.INFO, module, message, data),
  warn: (module: string, message: string, data?: any) => writeLog(LogLevel.WARN, module, message, data),
  error: (module: string, message: string, data?: any) => writeLog(LogLevel.ERROR, module, message, data)
};

/**
 * 获取所有日志
 * @returns 日志列表
 */
export const getLogs = async (): Promise<LogItem[]> => {
  const storageData = await chrome.storage.local.get(LOG_STORAGE_KEY);
  return storageData[LOG_STORAGE_KEY] || [];
};

/**
 * 清空日志
 */
export const clearLogs = async () => {
  await chrome.storage.local.remove(LOG_STORAGE_KEY);
};

/**
 * 导出日志为JSON文件
 */
export const exportLogs = async () => {
  const logs = await getLogs();
  const dataStr = JSON.stringify(logs, null, 2);
  const dataBlob = new Blob([dataStr], { type: 'application/json' });
  const url = URL.createObjectURL(dataBlob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `rednote2notion_logs_${new Date().toISOString().split('T')[0]}.json`;
  a.click();
  URL.revokeObjectURL(url);
};

import { encryptLicense, decryptLicense, sha256Hash, md5Hash } from './crypto';
import { v4 as uuidv4 } from 'uuid';

// ==================== 类型定义 ====================
export enum LicenseType {
  FREE = 'free',
  TRIAL = 'trial',
  PERMANENT = 'permanent'
}

export interface LicenseInfo {
  licenseCode: string;
  licenseType: LicenseType;
  activateTime: number;
  expireTime: number;
  deviceFingerprint: string;
  maxSyncCount: number;
  usedSyncCount: number;
  isValid: boolean;
  isActivated: boolean;
  errorMsg?: string;
}

export interface LicenseGenerateConfig {
  licenseType: LicenseType;
  validDays?: number;
  deviceFingerprint?: string;
  batchCount?: number;
}

export interface LicenseParseResult {
  licenseId: string;
  licenseType: LicenseType;
  generateTime: number;
  expireTime: number;
  deviceFingerprint: string;
  isActivated: boolean;
  isValid: boolean;
  errorMsg?: string;
}

// ==================== 常量配置 ====================
export const FREE_VERSION_MAX_SYNC = 5;
export const TRIAL_DEFAULT_DAYS = 7;
export const PERMANENT_VALID_YEARS = 99;
export const UNACTIVATED_DEVICE_FLAG = 'UNACTIVATED_CARD';
export const LICENSE_STORAGE_KEY = 'rednote_license_code';
export const LICENSE_USED_COUNT_KEY = 'license_used_sync_count';
export const LICENSE_ACTIVATED_KEY = 'rednote_license_activated';

// ==================== 工具函数 ====================
/**
 * 生成设备指纹（防倒卖核心，绑定浏览器环境）
 * @returns 设备唯一指纹
 */
export const generateDeviceFingerprint = async (): Promise<string> => {
  try {
    const runtimeId = chrome.runtime.id;
    const userAgent = navigator.userAgent;
    const platform = navigator.platform;
    const hardwareConcurrency = navigator.hardwareConcurrency;
    const language = navigator.language;
    const screenResolution = `${screen.width}x${screen.height}`;
    const rawFingerprint = `${runtimeId}_${userAgent}_${platform}_${hardwareConcurrency}_${language}_${screenResolution}`;
    
    const hash = await sha256Hash(rawFingerprint);
    return hash.slice(0, 16);
  } catch (error) {
    console.error('生成设备指纹失败', error);
    return md5Hash(`${chrome.runtime.id}_${Date.now()}`).slice(0, 16);
  }
};

/**
 * 生成未激活授权信息（用于无授权码时的默认状态）
 */
const createUnactivatedLicenseInfo = async (): Promise<LicenseInfo> => {
  const deviceFingerprint = await generateDeviceFingerprint();
  return {
    licenseCode: '',
    licenseType: LicenseType.FREE,
    activateTime: 0,
    expireTime: 0,
    deviceFingerprint,
    maxSyncCount: 0,
    usedSyncCount: 0,
    isValid: false,
    isActivated: false,
    errorMsg: '请输入授权码并激活后使用'
  };
};

/**
 * ==================== 卖家核心：生成授权码/卡密 ====================
 * 支持单条/批量生成，支持预生成未激活卡密
 */
export const generateLicenseCode = async (config: LicenseGenerateConfig): Promise<string[]> => {
  const { licenseType, validDays, deviceFingerprint, batchCount = 1 } = config;
  const generatedCodes: string[] = [];

  for (let i = 0; i < batchCount; i++) {
    const licenseId = uuidv4().replace(/-/g, '');
    const generateTime = Date.now();
    let expireTime = 0;

    // 计算过期时间
    if (licenseType === LicenseType.TRIAL) {
      const days = validDays || TRIAL_DEFAULT_DAYS;
      expireTime = deviceFingerprint 
        ? generateTime + days * 24 * 60 * 60 * 1000
        : generateTime + 365 * 24 * 60 * 60 * 1000;
    } else if (licenseType === LicenseType.PERMANENT) {
      expireTime = generateTime + PERMANENT_VALID_YEARS * 365 * 24 * 60 * 60 * 1000;
    } else {
      // 免费版：99年有效期
      expireTime = generateTime + 99 * 365 * 24 * 60 * 60 * 1000;
    }

    // 构建授权码原始数据
    const rawLicense = {
      licenseId,
      licenseType,
      generateTime,
      expireTime,
      deviceFingerprint: deviceFingerprint || UNACTIVATED_DEVICE_FLAG,
      validDays: licenseType === LicenseType.TRIAL ? validDays || TRIAL_DEFAULT_DAYS : 0,
      isPreGenerated: !deviceFingerprint
    };

    const licenseStr = JSON.stringify(rawLicense);
    const licenseCode = encryptLicense(licenseStr);
    generatedCodes.push(licenseCode);
  }

  return generatedCodes;
};

/**
 * 解析授权码信息（卖家售后校验用）
 */
export const parseLicenseCode = async (licenseCode: string): Promise<LicenseParseResult> => {
  const defaultResult: LicenseParseResult = {
    licenseId: '',
    licenseType: LicenseType.FREE,
    generateTime: 0,
    expireTime: 0,
    deviceFingerprint: '',
    isActivated: false,
    isValid: false,
    errorMsg: '授权码格式错误'
  };

  if (!licenseCode || licenseCode.trim() === '') {
    return { ...defaultResult, errorMsg: '授权码不能为空' };
  }

  try {
    const decryptedStr = decryptLicense(licenseCode);
    const licenseData = JSON.parse(decryptedStr);

    if (!licenseData.licenseId || !licenseData.licenseType) {
      return { ...defaultResult, errorMsg: '授权码无效，非官方生成' };
    }

    const isActivated = licenseData.deviceFingerprint !== UNACTIVATED_DEVICE_FLAG;
    const now = Date.now();
    let isValid = true;
    let errorMsg = '';

    if (licenseData.expireTime < now) {
      isValid = false;
      errorMsg = '授权码已过期';
    }

    return {
      licenseId: licenseData.licenseId,
      licenseType: licenseData.licenseType,
      generateTime: licenseData.generateTime,
      expireTime: licenseData.expireTime,
      deviceFingerprint: licenseData.deviceFingerprint,
      isActivated,
      isValid,
      errorMsg
    };

  } catch (error: any) {
    return { ...defaultResult, errorMsg: `解析失败：${error.message}` };
  }
};

/**
 * 激活预生成卡密，绑定当前设备
 * 【核心修改】所有版本都必须激活
 */
export const activateLicenseCode = async (licenseCode: string): Promise<LicenseInfo> => {
  const deviceFingerprint = await generateDeviceFingerprint();
  const unactivatedLicense = await createUnactivatedLicenseInfo();

  try {
    const parseResult = await parseLicenseCode(licenseCode);
    if (!parseResult.isValid) {
      return { ...unactivatedLicense, errorMsg: parseResult.errorMsg };
    }

    // 检查是否已激活
    if (parseResult.isActivated) {
      // 已激活，检查是否为当前设备
      if (parseResult.deviceFingerprint !== deviceFingerprint) {
        return { ...unactivatedLicense, errorMsg: '该授权码已被其他设备激活，禁止倒卖' };
      }
      // 当前设备已激活，直接返回授权信息
      return await verifyLicenseCode(licenseCode);
    }

    // 解密原始数据
    const decryptedStr = decryptLicense(licenseCode);
    const licenseData = JSON.parse(decryptedStr);

    // 重新计算有效期（体验版激活后开始计时）
    const now = Date.now();
    let newExpireTime = licenseData.expireTime;
    if (licenseData.licenseType === LicenseType.TRIAL) {
      const validDays = licenseData.validDays || TRIAL_DEFAULT_DAYS;
      newExpireTime = now + validDays * 24 * 60 * 60 * 1000;
    }

    // 绑定当前设备指纹，生成新的授权码
    const newLicenseData = {
      ...licenseData,
      deviceFingerprint,
      expireTime: newExpireTime,
      activateTime: now,
      isPreGenerated: false
    };

    const newLicenseStr = JSON.stringify(newLicenseData);
    const newLicenseCode = encryptLicense(newLicenseStr);

    // 保存激活后的授权码
    await saveLicenseCode(newLicenseCode);
    await chrome.storage.local.set({
      [LICENSE_ACTIVATED_KEY]: true,
      [LICENSE_USED_COUNT_KEY]: 0
    });

    // 计算最大同步数量
    let maxSyncCount = Infinity;
    if (newLicenseData.licenseType === LicenseType.FREE) {
      maxSyncCount = FREE_VERSION_MAX_SYNC;
    }

    return {
      licenseCode: newLicenseCode,
      licenseType: newLicenseData.licenseType,
      activateTime: now,
      expireTime: newExpireTime,
      deviceFingerprint,
      maxSyncCount,
      usedSyncCount: 0,
      isValid: true,
      isActivated: true
    };

  } catch (error: any) {
    return { ...unactivatedLicense, errorMsg: `激活失败：${error.message}` };
  }
};

/**
 * 校验授权码（插件核心校验逻辑）
 * 【核心修改】所有版本都必须激活后才能使用，无授权码时返回无效状态
 */
export const verifyLicenseCode = async (licenseCode: string): Promise<LicenseInfo> => {
  const deviceFingerprint = await generateDeviceFingerprint();
  const unactivatedLicense = await createUnactivatedLicenseInfo();

  // 【修改】无授权码，返回未激活状态，禁止使用
  if (!licenseCode || licenseCode.trim() === '') {
    return unactivatedLicense;
  }

  try {
    const decryptedStr = decryptLicense(licenseCode);
    const licenseData = JSON.parse(decryptedStr);

    // 校验是否为未激活卡密
    if (licenseData.deviceFingerprint === UNACTIVATED_DEVICE_FLAG) {
      return {
        ...unactivatedLicense,
        licenseCode,
        licenseType: licenseData.licenseType,
        isValid: false,
        isActivated: false,
        errorMsg: '授权码未激活，请先点击激活按钮绑定设备'
      };
    }

    // 校验设备绑定
    if (licenseData.deviceFingerprint !== deviceFingerprint) {
      return {
        ...unactivatedLicense,
        isValid: false,
        errorMsg: '授权码已绑定其他设备，禁止倒卖'
      };
    }

    // 校验有效期
    const now = Date.now();
    if (licenseData.expireTime < now) {
      return {
        ...unactivatedLicense,
        isValid: false,
        errorMsg: '授权码已过期，请续费'
      };
    }

    // 读取已同步数量
    const storageData = await chrome.storage.local.get(LICENSE_USED_COUNT_KEY);
    const usedSyncCount = storageData[LICENSE_USED_COUNT_KEY] || 0;

    // 构建授权信息
    const licenseType = licenseData.licenseType as LicenseType;
    let maxSyncCount = Infinity;
    if (licenseType === LicenseType.FREE) {
      maxSyncCount = FREE_VERSION_MAX_SYNC;
    }

    return {
      licenseCode,
      licenseType,
      activateTime: licenseData.activateTime || licenseData.generateTime,
      expireTime: licenseData.expireTime,
      deviceFingerprint,
      maxSyncCount,
      usedSyncCount,
      isValid: true,
      isActivated: true
    };

  } catch (error: any) {
    return {
      ...unactivatedLicense,
      isValid: false,
      errorMsg: '授权码格式错误，非官方生成'
    };
  }
};

/**
 * 更新已同步数量计数
 */
export const updateSyncCount = async (addCount: number = 1) => {
  const storageData = await chrome.storage.local.get(LICENSE_USED_COUNT_KEY);
  const currentCount = storageData[LICENSE_USED_COUNT_KEY] || 0;
  await chrome.storage.local.set({
    [LICENSE_USED_COUNT_KEY]: currentCount + addCount
  });
};

/**
 * 重置同步计数（仅永久版可用）
 */
export const resetSyncCount = async () => {
  await chrome.storage.local.set({
    [LICENSE_USED_COUNT_KEY]: 0
  });
};

/**
 * 保存授权码到本地存储
 */
export const saveLicenseCode = async (licenseCode: string) => {
  await chrome.storage.local.set({
    [LICENSE_STORAGE_KEY]: licenseCode
  });
};

/**
 * 从本地存储读取授权码
 */
export const getLicenseCode = async (): Promise<string> => {
  const storageData = await chrome.storage.local.get(LICENSE_STORAGE_KEY);
  return storageData[LICENSE_STORAGE_KEY] || '';
};

/**
 * 获取当前有效授权信息
 */
export const getCurrentLicense = async (): Promise<LicenseInfo> => {
  const licenseCode = await getLicenseCode();
  return await verifyLicenseCode(licenseCode);
};

/**
 * 检查是否有权限执行同步
 * 【核心修改】所有版本都必须激活后才能使用
 */
export const checkSyncPermission = async (): Promise<{ hasPermission: boolean; errorMsg?: string }> => {
  const license = await getCurrentLicense();

  // 授权无效
  if (!license.isValid) {
    return { hasPermission: false, errorMsg: license.errorMsg || '授权无效，请先激活授权码' };
  }

  // 未激活（所有版本都必须激活）
  if (!license.isActivated) {
    return { hasPermission: false, errorMsg: '授权码未激活，请先绑定设备' };
  }

  // 免费版超出同步上限
  if (license.licenseType === LicenseType.FREE && license.usedSyncCount >= license.maxSyncCount) {
    return { hasPermission: false, errorMsg: `免费版仅支持同步${FREE_VERSION_MAX_SYNC}篇笔记，请升级永久版` };
  }

  return { hasPermission: true };
};

/**
 * 清除授权信息（用于注销/切换账号）
 */
export const clearLicense = async () => {
  await chrome.storage.local.remove([
    LICENSE_STORAGE_KEY,
    LICENSE_USED_COUNT_KEY,
    LICENSE_ACTIVATED_KEY
  ]);
};

﻿import { FilterRule, RednoteNote } from './types';

/**
 * 校验单条笔记是否符合筛选规则
 * @param note 小红书笔记数据
 * @param rules 筛选规则
 * @returns 是否符合规则
 */
export const validateNoteByFilterRules = (note: RednoteNote, rules: FilterRule[]): boolean => {
  // 无规则，默认通过
  if (!rules || rules.length === 0) {
    return true;
  }

  // 遍历所有规则，全部满足才通过
  for (const rule of rules) {
    const { field, operator, value, logic = 'and' } = rule;
    let fieldValue: any;

    // 获取对应字段的值
    switch (field) {
      case 'title':
        fieldValue = note.title || '';
        break;
      case 'desc':
        fieldValue = note.desc || '';
        break;
      case 'tags':
        fieldValue = note.tags || [];
        break;
      case 'publishTime':
        fieldValue = note.publishTime || 0;
        break;
      case 'collectTime':
        fieldValue = note.collectTime || 0;
        break;
      case 'likeCount':
        fieldValue = note.likeCount || 0;
        break;
      case 'collectCount':
        fieldValue = note.collectCount || 0;
        break;
      case 'commentCount':
        fieldValue = note.commentCount || 0;
        break;
      case 'noteType':
        fieldValue = note.noteType || 'normal';
        break;
      case 'authorName':
        fieldValue = note.authorName || '';
        break;
      default:
        fieldValue = '';
    }

    // 执行规则校验
    let isRulePass = false;
    switch (operator) {
      case 'contains':
        // 包含关键词
        isRulePass = String(fieldValue).includes(String(value));
        break;
      case 'notContains':
        // 不包含关键词
        isRulePass = !String(fieldValue).includes(String(value));
        break;
      case 'equals':
        // 等于
        isRulePass = fieldValue === value;
        break;
      case 'notEquals':
        // 不等于
        isRulePass = fieldValue !== value;
        break;
      case 'greaterThan':
        // 大于
        isRulePass = Number(fieldValue) > Number(value);
        break;
      case 'lessThan':
        // 小于
        isRulePass = Number(fieldValue) < Number(value);
        break;
      case 'between':
        // 区间内
        const [min, max] = Array.isArray(value) ? value : String(value).split(',');
        isRulePass = Number(fieldValue) >= Number(min) && Number(fieldValue) <= Number(max);
        break;
      case 'in':
        // 在列表中
        const list = Array.isArray(value) ? value : String(value).split(',');
        isRulePass = list.includes(String(fieldValue));
        break;
      case 'notIn':
        // 不在列表中
        const notInList = Array.isArray(value) ? value : String(value).split(',');
        isRulePass = !notInList.includes(String(fieldValue));
        break;
      case 'tagContains':
        // 标签包含
        if (!Array.isArray(fieldValue)) {
          isRulePass = false;
          break;
        }
        isRulePass = fieldValue.some(tag => String(tag).includes(String(value)));
        break;
      default:
        isRulePass = true;
    }

    // 逻辑处理：and 必须全部通过，or 只要一个通过
    if (logic === 'and' && !isRulePass) {
      return false;
    }
    if (logic === 'or' && isRulePass) {
      return true;
    }
  }

  // 所有规则校验通过
  return true;
};

/**
 * 批量过滤笔记列表
 * @param notes 笔记列表
 * @param rules 筛选规则
 * @returns 过滤后的笔记列表
 */
export const filterNotesByRules = (notes: RednoteNote[], rules: FilterRule[]): RednoteNote[] => {
  if (!rules || rules.length === 0) {
    return notes;
  }
  return notes.filter(note => validateNoteByFilterRules(note, rules));
};

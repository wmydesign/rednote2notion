﻿/**
 * 图片OCR能力封装，支持百度智能云OCR/腾讯云OCR，默认提供百度通用文字识别接口
 */
export interface OCRConfig {
  provider: 'baidu' | 'tencent';
  apiKey: string;
  secretKey: string;
}

export interface OCRResult {
  success: boolean;
  text: string;
  words: string[];
  errorMsg?: string;
}

// 百度OCR access_token缓存
let baiduAccessToken: { token: string; expireTime: number } | null = null;

/**
 * 获取百度OCR access_token
 * @param apiKey 百度API Key
 * @param secretKey 百度Secret Key
 * @returns access_token
 */
const getBaiduAccessToken = async (apiKey: string, secretKey: string): Promise<string> => {
  // 缓存未过期，直接返回
  if (baiduAccessToken && baiduAccessToken.expireTime > Date.now()) {
    return baiduAccessToken.token;
  }

  try {
    const response = await fetch(`https://aip.baidubce.com/oauth/2.0/token?grant_type=client_credentials&client_id=${apiKey}&client_secret=${secretKey}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' }
    });

    const data = await response.json();
    if (data.error) {
      throw new Error(data.error_description);
    }

    // 缓存token，提前1小时过期
    baiduAccessToken = {
      token: data.access_token,
      expireTime: Date.now() + (data.expires_in - 3600) * 1000
    };

    return data.access_token;
  } catch (error) {
    console.error('获取百度OCR Token失败', error);
    throw error;
  }
};

/**
 * 执行图片OCR识别
 * @param imageUrl 图片URL
 * @param config OCR配置
 * @returns 识别结果
 */
export const imageOCR = async (imageUrl: string, config: OCRConfig): Promise<OCRResult> => {
  if (!config.apiKey || !config.secretKey) {
    return {
      success: false,
      text: '',
      words: [],
      errorMsg: 'OCR API配置不完整，请先填写API Key和Secret Key'
    };
  }

  try {
    if (config.provider === 'baidu') {
      const accessToken = await getBaiduAccessToken(config.apiKey, config.secretKey);
      
      // 先下载图片转为base64
      const imageResponse = await fetch(imageUrl);
      const imageBlob = await imageResponse.blob();
      const base64 = await new Promise<string>((resolve, reject) => {
        const reader = new FileReader();
        reader.onloadend = () => resolve(reader.result as string);
        reader.onerror = reject;
        reader.readAsDataURL(imageBlob);
      });
      const imageBase64 = base64.split(',')[1];

      // 调用百度OCR接口
      const ocrResponse = await fetch(`https://aip.baidubce.com/rest/2.0/ocr/v1/general_basic?access_token=${accessToken}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: `image=${encodeURIComponent(imageBase64)}`
      });

      const ocrData = await ocrResponse.json();
      if (ocrData.error_code) {
        throw new Error(ocrData.error_msg);
      }

      const words = ocrData.words_result.map((item: any) => item.words);
      const fullText = words.join('\n');

      return {
        success: true,
        text: fullText,
        words
      };
    }

    // 腾讯云OCR可在此扩展
    return {
      success: false,
      text: '',
      words: [],
      errorMsg: '暂不支持该OCR服务商'
    };

  } catch (error) {
    console.error('OCR识别失败', error);
    return {
      success: false,
      text: '',
      words: [],
      errorMsg: `OCR识别失败：${error.message}`
    };
  }
};

/**
 * 保存OCR配置到本地存储
 * @param config OCR配置
 */
export const saveOCRConfig = async (config: OCRConfig) => {
  await chrome.storage.local.set({
    'rednote_ocr_config': config
  });
};

/**
 * 读取OCR配置
 * @returns OCR配置
 */
export const getOCRConfig = async (): Promise<OCRConfig | null> => {
  const storageData = await chrome.storage.local.get('rednote_ocr_config');
  return storageData.rednote_ocr_config || null;
};

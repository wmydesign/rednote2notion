﻿import { Client } from '@notionhq/client';
import type { RednoteNote, AIProcessResult } from './types';
import { isFullDatabase } from '@notionhq/client';

// 初始化Notion客户端
const createNotionClient = (apiKey: string) => {
  return new Client({
    auth: apiKey,
    // 新增：自动重试配置
    retryOptions: {
      maxRetries: 3,
      retryInterval: 1000,
    }
  });
};

/**
 * 检查并自动创建数据库缺失字段
 * @param apiKey Notion API Key
 * @param databaseId 数据库ID
 * @param fieldNames 需要检查的字段名列表
 * @param fieldType 字段类型，默认富文本
 */
export const ensureDatabaseFields = async (
  apiKey: string,
  databaseId: string,
  fieldConfigs: { name: string; type: any; options?: any[] }[]
) => {
  try {
    const notion = createNotionClient(apiKey);
    const database = await notion.databases.retrieve({ database_id: databaseId });
    
    if (!isFullDatabase(database)) return;
    const existingFields = Object.keys(database.properties);
    const propertiesToAdd: Record<string, any> = {};

    // 遍历需要创建的字段
    for (const config of fieldConfigs) {
      if (!existingFields.includes(config.name)) {
        propertiesToAdd[config.name] = { [config.type]: config.options || {} };
      }
    }

    // 有缺失字段则更新数据库
    if (Object.keys(propertiesToAdd).length > 0) {
      await notion.databases.update({
        database_id: databaseId,
        properties: propertiesToAdd
      });
      console.log('自动创建Notion缺失字段：', Object.keys(propertiesToAdd));
    }

  } catch (error) {
    console.error('检查/创建Notion字段失败', error);
  }
};

/**
 * 创建小红书同步专用数据库（V2.0全字段适配）
 * @param apiKey Notion API Key
 * @param pageId 父页面ID
 * @param customFields 自定义字段（AI加工模板）
 * @returns 数据库ID
 */
export const createNotionDatabase = async (
  apiKey: string,
  pageId: string,
  customFields: { name: string; type: any }[] = []
): Promise<string> => {
  const notion = createNotionClient(apiKey);
  
  // 基础字段配置
  const baseProperties: Record<string, any> = {
    标题: { title: {} },
    分类: { select: {} },
    所属专辑: { select: {} },
    发布时间: { date: {} },
    收藏时间: { date: {} },
    作者: { rich_text: {} },
    作者ID: { rich_text: {} },
    点赞数: { number: { format: 'number' } },
    收藏数: { number: { format: 'number' } },
    评论数: { number: { format: 'number' } },
    分享数: { number: { format: 'number' } },
    原文链接: { url: {} },
    笔记类型: { 
      select: { 
        options: [
          { name: '图文', color: 'blue' },
          { name: '视频', color: 'red' },
          { name: '合集', color: 'purple' },
          { name: '其他', color: 'gray' }
        ] 
      } 
    },
    封面图: { files: {} },
    内容摘要: { rich_text: {} },
    图片OCR内容: { rich_text: {} },
    作者评论补充: { rich_text: {} },
    高赞评论: { rich_text: {} },
    标签: { multi_select: {} },
    同步时间: { date: {} },
    笔记ID: { rich_text: {} },
    同步状态: {
      select: {
        options: [
          { name: '已同步', color: 'green' },
          { name: '同步失败', color: 'red' },
          { name: '待同步', color: 'yellow' }
        ]
      }
    }
  };

  // 合并自定义字段
  customFields.forEach(field => {
    if (!baseProperties[field.name]) {
      baseProperties[field.name] = { [field.type]: {} };
    }
  });

  // 创建数据库
  const response = await notion.databases.create({
    parent: { type: 'page_id', page_id: pageId },
    title: [{ type: 'text', text: { content: '小红书收藏同步库' } }],
    properties: baseProperties
  });
  return response.id;
};

/**
 * 拆分超长文本为多个Notion块（解决Notion单块1000字符限制）
 * @param text 原始文本
 * @param maxLength 单块最大长度，默认900
 * @returns Notion块数组
 */
const splitTextToBlocks = (text: string, maxLength: number = 900): any[] => {
  if (!text || text.trim() === '') return [];
  
  const blocks: any[] = [];
  const textChunks = text.match(new RegExp(`.{1,${maxLength}}`, 'g')) || [];
  
  textChunks.forEach(chunk => {
    blocks.push({
      object: 'block',
      type: 'paragraph',
      paragraph: {
        rich_text: [{ type: 'text', text: { content: chunk } }]
      }
    });
  });
  
  return blocks;
};

/**
 * 写入单条小红书帖子到Notion数据库（V2.0全量适配+异常兜底）
 * @param apiKey Notion API Key
 * @param databaseId 数据库ID
 * @param note 小红书笔记数据
 * @param autoCreateField 是否自动创建缺失字段
 * @returns 页面ID
 */
export const writeNoteToNotion = async (
  apiKey: string,
  databaseId: string,
  note: RednoteNote,
  autoCreateField: boolean = true
): Promise<string> => {
  const notion = createNotionClient(apiKey);
  const now = new Date().toISOString();

  // ==================== 1. 自动创建AI加工字段 ====================
  if (autoCreateField && note.aiProcessResults && note.aiProcessResults.length > 0) {
    const fieldConfigs = note.aiProcessResults.map(result => ({
      name: result.fieldName,
      type: 'rich_text'
    }));
    await ensureDatabaseFields(apiKey, databaseId, fieldConfigs);
  }

  // ==================== 2. 构建数据库属性 ====================
  const properties: any = {
    标题: {
      title: [{ type: 'text', text: { content: note.title?.trim() || '无标题' } }]
    },
    分类: {
      select: { name: note.aiCategory?.trim() || '未分类' }
    },
    发布时间: {
      date: { start: new Date(note.publishTime).toISOString() }
    },
    作者: {
      rich_text: [{ type: 'text', text: { content: note.authorName?.trim() || '未知作者' } }]
    },
    作者ID: {
      rich_text: [{ type: 'text', text: { content: note.authorId || '未知ID' } }]
    },
    点赞数: {
      number: note.likeCount || 0
    },
    收藏数: {
      number: note.collectCount || 0
    },
    评论数: {
      number: note.commentCount || 0
    },
    分享数: {
      number: note.shareCount || 0
    },
    原文链接: {
      url: note.noteUrl
    },
    笔记类型: {
      select: { 
        name: note.noteType === 'video' ? '视频' : 
              note.noteType === 'image' ? '图文' : '其他' 
      }
    },
    标签: {
      multi_select: note.tags?.map(tag => ({ name: tag.trim().slice(0, 90) })).filter(tag => tag.name) || []
    },
    同步时间: {
      date: { start: now }
    },
    笔记ID: {
      rich_text: [{ type: 'text', text: { content: note.id } }]
    },
    同步状态: {
      select: { name: '已同步' }
    }
  };

  // 可选字段处理（无内容则不写入，避免字段报错）
  if (note.albumName) {
    properties.所属专辑 = { select: { name: note.albumName.trim().slice(0, 90) } };
  }
  if (note.collectTime) {
    properties.收藏时间 = { date: { start: new Date(note.collectTime).toISOString() } };
  }
  if (note.coverUrl) {
    try {
      properties.封面图 = {
        files: [{ type: 'external', name: 'cover', external: { url: note.coverUrl } }]
      };
    } catch (e) {
      console.warn('封面图URL无效，跳过', note.coverUrl);
    }
  }
  if (note.desc) {
    properties.内容摘要 = {
      rich_text: [{ type: 'text', text: { content: note.desc.trim().slice(0, 2000) } }]
    };
  }
  if (note.ocrResults && note.ocrResults.length > 0) {
    const fullOCRText = note.ocrResults.map(item => item.text).join('\n\n').slice(0, 2000);
    properties.图片OCR内容 = {
      rich_text: [{ type: 'text', text: { content: fullOCRText } }]
    };
  }
  if (note.authorComments && note.authorComments.length > 0) {
    const authorCommentText = note.authorComments
      .map(item => `[${new Date(item.publishTime).toLocaleString()}]：${item.content}`)
      .join('\n\n')
      .slice(0, 2000);
    properties.作者评论补充 = {
      rich_text: [{ type: 'text', text: { content: authorCommentText } }]
    };
  }
  if (note.comments && note.comments.length > 0) {
    const commentText = note.comments
      .map(item => `@${item.authorName}（点赞${item.likeCount}）：${item.content}`)
      .join('\n\n')
      .slice(0, 2000);
    properties.高赞评论 = {
      rich_text: [{ type: 'text', text: { content: commentText } }]
    };
  }

  // AI加工结果写入属性
  if (note.aiProcessResults && note.aiProcessResults.length > 0) {
    note.aiProcessResults.forEach(result => {
      if (result.fieldName && result.content) {
        properties[result.fieldName] = {
          rich_text: [{ type: 'text', text: { content: result.content.slice(0, 2000) } }]
        };
      }
    });
  }

  // ==================== 3. 构建页面内容块 ====================
  const children: any[] = [];

  // 笔记标题
  children.push({
    object: 'block',
    type: 'heading_1',
    heading_1: {
      rich_text: [{ type: 'text', text: { content: note.title?.trim() || '无标题' } }]
    }
  });

  // 基础信息栏
  children.push({
    object: 'block',
    type: 'callout',
    callout: {
      icon: { type: 'emoji', emoji: '📌' },
      color: 'gray_background',
      rich_text: [
        { type: 'text', text: { content: `作者：${note.authorName} | 发布时间：${new Date(note.publishTime).toLocaleString()}\n` } },
        { type: 'text', text: { content: `点赞：${note.likeCount} | 收藏：${note.collectCount} | 评论：${note.commentCount}\n` } },
        { type: 'text', text: { content: `原文链接：`, link: { url: note.noteUrl } } }
      ]
    }
  });

  // 笔记正文
  if (note.desc) {
    children.push({
      object: 'block',
      type: 'heading_2',
      heading_2: {
        rich_text: [{ type: 'text', text: { content: '📝 笔记正文' } }]
      }
    });
    // 超长正文拆分
    children.push(...splitTextToBlocks(note.desc));
  }

  // 所有图片插入
  if (note.allImages && note.allImages.length > 0) {
    children.push({
      object: 'block',
      type: 'heading_2',
      heading_2: {
        rich_text: [{ type: 'text', text: { content: '🖼️ 笔记原图' } }]
      }
    });
    for (const imageUrl of note.allImages) {
      try {
        children.push({
          object: 'block',
          type: 'image',
          image: {
            type: 'external',
            external: { url: imageUrl }
          }
        });
      } catch (e) {
        console.warn('图片URL无效，跳过', imageUrl);
      }
    }
  }

  // OCR识别内容
  if (note.ocrResults && note.ocrResults.length > 0) {
    children.push({
      object: 'block',
      type: 'heading_2',
      heading_2: {
        rich_text: [{ type: 'text', text: { content: '🔍 图片OCR识别内容' } }]
      }
    });
    note.ocrResults.forEach((result, index) => {
      children.push({
        object: 'block',
        type: 'heading_3',
        heading_3: {
          rich_text: [{ type: 'text', text: { content: `图片${index + 1}识别结果` } }]
        }
      });
      children.push(...splitTextToBlocks(result.text));
    });
  }

  // 作者补充评论
  if (note.authorComments && note.authorComments.length > 0) {
    children.push({
      object: 'block',
      type: 'heading_2',
      heading_2: {
        rich_text: [{ type: 'text', text: { content: '💬 作者补充评论' } }]
      }
    });
    const authorCommentText = note.authorComments
      .map(item => `[${new Date(item.publishTime).toLocaleString()}]：${item.content}`)
      .join('\n\n');
    children.push(...splitTextToBlocks(authorCommentText));
  }

  // 高赞评论
  if (note.comments && note.comments.length > 0) {
    children.push({
      object: 'block',
      type: 'heading_2',
      heading_2: {
        rich_text: [{ type: 'text', text: { content: '🔥 高赞评论' } }]
      }
    });
    const commentText = note.comments
      .map(item => `@${item.authorName}（点赞${item.likeCount}）：\n${item.content}`)
      .join('\n\n');
    children.push(...splitTextToBlocks(commentText));
  }

  // AI深度加工内容
  if (note.aiProcessResults && note.aiProcessResults.length > 0) {
    children.push({
      object: 'block',
      type: 'heading_2',
      heading_2: {
        rich_text: [{ type: 'text', text: { content: '🤖 AI深度加工内容' } }]
      }
    });
    note.aiProcessResults.forEach(result => {
      children.push({
        object: 'block',
        type: 'heading_3',
        heading_3: {
          rich_text: [{ type: 'text', text: { content: result.fieldName } }]
        }
      });
      children.push(...splitTextToBlocks(result.content));
    });
  }

  // 原文链接兜底
  children.push({
    object: 'block',
    type: 'divider',
    divider: {}
  });
  children.push({
    object: 'block',
    type: 'paragraph',
    paragraph: {
      rich_text: [{ type: 'text', text: { content: '🔗 小红书原文链接：', link: { url: note.noteUrl } } }]
    }
  });

  // ==================== 4. 分块写入Notion（解决100块限制） ====================
  const MAX_BLOCKS_PER_REQUEST = 100;
  let pageId = '';

  // 第一步：创建页面基础信息
  const firstBatchBlocks = children.slice(0, MAX_BLOCKS_PER_REQUEST);
  const remainingBlocks = children.slice(MAX_BLOCKS_PER_REQUEST);

  const pageResponse = await notion.pages.create({
    parent: { type: 'database_id', database_id: databaseId },
    properties,
    children: firstBatchBlocks
  });
  pageId = pageResponse.id;

  // 第二步：分批写入剩余内容块
  if (remainingBlocks.length > 0) {
    for (let i = 0; i < remainingBlocks.length; i += MAX_BLOCKS_PER_REQUEST) {
      const batch = remainingBlocks.slice(i, i + MAX_BLOCKS_PER_REQUEST);
      await notion.blocks.children.append({
        block_id: pageId,
        children: batch
      });
      // 限流延迟
      await new Promise(resolve => setTimeout(resolve, 300));
    }
  }

  return pageId;
};

/**
 * 检查帖子是否已同步到Notion（优化：支持多字段查重）
 * @param apiKey Notion API Key
 * @param databaseId 数据库ID
 * @param noteId 小红书帖子ID
 * @returns 是否已同步
 */
export const checkNoteIsSynced = async (
  apiKey: string,
  databaseId: string,
  noteId: string
): Promise<boolean> => {
  try {
    const notion = createNotionClient(apiKey);
    const response = await notion.databases.query({
      database_id: databaseId,
      filter: {
        or: [
          { property: '原文链接', url: { contains: noteId } },
          { property: '笔记ID', rich_text: { equals: noteId } }
        ]
      },
      page_size: 1
    });
    return response.results.length > 0;
  } catch (error) {
    console.error('检查同步状态失败', error);
    // 异常时返回false，重新同步，避免漏同步
    return false;
  }
};

/**
 * 批量更新笔记同步状态
 * @param apiKey Notion API Key
 * @param databaseId 数据库ID
 * @param pageId 页面ID
 * @param status 同步状态
 * @param errorMsg 错误信息
 */
export const updateNoteSyncStatus = async (
  apiKey: string,
  databaseId: string,
  pageId: string,
  status: '已同步' | '同步失败' | '待同步',
  errorMsg?: string
) => {
  try {
    const notion = createNotionClient(apiKey);
    const properties: any = {
      同步状态: { select: { name: status } }
    };
    if (errorMsg) {
      properties.同步错误信息 = { rich_text: [{ type: 'text', text: { content: errorMsg.slice(0, 2000) } }] };
    }
    await notion.pages.update({
      page_id: pageId,
      properties
    });
  } catch (error) {
    console.error('更新同步状态失败', error);
  }
};

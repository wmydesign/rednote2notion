﻿import { RednoteAlbum } from './types';

/**
 * 获取用户所有收藏专辑列表
 * @returns 专辑列表
 */
export const getUserAlbumList = async (): Promise<RednoteAlbum[]> => {
  try {
    const response = await fetch('https://edith.xiaohongshu.com/api/sns/web/v1/album/list', {
      method: 'POST',
      credentials: 'include',
      headers: {
        'Content-Type': 'application/json',
        'Referer': 'https://www.xiaohongshu.com/',
        'Origin': 'https://www.xiaohongshu.com'
      },
      body: JSON.stringify({
        page_size: 100, // 最多获取100个专辑，覆盖绝大多数用户场景
        cursor: ''
      })
    });

    if (!response.ok) {
      throw new Error(`获取专辑列表失败: ${response.status}`);
    }

    const data = await response.json();
    if (data.code !== 0) {
      throw new Error(`API返回错误: ${data.msg}`);
    }

    const albums = data.data?.albums || [];
    return albums.map((album: any) => ({
      albumId: album.id,
      albumName: album.name,
      coverUrl: album.cover?.url || '',
      noteCount: album.note_count || 0,
      updateTime: album.update_time || 0,
      isDefault: album.is_default || false
    }));

  } catch (error) {
    console.error('获取收藏专辑列表失败', error);
    return [];
  }
};

/**
 * 获取指定专辑内的笔记列表
 * @param albumId 专辑ID
 * @param cursor 分页游标
 * @param pageSize 每页数量
 * @returns 笔记列表+下一页游标
 */
export const getAlbumNoteList = async (
  albumId: string,
  cursor: string = '',
  pageSize: number = 20
): Promise<{ notes: any[]; nextCursor: string; hasMore: boolean }> => {
  try {
    const response = await fetch('https://edith.xiaohongshu.com/api/sns/web/v1/album/note/list', {
      method: 'POST',
      credentials: 'include',
      headers: {
        'Content-Type': 'application/json',
        'Referer': 'https://www.xiaohongshu.com/',
        'Origin': 'https://www.xiaohongshu.com'
      },
      body: JSON.stringify({
        album_id: albumId,
        cursor,
        page_size: pageSize
      })
    });

    if (!response.ok) {
      throw new Error(`获取专辑笔记失败: ${response.status}`);
    }

    const data = await response.json();
    if (data.code !== 0) {
      throw new Error(`API返回错误: ${data.msg}`);
    }

    return {
      notes: data.data?.notes || [],
      nextCursor: data.data?.cursor || '',
      hasMore: data.data?.has_more || false
    };

  } catch (error) {
    console.error('获取专辑笔记列表失败', error);
    return {
      notes: [],
      nextCursor: '',
      hasMore: false
    };
  }
};

/**
 * 获取笔记详情（含所有图片、评论、完整正文）
 * @param noteId 笔记ID
 * @returns 笔记详情
 */
export const getNoteDetail = async (noteId: string): Promise<any> => {
  try {
    const response = await fetch(`https://edith.xiaohongshu.com/api/sns/web/v1/feed/note_detail?note_id=${noteId}`, {
      method: 'GET',
      credentials: 'include',
      headers: {
        'Content-Type': 'application/json',
        'Referer': 'https://www.xiaohongshu.com/',
        'Origin': 'https://www.xiaohongshu.com'
      }
    });

    if (!response.ok) {
      throw new Error(`获取笔记详情失败: ${response.status}`);
    }

    const data = await response.json();
    if (data.code !== 0) {
      throw new Error(`API返回错误: ${data.msg}`);
    }

    return data.data;

  } catch (error) {
    console.error('获取笔记详情失败', error);
    return null;
  }
};

/**
 * 获取笔记评论列表
 * @param noteId 笔记ID
 * @param cursor 分页游标
 * @param pageSize 每页数量
 * @returns 评论列表
 */
export const getNoteCommentList = async (
  noteId: string,
  cursor: string = '',
  pageSize: number = 20
): Promise<{ comments: any[]; nextCursor: string; hasMore: boolean }> => {
  try {
    const response = await fetch('https://edith.xiaohongshu.com/api/sns/web/v2/comment/page', {
      method: 'POST',
      credentials: 'include',
      headers: {
        'Content-Type': 'application/json',
        'Referer': 'https://www.xiaohongshu.com/',
        'Origin': 'https://www.xiaohongshu.com'
      },
      body: JSON.stringify({
        note_id: noteId,
        cursor,
        page_size: pageSize,
        top_comment_id: '',
        image_formats: 'jpg,webp,avif'
      })
    });

    if (!response.ok) {
      throw new Error(`获取评论列表失败: ${response.status}`);
    }

    const data = await response.json();
    if (data.code !== 0) {
      throw new Error(`API返回错误: ${data.msg}`);
    }

    return {
      comments: data.data?.comments || [],
      nextCursor: data.data?.cursor || '',
      hasMore: data.data?.has_more || false
    };

  } catch (error) {
    console.error('获取评论列表失败', error);
    return {
      comments: [],
      nextCursor: '',
      hasMore: false
    };
  }
};

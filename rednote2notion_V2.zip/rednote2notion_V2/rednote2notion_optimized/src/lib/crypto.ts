﻿import CryptoJS from 'crypto-js';

// 加密密钥（生产环境请通过环境变量注入，禁止硬编码到代码中）
const SECRET_KEY = import.meta.env.PLASMO_PUBLIC_CRYPTO_KEY || 'rednote2notion_v2_official_2024_secure_key';
const SECRET_IV = import.meta.env.PLASMO_PUBLIC_CRYPTO_IV || 'rednote2notion_v2_iv_2024';
// 授权码专用盐值，与通用加密隔离
const LICENSE_SECRET_KEY = import.meta.env.PLASMO_PUBLIC_LICENSE_KEY || 'rednote2notion_license_secure_2024_v2';
const LICENSE_SECRET_IV = import.meta.env.PLASMO_PUBLIC_LICENSE_IV || 'license_iv_2024_v2';

/**
 * ==================== 通用AES-CBC加密（配置数据用） ====================
 */

/**
 * AES-CBC加密
 * @param data 待加密数据
 * @returns 加密后的字符串
 */
export const encryptAES = (data: string): string => {
  const key = CryptoJS.enc.Utf8.parse(SECRET_KEY);
  const iv = CryptoJS.enc.Utf8.parse(SECRET_IV);
  const encrypted = CryptoJS.AES.encrypt(data, key, {
    iv: iv,
    mode: CryptoJS.mode.CBC,
    padding: CryptoJS.pad.Pkcs7
  });
  return encrypted.toString();
};

/**
 * AES-CBC解密
 * @param encryptedData 加密后的字符串
 * @returns 解密后的原始数据
 */
export const decryptAES = (encryptedData: string): string => {
  try {
    const key = CryptoJS.enc.Utf8.parse(SECRET_KEY);
    const iv = CryptoJS.enc.Utf8.parse(SECRET_IV);
    const decrypted = CryptoJS.AES.decrypt(encryptedData, key, {
      iv: iv,
      mode: CryptoJS.mode.CBC,
      padding: CryptoJS.pad.Pkcs7
    });
    return decrypted.toString(CryptoJS.enc.Utf8);
  } catch (error) {
    console.error('AES解密失败', error);
    throw new Error('数据解密失败，可能已被篡改');
  }
};

/**
 * ==================== 授权码专用加密（防篡改/防倒卖） ====================
 */

/**
 * 授权码加密（专用密钥，与通用加密隔离）
 * @param data 授权原始数据
 * @returns 加密后的授权码
 */
export const encryptLicense = (data: string): string => {
  const key = CryptoJS.enc.Utf8.parse(LICENSE_SECRET_KEY);
  const iv = CryptoJS.enc.Utf8.parse(LICENSE_SECRET_IV);
  // 先加签名防篡改
  const signature = CryptoJS.MD5(data + LICENSE_SECRET_KEY).toString();
  const dataWithSign = JSON.stringify({ data, signature });
  // 双重加密
  const encrypted = CryptoJS.AES.encrypt(dataWithSign, key, {
    iv: iv,
    mode: CryptoJS.mode.CBC,
    padding: CryptoJS.pad.Pkcs7
  });
  // Base64编码后替换特殊字符，方便用户复制
  return encrypted.toString().replace(/\+/g, '-').replace(/\//g, '_').replace(/=/g, '');
};

/**
 * 授权码解密+防篡改校验
 * @param licenseCode 授权码
 * @returns 解密后的授权数据
 */
export const decryptLicense = (licenseCode: string): string => {
  try {
    // 还原Base64特殊字符
    const normalizedCode = licenseCode.replace(/-/g, '+').replace(/_/g, '/');
    // 补全Base64 padding
    const padLength = 4 - (normalizedCode.length % 4);
    const paddedCode = normalizedCode + '='.repeat(padLength < 4 ? padLength : 0);

    const key = CryptoJS.enc.Utf8.parse(LICENSE_SECRET_KEY);
    const iv = CryptoJS.enc.Utf8.parse(LICENSE_SECRET_IV);
    // 解密
    const decrypted = CryptoJS.AES.decrypt(paddedCode, key, {
      iv: iv,
      mode: CryptoJS.mode.CBC,
      padding: CryptoJS.pad.Pkcs7
    });
    const decryptedStr = decrypted.toString(CryptoJS.enc.Utf8);
    
    // 校验签名防篡改
    const { data, signature } = JSON.parse(decryptedStr);
    const validSignature = CryptoJS.MD5(data + LICENSE_SECRET_KEY).toString();
    if (signature !== validSignature) {
      throw new Error('授权码已被篡改，无效授权');
    }

    return data;
  } catch (error) {
    console.error('授权码解密失败', error);
    throw new Error('授权码无效，非官方生成');
  }
};

/**
 * ==================== 不可逆哈希工具 ====================
 */

/**
 * SHA256哈希（不可逆，用于设备指纹）
 * @param data 原始数据
 * @returns 哈希字符串
 */
export const sha256Hash = async (data: string): Promise<string> => {
  const encoder = new TextEncoder();
  const buffer = encoder.encode(data);
  const hashBuffer = await crypto.subtle.digest('SHA-256', buffer);
  const hashArray = Array.from(new Uint8Array(hashBuffer));
  return hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
};

/**
 * MD5哈希（快速校验用）
 * @param data 原始数据
 * @returns MD5字符串
 */
export const md5Hash = (data: string): string => {
  return CryptoJS.MD5(data).toString();
};

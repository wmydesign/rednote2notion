﻿import { createClient } from '@supabase/supabase-js';

// Supabase配置（生产环境请通过环境变量注入）
const SUPABASE_URL = import.meta.env.PLASMO_PUBLIC_SUPABASE_URL || '';
const SUPABASE_ANON_KEY = import.meta.env.PLASMO_PUBLIC_SUPABASE_ANON_KEY || '';

export const supabase = createClient(SUPABASE_URL, SUPABASE_ANON_KEY);


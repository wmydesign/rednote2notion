﻿import OpenAI from 'openai';
import type { RednoteNote, AIProcessTemplate, AIProcessResult } from './types';

// 初始化OpenAI客户端
const createOpenAIClient = (apiKey: string) => {
  return new OpenAI({
    apiKey,
    dangerouslyAllowBrowser: true
  });
};

// 预设分类标签（可自定义）
const DEFAULT_CATEGORIES = [
  '职场干货',
  '学习成长',
  '生活方式',
  '美食探店',
  '旅行攻略',
  '美妆护肤',
  '穿搭时尚',
  '家居好物',
  '科技数码',
  '财经理财',
  '情感心理',
  '健身运动',
  '母婴育儿',
  '兴趣爱好',
  '其他'
];

/**
 * AI智能分类小红书帖子
 * @param apiKey OpenAI API Key
 * @param note 小红书帖子数据
 * @param customCategories 自定义分类标签
 * @returns 分类结果
 */
export const classifyNoteWithAI = async (
  apiKey: string,
  note: RednoteNote,
  customCategories: string[] = DEFAULT_CATEGORIES
): Promise<string> => {
  if (!apiKey) throw new Error('OpenAI API Key 未配置');
  if (!note.title && !note.desc) return '其他';

  const openai = createOpenAIClient(apiKey);
  const prompt = `
你是一个专业的内容分类助手，需要根据小红书帖子的标题和正文，将其归类到最合适的分类中。
可选分类：${customCategories.join('、')}

帖子标题：${note.title || '无'}
帖子正文：${note.desc || '无'}
帖子标签：${note.tags.join('、') || '无'}

要求：
1. 只返回一个最匹配的分类名称，不要返回任何其他内容
2. 如果没有匹配的分类，返回"其他"
3. 严格使用提供的分类列表中的名称，不要自创分类
`;

  try {
    const response = await openai.chat.completions.create({
      model: 'gpt-3.5-turbo',
      messages: [
        { role: 'system', content: '你是一个专业的内容分类助手，严格按照要求执行分类任务' },
        { role: 'user', content: prompt }
      ],
      temperature: 0.3,
      max_tokens: 20
    });

    const category = response.choices[0]?.message?.content?.trim() || '其他';
    return customCategories.includes(category) ? category : '其他';
  } catch (error) {
    console.error('AI分类失败', error);
    return '其他';
  }
};

/**
 * ==================== 新增：AI深度知识加工 ====================
 * 对小红书笔记进行深度加工，生成指定模板的内容
 */
export const processNoteWithAI = async (
  apiKey: string,
  note: RednoteNote,
  template: AIProcessTemplate
): Promise<AIProcessResult> => {
  if (!apiKey) throw new Error('OpenAI API Key 未配置');
  if (!template.enable) {
    return {
      fieldName: template.fieldName,
      content: ''
    };
  }

  const openai = createOpenAIClient(apiKey);
  // 替换Prompt中的变量
  let prompt = template.prompt
    .replace(/{title}/g, note.title || '无')
    .replace(/{desc}/g, note.desc || '无')
    .replace(/{tags}/g, note.tags.join('、') || '无');

  // 补充OCR内容
  if (note.ocrResults && note.ocrResults.length > 0) {
    const ocrText = note.ocrResults.map(item => item.text).join('\n');
    prompt += `\n图片中的文字内容：${ocrText}`;
  }

  try {
    const response = await openai.chat.completions.create({
      model: 'gpt-3.5-turbo',
      messages: [
        { role: 'system', content: '你是一个专业的知识整理助手，严格按照用户的要求处理内容，只输出处理后的结果，不要多余的解释和内容' },
        { role: 'user', content: prompt }
      ],
      temperature: 0.4,
      max_tokens: 2000
    });

    const content = response.choices[0]?.message?.content?.trim() || '';
    return {
      fieldName: template.fieldName,
      content
    };
  } catch (error) {
    console.error(`AI加工失败 [${template.name}]`, error);
    return {
      fieldName: template.fieldName,
      content: `加工失败：${error.message}`
    };
  }
};

/**
 * 批量执行AI加工模板
 * @param apiKey OpenAI API Key
 * @param note 小红书笔记数据
 * @param templates 加工模板列表
 * @returns 加工结果列表
 */
export const batchProcessNoteWithAI = async (
  apiKey: string,
  note: RednoteNote,
  templates: AIProcessTemplate[]
): Promise<AIProcessResult[]> => {
  const enableTemplates = templates.filter(t => t.enable);
  if (enableTemplates.length === 0) return [];

  const results: AIProcessResult[] = [];
  for (const template of enableTemplates) {
    const result = await processNoteWithAI(apiKey, note, template);
    results.push(result);
    // 延迟避免API限流
    await new Promise(resolve => setTimeout(resolve, 200));
  }
  return results;
};

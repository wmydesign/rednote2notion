﻿/**
 * 国际化工具类
 * 封装Chrome i18n API，适配插件多语言场景
 */

/**
 * 获取国际化文本
 * @param key 消息key，对应messages.json中的字段
 * @param substitutions 替换参数
 * @returns 本地化后的文本
 */
export const t = (key: string, substitutions?: string | string[]): string => {
  if (typeof chrome === 'undefined' || !chrome.i18n) {
    // 开发环境降级处理
    return key;
  }
  return chrome.i18n.getMessage(key, substitutions) || key;
};

/**
 * 获取插件当前语言
 * @returns 语言代码（如zh_CN、en）
 */
export const getCurrentLocale = (): string => {
  if (typeof chrome === 'undefined' || !chrome.i18n) {
    return 'en';
  }
  return chrome.i18n.getUILanguage();
};

/**
 * 检查是否支持目标语言
 * @param locale 语言代码
 * @returns 是否支持
 */
export const isLocaleSupported = (locale: string): boolean => {
  const supportedLocales = ['en', 'zh_CN', 'de', 'es', 'fr', 'ja', 'ko', 'pt'];
  return supportedLocales.includes(locale);
};

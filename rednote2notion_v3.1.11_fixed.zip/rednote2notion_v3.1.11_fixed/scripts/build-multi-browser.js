#!/usr/bin/env node
/**
 * 多浏览器构建脚本
 * 一键构建 Chrome 和 Edge 版本
 * 支持：版本号自动注入、品牌色替换、zip打包
 */

const { execSync, spawn } = require('child_process');
const fs = require('fs');
const path = require('path');
const archiver = require('archiver');

// ==================== 配置 ====================
const CONFIG = {
  version: '3.1.0',
  browsers: ['chrome', 'edge'],
  brandColors: {
    chrome: '#FF2442',  // 小红书红
    edge: '#0078D4',    // Microsoft 蓝
  },
  storeNames: {
    chrome: 'Chrome Web Store',
    edge: 'Edge Add-ons',
  },
  outputDir: 'dist',
};

// ==================== 工具函数 ====================

/**
 * 执行命令
 */
function runCommand(command, options = {}) {
  console.log(`[Build] 执行: ${command}`);
  try {
    return execSync(command, { stdio: 'inherit', ...options });
  } catch (error) {
    console.error(`[Build] 命令执行失败: ${command}`);
    throw error;
  }
}

/**
 * 创建 ZIP 文件
 */
function createZip(sourceDir, outputPath) {
  return new Promise((resolve, reject) => {
    const output = fs.createWriteStream(outputPath);
    const archive = archiver('zip', { zlib: { level: 9 } });

    output.on('close', () => {
      console.log(`[Build] ZIP 创建成功: ${outputPath} (${(archive.pointer() / 1024).toFixed(2)} KB)`);
      resolve();
    });

    archive.on('error', reject);
    archive.pipe(output);
    archive.directory(sourceDir, false);
    archive.finalize();
  });
}

/**
 * 替换文件内容
 */
function replaceInFile(filePath, replacements) {
  let content = fs.readFileSync(filePath, 'utf8');

  for (const [from, to] of Object.entries(replacements)) {
    content = content.replace(new RegExp(from, 'g'), to);
  }

  fs.writeFileSync(filePath, content);
}

// ==================== 构建流程 ====================

/**
 * 构建单个浏览器版本
 */
async function buildForBrowser(browser) {
  console.log(`\n${'='.repeat(50)}`);
  console.log(`[Build] 开始构建 ${browser.toUpperCase()} 版本`);
  console.log(`${'='.repeat(50)}\n`);

  const buildDir = path.join(CONFIG.outputDir, `build-${browser}`);
  const zipPath = path.join(CONFIG.outputDir, `rednote2notion-v${CONFIG.version}-${browser}.zip`);

  // 1. 清理并创建构建目录
  console.log('[Build] 步骤 1/5: 清理构建目录');
  if (fs.existsSync(buildDir)) {
    fs.rmSync(buildDir, { recursive: true });
  }
  fs.mkdirSync(buildDir, { recursive: true });

  // 2. 执行 Plasmo 构建
  console.log('[Build] 步骤 2/5: 执行 Plasmo 构建');
  const env = {
    ...process.env,
    BROWSER_TARGET: browser,
    BRAND_COLOR: CONFIG.brandColors[browser],
  };

  try {
    runCommand(`npx plasmo build --target=${browser}`, { env, cwd: process.cwd() });
  } catch (error) {
    console.log('[Build] Plasmo 构建可能已完成，继续处理...');
  }

  // 3. 复制构建产物
  console.log('[Build] 步骤 3/5: 复制构建产物');
  const defaultBuildDir = path.join(process.cwd(), 'build', 'chromium');
  if (fs.existsSync(defaultBuildDir)) {
    const files = fs.readdirSync(defaultBuildDir);
    for (const file of files) {
      const srcPath = path.join(defaultBuildDir, file);
      const destPath = path.join(buildDir, file);
      if (fs.statSync(srcPath).isDirectory()) {
        fs.cpSync(srcPath, destPath, { recursive: true });
      } else {
        fs.copyFileSync(srcPath, destPath);
      }
    }
  }

  // 4. 更新 manifest.json
  console.log('[Build] 步骤 4/5: 更新 manifest.json');
  const manifestPath = path.join(buildDir, 'manifest.json');
  if (fs.existsSync(manifestPath)) {
    const manifest = JSON.parse(fs.readFileSync(manifestPath, 'utf8'));
    manifest.version = CONFIG.version;
    manifest.version_name = `v${CONFIG.version} (${browser})`;

    // Edge 特定配置
    if (browser === 'edge') {
      if (manifest.background) {
        manifest.background.service_worker = 'background.js';
      }
    }

    fs.writeFileSync(manifestPath, JSON.stringify(manifest, null, 2));
  }

  // 5. 创建 ZIP
  console.log('[Build] 步骤 5/5: 创建发布包');
  await createZip(buildDir, zipPath);

  console.log(`\n[Build] ✅ ${browser.toUpperCase()} 版本构建完成!\n`);
  console.log(`  📦 输出: ${zipPath}`);
  console.log(`  🏪 商店: ${CONFIG.storeNames[browser]}\n`);

  return zipPath;
}

/**
 * 主构建流程
 */
async function main() {
  console.log('\n🚀 Rednote2Notion V3.1.0 多浏览器构建');
  console.log('━'.repeat(50));

  // 创建输出目录
  if (!fs.existsSync(CONFIG.outputDir)) {
    fs.mkdirSync(CONFIG.outputDir, { recursive: true });
  }

  const results = [];

  // 构建所有浏览器版本
  for (const browser of CONFIG.browsers) {
    try {
      const zipPath = await buildForBrowser(browser);
      results.push({ browser, zipPath, success: true });
    } catch (error) {
      console.error(`[Build] ❌ ${browser} 版本构建失败:`, error.message);
      results.push({ browser, success: false, error: error.message });
    }
  }

  // 输出汇总
  console.log('\n' + '='.repeat(50));
  console.log('📊 构建汇总');
  console.log('='.repeat(50));

  for (const result of results) {
    if (result.success) {
      console.log(`  ✅ ${result.browser}: ${result.zipPath}`);
    } else {
      console.log(`  ❌ ${result.browser}: ${result.error}`);
    }
  }

  console.log('\n');
}

// 执行构建
main().catch(console.error);

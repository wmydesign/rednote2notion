/**
 * Content Script - V3.1.0
 * 负责页面注入、用户状态检测、请求头劫持
 * 集成：统一日志管理器
 */

import { MessageType, KnowledgeType } from '../lib/types';
import { detectBrowserType, generateSecChUa, getBrowserInfo, extractBrowserVersion } from '../lib/browser-polyfill';
import { logger } from '../lib/logger';

const MODULE = 'ContentScript';

// 页面加载完成后初始化
window.addEventListener('load', () => {
  initContentScript();
});

// 初始化内容脚本
const initContentScript = async () => {
  const browserInfo = getBrowserInfo();
  logger.info(MODULE, `Content Script 已加载`, { browser: `${browserInfo.name} ${browserInfo.version}` });
  await checkUserLoginStatus();
  listenAccountSwitch();
  listenRuntimeMessage();
  injectRequestHeaderHook();
};

// 检查用户登录状态，获取当前登录用户信息
const checkUserLoginStatus = async () => {
  try {
    const response = await fetch('https://edith.xiaohongshu.com/api/sns/web/v2/user/me', {
      credentials: 'include',
      headers: {
        'Content-Type': 'application/json',
        'Referer': 'https://www.xiaohongshu.com/',
        'Origin': 'https://www.xiaohongshu.com'
      }
    });

    if (response.ok) {
      const data = await response.json();
      if (data.code === 0 && data.data) {
        const userInfo = {
          userId: data.data.user_id,
          nickname: data.data.nickname,
          avatar: data.data.imageb || data.data.images
        };
        logger.info(MODULE, '用户登录状态检测成功', { userId: userInfo.userId });
        // 通知后台用户登录信息
        chrome.runtime.sendMessage({
          name: MessageType.ACCOUNT_SWITCH,
          data: userInfo
        });
      }
    }
  } catch (error) {
    logger.error(MODULE, '获取用户信息失败', error);
  }
};

// 监听账号切换+页面路由变化
const listenAccountSwitch = () => {
  let lastUserId = '';
  let checkIntervalId: number | null = null;
  let isRunning = true;
  
  // 检测账号状态的函数
  const checkAccountChange = async () => {
    if (!isRunning) return;
    
    try {
      const response = await fetch('https://edith.xiaohongshu.com/api/sns/web/v2/user/me', {
        credentials: 'include',
        headers: {
          'Content-Type': 'application/json',
          'Referer': 'https://www.xiaohongshu.com/',
          'Origin': 'https://www.xiaohongshu.com'
        }
      });
      if (response.ok) {
        const data = await response.json();
        if (data.code === 0 && data.data) {
          const currentUserId = data.data.user_id;
          if (lastUserId && lastUserId !== currentUserId) {
            logger.info(MODULE, '检测到账号切换', { from: lastUserId, to: currentUserId });
            chrome.runtime.sendMessage({
              name: MessageType.ACCOUNT_SWITCH,
              data: {
                userId: currentUserId,
                nickname: data.data.nickname,
                avatar: data.data.imageb || data.data.images
              }
            });
          }
          lastUserId = currentUserId;
        }
      }
    } catch (error) {
      logger.error(MODULE, '账号切换检测失败', error);
    }
  };
  
  // 清理函数
  const cleanup = () => {
    isRunning = false;
    if (checkIntervalId !== null) {
      clearInterval(checkIntervalId);
      checkIntervalId = null;
    }
  };
  
  // 启动定时检测
  checkIntervalId = window.setInterval(checkAccountChange, 5000);
  
  // 多种清理方式确保内存不泄漏
  window.addEventListener('beforeunload', cleanup);
  window.addEventListener('pagehide', cleanup);
  window.addEventListener('unload', cleanup);
  
  // SPA路由切换时清理
  document.addEventListener('visibilitychange', () => {
    if (document.visibilityState === 'hidden') {
      // 页面隐藏时暂停检测（节省资源）
      if (checkIntervalId !== null) {
        clearInterval(checkIntervalId);
        checkIntervalId = null;
      }
    } else if (document.visibilityState === 'visible' && isRunning && checkIntervalId === null) {
      // 页面重新可见时恢复检测
      checkIntervalId = window.setInterval(checkAccountChange, 5000);
    }
  });
};

// 注入请求头钩子，动态适配浏览器指纹，降低风控风险
const injectRequestHeaderHook = () => {
  // 检测当前浏览器类型
  const browserType = detectBrowserType();
  const browserVersion = extractBrowserVersion(browserType);

  // 根据浏览器类型生成匹配的指纹
  const secChUa = generateSecChUa(browserType, browserVersion);
  const secChUaMobile = '?0';
  const secChUaPlatform = navigator.platform.toLowerCase().includes('mac') ? '"macOS"' : '"Windows"';

  logger.info(MODULE, `浏览器适配`, { browser: browserType, fingerprint: secChUa });

  // 重写XMLHttpRequest，添加动态浏览器请求头
  const originalXHROpen = XMLHttpRequest.prototype.open;
  XMLHttpRequest.prototype.open = function(...args) {
    this.addEventListener('readystatechange', () => {
      if (this.readyState === 1) {
        this.setRequestHeader('Accept', 'application/json, text/plain, */*');
        this.setRequestHeader('Accept-Language', 'zh-CN,zh;q=0.9,en;q=0.8');

        // 动态注入浏览器指纹（关键修改：不再硬编码Chrome指纹）
        if (secChUa) {
          this.setRequestHeader('sec-ch-ua', secChUa);
        }
        this.setRequestHeader('sec-ch-ua-mobile', secChUaMobile);
        this.setRequestHeader('sec-ch-ua-platform', secChUaPlatform);

        this.setRequestHeader('Sec-Fetch-Dest', 'empty');
        this.setRequestHeader('Sec-Fetch-Mode', 'cors');
        this.setRequestHeader('Sec-Fetch-Site', 'same-site');
      }
    });
    return originalXHROpen.apply(this, args);
  };
};

// 监听来自后台的消息
const listenRuntimeMessage = () => {
  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    switch (message.name) {
      case MessageType.GET_COOKIE:
        // 获取小红书Cookie
        sendResponse(document.cookie);
        break;
      case MessageType.GET_ALBUM_LIST:
        // 获取收藏专辑列表
        fetch('https://edith.xiaohongshu.com/api/sns/web/v1/album/list', {
          method: 'POST',
          credentials: 'include',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ page_size: 100, cursor: '' })
        })
        .then(res => res.json())
        .then(data => sendResponse({ success: true, data }))
        .catch(err => {
          logger.error(MODULE, '获取专辑列表失败', err);
          sendResponse({ success: false, error: err.message });
        });
        break;
      case MessageType.GET_NOTE_DETAIL:
        // 获取笔记详情
        const noteId = message.data.noteId;
        fetch(`https://edith.xiaohongshu.com/api/sns/web/v1/feed/note_detail?note_id=${noteId}`, {
          method: 'GET',
          credentials: 'include',
          headers: { 'Content-Type': 'application/json' }
        })
        .then(res => res.json())
        .then(data => sendResponse({ success: true, data }))
        .catch(err => {
          logger.error(MODULE, '获取笔记详情失败', { noteId, error: err });
          sendResponse({ success: false, error: err.message });
        });
        break;
      default:
        break;
    }
    return true;
  });
};
/**
 * SidePanel 组件 (最终集成版 - 含日志监控)
 * 集成现有 logger.ts，实现全链路日志记录与持久化
 * 优化内容：
 * 1. 同步开关状态原子化，失败时回滚
 * 2. 停止同步清理模拟进度定时器
 * 3. 授权激活立即生效
 * 4. 补回关联数据库 UI
 * 5. 保存配置不再闪烁
 * 6. 进度监听增加来源校验与超时
 * 7. 所有 console 调用替换为 logger，实现持久化监控
 */

import React, { useState, useEffect, useCallback, useRef } from 'react';
import { MessageType, AIProvider, AI_MODEL_PRESETS } from './lib/types';
import { testAIConnection } from './lib/ai-service';
import { getCurrentLicense, LicenseType, activateLicenseCode } from './lib/license';
import {
  createCompleteDatabase,
  getNotionPages,
  checkDatabaseCompleteness,
  completeDatabaseFields,
  getViewConfigurationGuide,
  createRelationDatabases,
  updateDatabaseWithRelations
} from './lib/notion';
import type { NotionPage, RelationDatabaseConfig, RelationDatabaseResult } from './lib/types';
import { logger } from './lib/logger';
import './style.css';

// 模块名称常量
const MODULE = 'SidePanel';

// ==================== 自定义 Hook：响应式存储 ====================
function useStorageState<T>(
  key: string,
  defaultValue: T
): [T, (value: T | ((prev: T) => T)) => Promise<void>, boolean] {
  const [state, setState] = useState<T>(defaultValue);
  const [loading, setLoading] = useState(true);
  const defaultValueRef = useRef(defaultValue);

  useEffect(() => {
    chrome.storage.local.get(key, (result) => {
      setState(result[key] ?? defaultValueRef.current);
      setLoading(false);
    });

    const listener = (changes: { [key: string]: chrome.storage.StorageChange }) => {
      if (changes[key]) {
        setState(changes[key].newValue ?? defaultValueRef.current);
      }
    };
    chrome.storage.onChanged.addListener(listener);
    return () => chrome.storage.onChanged.removeListener(listener);
  }, [key]);

  const setValue = useCallback(async (value: T | ((prev: T) => T)) => {
    const newValue = value instanceof Function ? value(state) : value;
    setState(newValue);
    await chrome.storage.local.set({ [key]: newValue });
  }, [key, state]);

  return [state, setValue, loading];
}

// ==================== 工具函数 ====================
const formatTime = (timestamp: number): string => {
  if (!timestamp) return '从未同步';
  const date = new Date(timestamp);
  const now = new Date();
  const diff = now.getTime() - date.getTime();
  if (diff < 60000) return '刚刚';
  if (diff < 3600000) return `${Math.floor(diff / 60000)}分钟前`;
  if (diff < 86400000) return `${Math.floor(diff / 3600000)}小时前`;
  return date.toLocaleDateString();
};

// ==================== 子组件 ====================

// 骨架屏组件
const SkeletonLoader: React.FC = () => (
  <div className="skeleton-container">
    <div className="skeleton-card">
      <div style={{ display: 'flex', alignItems: 'center' }}>
        <div className="skeleton skeleton-avatar" />
        <div className="skeleton-info">
          <div className="skeleton skeleton-line" style={{ width: '120px' }} />
          <div className="skeleton skeleton-line" style={{ width: '80px', height: '10px' }} />
        </div>
      </div>
    </div>
    <div className="skeleton-card">
      <div className="skeleton skeleton-title" />
      {[1, 2, 3].map((i) => (
        <div key={i} className="skeleton-row" style={{ borderBottom: i < 3 ? '1px solid #F0F0F0' : 'none' }}>
          <div className="skeleton skeleton-circle" />
          <div className="skeleton-info" style={{ marginLeft: '12px' }}>
            <div className="skeleton skeleton-line" style={{ width: `${100 + i * 20}px` }} />
            <div className="skeleton skeleton-line" style={{ width: '60px', height: '10px' }} />
          </div>
        </div>
      ))}
    </div>
    <div className="skeleton-card">
      <div style={{ display: 'flex', gap: '10px' }}>
        <div className="skeleton" style={{ flex: 1, height: '40px', borderRadius: '12px' }} />
        <div className="skeleton" style={{ flex: 1, height: '40px', borderRadius: '12px' }} />
      </div>
    </div>
  </div>
);

// 圆环进度组件
const CircularProgress: React.FC<{ progress: number; size?: number; strokeWidth?: number }> = ({
  progress,
  size = 64,
  strokeWidth = 5
}) => {
  const radius = (size - strokeWidth) / 2;
  const circumference = radius * 2 * Math.PI;
  const offset = circumference - (progress / 100) * circumference;

  return (
    <div className="progress-ring-container">
      <div className="progress-ring" style={{ width: size, height: size }}>
        <svg viewBox={`0 0 ${size} ${size}`}>
          <defs>
            <linearGradient id="progressGradient" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#FF2442" />
              <stop offset="100%" stopColor="#FF6B81" />
            </linearGradient>
          </defs>
          <circle className="progress-ring-bg" cx={size / 2} cy={size / 2} r={radius} />
          <circle
            className="progress-ring-value"
            cx={size / 2}
            cy={size / 2}
            r={radius}
            style={{ strokeDasharray: circumference, strokeDashoffset: offset }}
          />
        </svg>
        <span className="progress-ring-text">{Math.round(progress)}%</span>
      </div>
    </div>
  );
};

// Toast 组件
const Toast: React.FC<{ message: string; type?: 'default' | 'success' | 'error' | 'warning'; show: boolean }> = ({
  message,
  type = 'default',
  show
}) => {
  if (!message) return null;
  const icons = { default: '💡', success: '✅', error: '❌', warning: '⚠️' };
  return (
    <div className={`xhs-toast ${show ? 'show' : ''} ${type !== 'default' ? `xhs-toast-${type}` : ''}`}>
      <span className="xhs-toast-icon">{icons[type]}</span>
      <span>{message}</span>
    </div>
  );
};

// 授权激活遮罩组件
const LicenseNotActivatedOverlay: React.FC<{
  onActivate: () => void;
  onVerifyLicense: (code: string) => Promise<boolean>;
  licenseInput: string;
  setLicenseInput: (value: string) => void;
  verifying: boolean;
  verifyError: string;
  verifySuccess: boolean;
}> = ({ onActivate, onVerifyLicense, licenseInput, setLicenseInput, verifying, verifyError, verifySuccess }) => {
  const [showInput, setShowInput] = useState(false);

  const handleVerify = async () => {
    if (!licenseInput.trim()) return;
    await onVerifyLicense(licenseInput.trim());
  };

  return (
    <div
      className="animate-fade-in"
      style={{
        position: 'fixed',
        top: 0,
        left: 0,
        right: 0,
        bottom: 0,
        background: 'rgba(0, 0, 0, 0.85)',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        zIndex: 9999,
        padding: '20px'
      }}
    >
      <div className="glass-card" style={{ maxWidth: '380px', width: '100%', textAlign: 'center', padding: '32px 24px' }}>
        {verifySuccess ? (
          <>
            <div
              style={{
                width: '80px',
                height: '80px',
                margin: '0 auto 20px',
                borderRadius: '50%',
                background: 'linear-gradient(135deg, #52C41A 0%, #73D13D 100%)',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                fontSize: '40px',
                boxShadow: '0 8px 24px rgba(82, 196, 26, 0.35)',
                animation: 'pulse 0.5s ease-in-out'
              }}
            >
              ✅
            </div>
            <h2 style={{ fontSize: '20px', fontWeight: 600, color: '#52C41A', marginBottom: '12px' }}>激活成功！</h2>
            <p style={{ fontSize: '14px', color: 'var(--text-secondary)', lineHeight: 1.6 }}>现在可以使用全部功能了</p>
          </>
        ) : (
          <>
            <div
              style={{
                width: '80px',
                height: '80px',
                margin: '0 auto 20px',
                borderRadius: '50%',
                background: 'linear-gradient(135deg, #FF2442 0%, #FF6B81 100%)',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                fontSize: '40px',
                boxShadow: '0 8px 24px rgba(255, 36, 66, 0.35)'
              }}
            >
              🔐
            </div>
            <h2 style={{ fontSize: '20px', fontWeight: 600, color: 'var(--text-primary)', marginBottom: '12px' }}>
              请先激活授权码
            </h2>
            <p style={{ fontSize: '14px', color: 'var(--text-secondary)', marginBottom: '24px', lineHeight: 1.6 }}>
              为了持续为您提供优质服务
              <br />
              请激活授权码后继续使用
            </p>
            {showInput ? (
              <div style={{ marginBottom: '16px' }}>
                <input
                  type="text"
                  value={licenseInput}
                  onChange={(e) => setLicenseInput(e.target.value)}
                  placeholder="请输入授权码"
                  maxLength={512}
                  style={{
                    width: '100%',
                    padding: '12px 16px',
                    border: verifyError ? '2px solid #FF4D4F' : '2px solid var(--border-color)',
                    borderRadius: '12px',
                    fontSize: '14px',
                    outline: 'none',
                    transition: 'border-color 0.2s',
                    boxSizing: 'border-box',
                    marginBottom: '8px'
                  }}
                  disabled={verifying}
                />
                {verifyError && (
                  <div style={{ fontSize: '12px', color: '#FF4D4F', marginBottom: '8px', textAlign: 'left' }}>
                    ⚠️ {verifyError}
                  </div>
                )}
                <div style={{ display: 'flex', gap: '10px' }}>
                  <button
                    className="xhs-btn xhs-btn-secondary"
                    onClick={() => {
                      setShowInput(false);
                      setLicenseInput('');
                    }}
                    style={{ flex: 1 }}
                    disabled={verifying}
                  >
                    取消
                  </button>
                  <button
                    className="xhs-btn xhs-btn-primary"
                    onClick={handleVerify}
                    style={{ flex: 2 }}
                    disabled={verifying || !licenseInput.trim()}
                  >
                    {verifying ? '⏳ 验证中...' : '✓ 激活授权'}
                  </button>
                </div>
              </div>
            ) : (
              <>
                <button
                  className="xhs-btn xhs-btn-primary xhs-btn-block"
                  onClick={() => setShowInput(true)}
                  style={{ marginBottom: '12px' }}
                >
                  🔑 输入授权码激活
                </button>
                <button
                  className="xhs-btn xhs-btn-secondary xhs-btn-block"
                  onClick={onActivate}
                  style={{ marginBottom: '12px' }}
                >
                  📋 前往激活页面
                </button>
              </>
            )}
            <p style={{ fontSize: '12px', color: 'var(--text-hint)' }}>没有授权码？联系开发者获取</p>
          </>
        )}
      </div>
    </div>
  );
};

// 同步卡片组件
interface SyncCardProps {
  title: string;
  icon: string;
  iconClass: string;
  isActive: boolean;
  lastSyncTime: number;
  onToggle: () => void;
  disabled?: boolean;
}

const SyncCard: React.FC<SyncCardProps> = ({ title, icon, iconClass, isActive, lastSyncTime, onToggle, disabled }) => {
  const handleCardClick = () => {
    if (disabled) return;
    onToggle();
  };

  const handleSwitchClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (disabled) return;
    onToggle();
  };

  return (
    <div className={`sync-status-card ${isActive ? 'active' : ''} ${disabled ? 'disabled' : ''}`} onClick={handleCardClick}>
      <div
        className={`sync-status-icon ${iconClass} ${isActive ? 'syncing' : ''} xhs-bubble`}
        data-bubble={disabled ? '请先激活授权并授权小红书' : isActive ? '同步中...' : '点击开启'}
        style={{
          background:
            iconClass === 'post'
              ? 'linear-gradient(135deg, #FFE4E8 0%, #FFCCD5 100%)'
              : iconClass === 'bookmark'
                ? 'linear-gradient(135deg, #FFF3E0 0%, #FFE0B2 100%)'
                : 'linear-gradient(135deg, #FFE4EC 0%, #FFCCD5 100%)',
          opacity: disabled ? 0.6 : 1
        }}
      >
        {icon}
      </div>
      <div className="sync-status-info">
        <div className="sync-status-title">{title}</div>
        <div className="sync-status-time">
          {isActive ? (
            <span style={{ color: 'var(--success-color)', display: 'flex', alignItems: 'center', gap: '4px' }}>
              <span className="animate-pulse">●</span> 同步中 · {formatTime(lastSyncTime)}
            </span>
          ) : (
            `最后同步：${formatTime(lastSyncTime)}`
          )}
        </div>
      </div>
      <div className={`xhs-switch ${isActive ? 'active' : ''}`} onClick={handleSwitchClick} style={{ opacity: disabled ? 0.5 : 1 }} />
    </div>
  );
};

// ==================== 主组件 ====================
const SidePanel: React.FC = () => {
  // 授权相关状态
  const [licenseActivated, setLicenseActivated] = useState(false);
  const [licenseInfo, setLicenseInfo] = useState<any>(null);
  const [licenseInput, setLicenseInput] = useState('');
  const [verifying, setVerifying] = useState(false);
  const [verifyError, setVerifyError] = useState('');
  const [verifySuccess, setVerifySuccess] = useState(false);

  // 用户信息
  const [userInfo, setUserInfo] = useState<{ userId: string; nickname: string } | null>(null);
  const [xiaohongshuAuthorized, setXiaohongshuAuthorized] = useState(false);
  const [xiaohongshuLoading, setXiaohongshuLoading] = useState(true);

  // 使用自定义 Hook 管理存储状态
  const [notionApiKey, setNotionApiKey, loadingApiKey] = useStorageState('notion_api_key', '');
  const [notionDatabaseId, setNotionDatabaseId, loadingDbId] = useStorageState('notion_database_id', '');
  const [aiProvider, setAiProvider] = useStorageState<AIProvider>('ai_provider', AIProvider.OPENAI);
  const [aiModel, setAiModel] = useStorageState('ai_model', 'gpt-3.5-turbo');
  const [aiApiKey, setAiApiKey] = useStorageState('ai_api_key', '');
  const [aiEnableClassify, setAiEnableClassify] = useStorageState('ai_enable_classify', false);
  const [knowledgeBaseEnabled, setKnowledgeBaseEnabled] = useStorageState('knowledge_base_enabled', false);

  // 同步状态
  const [syncPostStatus, setSyncPostStatus] = useStorageState('sync-rednote-post-to-notion', false);
  const [syncBookmarkStatus, setSyncBookmarkStatus] = useStorageState('sync-rednote-bookmark-to-notion', false);
  const [syncLikeStatus, setSyncLikeStatus] = useStorageState('sync-rednote-like-to-notion', false);
  const [lastPostSyncTime, setLastPostSyncTime] = useStorageState('sync-rednote-post-to-notion_last_time', 0);
  const [lastBookmarkSyncTime, setLastBookmarkSyncTime] = useStorageState('sync-rednote-bookmark-to-notion_last_time', 0);
  const [lastLikeSyncTime, setLastLikeSyncTime] = useStorageState('sync-rednote-like-to-notion_last_time', 0);

  // UI 状态
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState<'sync' | 'config'>('sync');
  const [syncProgress, setSyncProgress] = useState(0);
  const [syncStatusText, setSyncStatusText] = useState('');
  const [isDarkMode, setIsDarkMode] = useState(false);
  const [toast, setToast] = useState({ show: false, message: '', type: 'default' as 'default' | 'success' | 'error' | 'warning' });
  const [testingConnection, setTestingConnection] = useState(false);

  // 数据库管理状态
  const [notionPages, setNotionPages] = useState<NotionPage[]>([]);
  const [selectedPageId, setSelectedPageId] = useState('');
  const [creating, setCreating] = useState(false);
  const [databaseUrl, setDatabaseUrl] = useState('');

  // 关联数据库
  const [relationConfig, setRelationConfig] = useState<RelationDatabaseConfig>({ enableAuthorDB: true, enableTagDB: true, enableAlbumDB: false });
  const [relationDBResult, setRelationDBResult] = useState<RelationDatabaseResult | null>(null);
  const [creatingRelationDB, setCreatingRelationDB] = useState(false);

  // 定时器引用
  const progressIntervalRef = useRef<NodeJS.Timeout | null>(null);

  // 初始化深色模式
  useEffect(() => {
    chrome.storage.local.get(['darkMode'], (result) => {
      const stored = result.darkMode;
      if (stored !== undefined) {
        setIsDarkMode(stored === true);
        document.body.classList.toggle('dark', stored === true);
      } else {
        const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
        setIsDarkMode(prefersDark);
        document.body.classList.toggle('dark', prefersDark);
      }
    });
    logger.debug(MODULE, '深色模式初始化完成');
  }, []);

  // 加载授权状态
  useEffect(() => {
    const initLicense = async () => {
      const info = await getCurrentLicense();
      setLicenseInfo(info);
      setLicenseActivated(info.isActivated && info.isValid);
      logger.info(MODULE, '授权状态加载完成', { activated: info.isActivated, valid: info.isValid });
    };
    initLicense();
  }, []);

  // 检查小红书授权
  useEffect(() => {
    checkXiaohongshuAuth();
  }, []);

  // 进度监听（增加来源校验）
  useEffect(() => {
    let mounted = true;
    const handleProgress = (message: any, sender: chrome.runtime.MessageSender) => {
      if (!mounted) return;
      if (sender.id !== chrome.runtime.id) return;
      if (message.name === 'SYNC_PROGRESS' && message.data) {
        requestAnimationFrame(() => {
          setSyncProgress(message.data.progress ?? 0);
          setSyncStatusText(message.data.step ?? '');
        });
      }
    };
    chrome.runtime.onMessage.addListener(handleProgress);
    return () => {
      mounted = false;
      chrome.runtime.onMessage.removeListener(handleProgress);
      if (progressIntervalRef.current) {
        clearInterval(progressIntervalRef.current);
        progressIntervalRef.current = null;
      }
    };
  }, []);

  // 综合加载状态
  useEffect(() => {
    const allLoaded = !loadingApiKey && !loadingDbId;
    if (allLoaded) {
      setLoading(false);
      logger.debug(MODULE, 'UI 加载完成');
    }
  }, [loadingApiKey, loadingDbId]);

  // 辅助函数
  const showToast = (msg: string, type: 'default' | 'success' | 'error' | 'warning' = 'default') => {
    setToast({ show: true, message: msg, type });
    setTimeout(() => setToast({ show: false, message: '', type: 'default' }), 2500);
  };

  const toggleDarkMode = () => {
    const newMode = !isDarkMode;
    setIsDarkMode(newMode);
    chrome.storage.local.set({ darkMode: newMode });
    document.body.classList.toggle('dark', newMode);
    logger.debug(MODULE, `切换深色模式: ${newMode}`);
  };

  const openActivationPage = () => chrome.runtime.openOptionsPage();

  const handleVerifyLicense = async (code: string): Promise<boolean> => {
    setVerifying(true);
    setVerifyError('');
    logger.info(MODULE, '开始验证授权码', { codeLength: code.length });
    try {
      const result = await activateLicenseCode(code);
      if (result.isValid && result.isActivated) {
        setVerifySuccess(true);
        setLicenseActivated(true);
        setLicenseInfo(result);
        showToast('授权码激活成功！', 'success');
        logger.info(MODULE, '授权码激活成功');
        return true;
      } else {
        setVerifyError(result.errorMsg || '授权码无效');
        logger.warn(MODULE, '授权码无效', { error: result.errorMsg });
        return false;
      }
    } catch (error: any) {
      setVerifyError(error.message || '验证失败');
      logger.error(MODULE, '授权码验证异常', error);
      return false;
    } finally {
      setVerifying(false);
    }
  };

  const checkXiaohongshuAuth = async () => {
    setXiaohongshuLoading(true);
    logger.debug(MODULE, '开始检查小红书授权');
    try {
      const storageData = await chrome.storage.local.get(['current_user']);
      if (storageData.current_user) {
        setXiaohongshuAuthorized(true);
        setUserInfo(storageData.current_user);
        setXiaohongshuLoading(false);
        logger.info(MODULE, '小红书授权状态从本地恢复', { userId: storageData.current_user.userId });
        return;
      }

      const res = await Promise.race([
        chrome.runtime.sendMessage({ name: MessageType.CHECK_XHS_AUTH }),
        new Promise<null>((_, reject) => setTimeout(() => reject(new Error('授权检查超时')), 8000))
      ]);

      if (res && res.success && res.data) {
        setXiaohongshuAuthorized(true);
        setUserInfo(res.data);
        await chrome.storage.local.set({ current_user: res.data });
        logger.info(MODULE, '小红书授权验证成功', { userId: res.data.userId });
      } else {
        throw new Error(res?.error || '授权校验失败');
      }
    } catch (error) {
      logger.error(MODULE, '小红书授权检查失败', error);
      setXiaohongshuAuthorized(false);
      setUserInfo(null);
      showToast(`小红书授权失败：${error instanceof Error ? error.message : '请先登录小红书官网'}`, 'error');
    } finally {
      setXiaohongshuLoading(false);
    }
  };

  const handleXiaohongshuAuth = () => {
    chrome.tabs.create({ url: 'https://www.xiaohongshu.com/', active: true });
    showToast('请登录小红书后，点击刷新按钮', 'warning');
    logger.info(MODULE, '打开小红书登录页');
  };

  const handleTestConnection = async () => {
    if (!aiApiKey) {
      showToast('请先输入 API Key', 'warning');
      return;
    }
    setTestingConnection(true);
    logger.info(MODULE, '开始测试 AI 连接', { provider: aiProvider });
    try {
      const result = await testAIConnection({ provider: aiProvider, apiKey: aiApiKey, model: aiModel });
      showToast(result.message, result.success ? 'success' : 'error');
      logger.info(MODULE, `AI 连接测试${result.success ? '成功' : '失败'}`, { message: result.message });
    } catch (error: any) {
      showToast(`测试失败: ${error.message}`, 'error');
      logger.error(MODULE, 'AI 连接测试异常', error);
    } finally {
      setTestingConnection(false);
    }
  };

  const loadNotionPages = async () => {
    if (!notionApiKey) {
      showToast('请先填写Notion API Key', 'error');
      return;
    }
    setLoading(true);
    logger.info(MODULE, '开始获取 Notion 页面列表');
    try {
      const pages = await getNotionPages(notionApiKey);
      setNotionPages(pages);
      if (pages.length > 0) setSelectedPageId(pages[0].id);
      showToast(`找到 ${pages.length} 个页面`, 'success');
      logger.info(MODULE, `获取到 ${pages.length} 个 Notion 页面`);
    } catch (error: any) {
      showToast(`获取页面失败: ${error.message}`, 'error');
      logger.error(MODULE, '获取 Notion 页面失败', error);
    } finally {
      setLoading(false);
    }
  };

  const handleCreateDatabase = async () => {
    if (!notionApiKey) {
      showToast('请先填写Notion API Key', 'error');
      return;
    }
    if (!selectedPageId) {
      showToast('请选择一个页面作为数据库的父页面', 'error');
      return;
    }
    setCreating(true);
    logger.info(MODULE, '开始创建 Notion 数据库', { parentPageId: selectedPageId, knowledgeMode: knowledgeBaseEnabled });
    try {
      const result = await createCompleteDatabase(notionApiKey, selectedPageId, knowledgeBaseEnabled);
      await setNotionDatabaseId(result.databaseId);
      setDatabaseUrl(result.databaseUrl);
      showToast('数据库创建成功！已自动保存数据库ID', 'success');
      logger.info(MODULE, '数据库创建成功', { databaseId: result.databaseId });
    } catch (error: any) {
      showToast(`创建失败: ${error.message}`, 'error');
      logger.error(MODULE, '数据库创建失败', error);
    } finally {
      setCreating(false);
    }
  };

  const handleCheckDatabase = async () => {
    if (!notionApiKey || !notionDatabaseId) {
      showToast('请先填写完整配置', 'error');
      return;
    }
    logger.info(MODULE, '开始检查数据库完整性');
    try {
      const result = await checkDatabaseCompleteness(notionApiKey, notionDatabaseId);
      if (result.isComplete) {
        showToast('数据库字段完整，无需修复', 'success');
        logger.info(MODULE, '数据库字段完整');
      } else {
        showToast(`缺少字段: ${result.missingFields.join(', ')}`, 'warning');
        logger.warn(MODULE, '数据库缺少字段', { missing: result.missingFields });
        if (confirm('检测到缺失字段，是否自动补齐？')) {
          await completeDatabaseFields(notionApiKey, notionDatabaseId, knowledgeBaseEnabled);
          showToast('字段已补齐', 'success');
          logger.info(MODULE, '数据库字段补齐完成');
        }
      }
    } catch (error: any) {
      showToast(`检查失败: ${error.message}`, 'error');
      logger.error(MODULE, '数据库完整性检查失败', error);
    }
  };

  const handleCreateRelationDatabases = async () => {
    if (!notionApiKey || !selectedPageId || !notionDatabaseId) {
      showToast('请先完成Notion基础配置', 'error');
      return;
    }
    setCreatingRelationDB(true);
    logger.info(MODULE, '开始创建关联数据库', relationConfig);
    try {
      const result = await createRelationDatabases(notionApiKey, selectedPageId, notionDatabaseId, relationConfig);
      await updateDatabaseWithRelations(notionApiKey, notionDatabaseId, {
        authorDBId: result.authorDBId,
        tagDBId: result.tagDBId,
        albumDBId: result.albumDBId
      });
      await chrome.storage.local.set({ relation_db_ids: result });
      setRelationDBResult(result);
      showToast('关联数据库创建成功！', 'success');
      logger.info(MODULE, '关联数据库创建成功', result);
    } catch (error: any) {
      showToast(`创建失败: ${error.message}`, 'error');
      logger.error(MODULE, '关联数据库创建失败', error);
    } finally {
      setCreatingRelationDB(false);
    }
  };

  const saveConfig = async () => {
    showToast('配置保存成功', 'success');
    logger.info(MODULE, '配置已保存');
  };

  const toggleSync = async (platform: 'rednotePost' | 'rednoteBookmark' | 'rednoteLike') => {
    if (!licenseActivated) {
      showToast('请先激活授权码', 'warning');
      return;
    }
    if (!xiaohongshuAuthorized) {
      showToast('请先授权小红书账号', 'warning');
      return;
    }
    if (!notionApiKey || !notionDatabaseId) {
      showToast('请先配置Notion', 'warning');
      setActiveTab('config');
      return;
    }

    const isPost = platform === 'rednotePost';
    const isBookmark = platform === 'rednoteBookmark';
    const currentStatus = isPost ? syncPostStatus : isBookmark ? syncBookmarkStatus : syncLikeStatus;
    const newStatus = !currentStatus;

    if (newStatus) {
      logger.info(MODULE, `启动同步: ${platform}`, { aiEnabled: aiEnableClassify });
      try {
        await chrome.runtime.sendMessage({
          name: MessageType.SYNC_TO_NOTION,
          data: {
            platform,
            notionApiKey,
            notionDatabaseId,
            aiProvider,
            aiModel,
            aiApiKey,
            enableAIClassify: aiEnableClassify
          }
        });

        if (isPost) await setSyncPostStatus(true);
        else if (isBookmark) await setSyncBookmarkStatus(true);
        else await setSyncLikeStatus(true);

        let progress = 0;
        progressIntervalRef.current = setInterval(() => {
          progress += Math.random() * 15;
          if (progress > 90) progress = 90;
          setSyncProgress(progress);
        }, 500);

        showToast('同步已开始', 'success');
      } catch (error: any) {
        showToast(`启动同步失败: ${error.message}`, 'error');
        logger.error(MODULE, `同步启动失败: ${platform}`, error);
      }
    } else {
      logger.info(MODULE, `停止同步: ${platform}`);
      await chrome.runtime.sendMessage({ name: MessageType.STOP_ALL_SYNC });
      
      if (progressIntervalRef.current) {
        clearInterval(progressIntervalRef.current);
        progressIntervalRef.current = null;
      }
      setSyncProgress(0);
      
      await Promise.all([setSyncPostStatus(false), setSyncBookmarkStatus(false), setSyncLikeStatus(false)]);
      showToast('已停止同步', 'default');
    }
  };

  const stopAllSync = async () => {
    logger.info(MODULE, '停止所有同步');
    await chrome.runtime.sendMessage({ name: MessageType.STOP_ALL_SYNC });
    
    if (progressIntervalRef.current) {
      clearInterval(progressIntervalRef.current);
      progressIntervalRef.current = null;
    }
    setSyncProgress(0);
    
    await Promise.all([setSyncPostStatus(false), setSyncBookmarkStatus(false), setSyncLikeStatus(false)]);
    showToast('已停止所有同步', 'default');
  };

  const clearCache = async () => {
    if (confirm('确定要清除所有同步缓存吗？')) {
      await chrome.runtime.sendMessage({ name: MessageType.CLEAR_CACHE });
      showToast('缓存清除成功', 'success');
      logger.info(MODULE, '同步缓存已清除');
    }
  };

  const toggleKnowledgeBase = async () => {
    if (!licenseActivated) {
      showToast('请先激活授权码', 'warning');
      return;
    }
    const newValue = !knowledgeBaseEnabled;
    await setKnowledgeBaseEnabled(newValue);
    showToast(newValue ? '智能知识库已启用' : '智能知识库已关闭', 'success');
    logger.info(MODULE, `智能知识库${newValue ? '启用' : '关闭'}`);
  };

  const handleExportLogs = async () => {
    try {
      const { exportLogs } = await import('./lib/logger');
      await exportLogs();
      showToast('日志已导出', 'success');
      logger.info(MODULE, '用户导出日志');
    } catch (error) {
      showToast('日志导出失败', 'error');
      logger.error(MODULE, '日志导出失败', error);
    }
  };

  const currentPreset = AI_MODEL_PRESETS[aiProvider];

  if (loading) {
    return (
      <div className="w-full min-h-screen" style={{ background: 'var(--bg-light)' }}>
        <div className="xhs-header">
          <h1>Rednote2Notion</h1>
          <p>小红书内容同步 · AI智能分类</p>
        </div>
        <SkeletonLoader />
      </div>
    );
  }

  return (
    <div className="w-full min-h-screen" style={{ background: 'var(--bg-light)' }}>
      {!licenseActivated && (
        <LicenseNotActivatedOverlay
          onActivate={openActivationPage}
          onVerifyLicense={handleVerifyLicense}
          licenseInput={licenseInput}
          setLicenseInput={setLicenseInput}
          verifying={verifying}
          verifyError={verifyError}
          verifySuccess={verifySuccess}
        />
      )}

      <div className="xhs-header micro-glow">
        <h1>Rednote2Notion</h1>
        <p>小红书内容同步 · AI智能分类</p>
      </div>

      <div className="p-4">
        <div className="dark-mode-toggle glass-card">
          <div className="dark-mode-toggle-label">
            <span className="dark-mode-toggle-icon">{isDarkMode ? '🌙' : '☀️'}</span>
            <span>{isDarkMode ? '深色模式' : '浅色模式'}</span>
          </div>
          <div className={`dark-mode-switch ${isDarkMode ? 'active' : ''}`} onClick={toggleDarkMode} />
        </div>
      </div>

      {/* 授权状态横幅 */}
      <div className="px-4 pb-2">
        <div
          className="xhs-card glass-card"
          style={{
            background: licenseActivated
              ? 'linear-gradient(135deg, rgba(82, 196, 26, 0.1), rgba(82, 196, 26, 0.02))'
              : 'linear-gradient(135deg, rgba(255, 77, 79, 0.1), rgba(255, 77, 79, 0.02))',
            border: `1px solid ${licenseActivated ? 'rgba(82, 196, 26, 0.2)' : 'rgba(255, 77, 79, 0.2)'}`
          }}
        >
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
              <div
                style={{
                  width: '36px',
                  height: '36px',
                  borderRadius: '50%',
                  background: licenseActivated
                    ? 'linear-gradient(135deg, #52C41A 0%, #73D13D 100%)'
                    : 'linear-gradient(135deg, #FF4D4F 0%, #FF7875 100%)',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  fontSize: '16px'
                }}
              >
                {licenseActivated ? '✅' : '⚠️'}
              </div>
              <div>
                <div style={{ fontSize: '13px', fontWeight: 600, color: licenseActivated ? '#52C41A' : '#FF4D4F' }}>
                  授权 {licenseActivated ? '已激活' : '未激活'}
                </div>
                {licenseInfo && (
                  <div style={{ fontSize: '11px', color: 'var(--text-hint)', marginTop: '2px' }}>
                    {licenseInfo.licenseType === LicenseType.PERMANENT
                      ? '永久版'
                      : licenseInfo.licenseType === LicenseType.TRIAL
                        ? '体验版'
                        : '免费版'}{' '}
                    · 已同步 {licenseInfo.usedSyncCount} / {licenseInfo.maxSyncCount === Infinity ? '∞' : licenseInfo.maxSyncCount} 篇
                  </div>
                )}
              </div>
            </div>
            {!licenseActivated && (
              <button className="xhs-btn xhs-btn-primary" onClick={openActivationPage} style={{ fontSize: '12px', padding: '6px 14px' }}>
                前往激活
              </button>
            )}
          </div>
        </div>
      </div>

      {/* 小红书授权卡片 */}
      <div className="px-4 pb-2">
        <div className="xhs-card glass-card">
          <div className="xhs-card-title">小红书授权</div>
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
            <div>
              <div style={{ fontSize: '14px', fontWeight: 500, display: 'flex', alignItems: 'center', gap: '6px' }}>
                {xiaohongshuAuthorized ? (
                  <>
                    <span style={{ color: 'var(--success-color)' }}>✅</span>
                    <span style={{ color: 'var(--success-color)' }}>已授权</span>
                  </>
                ) : (
                  <>
                    <span style={{ color: 'var(--error-color)' }}>❌</span>
                    <span style={{ color: 'var(--error-color)' }}>未授权</span>
                  </>
                )}
              </div>
              <div style={{ fontSize: '12px', color: 'var(--text-hint)', marginTop: '4px' }}>
                {xiaohongshuAuthorized && userInfo ? `👤 ${userInfo.nickname}` : '请先授权登录小红书账号'}
              </div>
            </div>
            <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
              <span className={`xhs-badge ${xiaohongshuAuthorized ? 'xhs-badge-success' : 'xhs-badge-warning'}`}>
                {xiaohongshuAuthorized ? '已授权' : '未授权'}
              </span>
              <button
                className={`xhs-btn ${xiaohongshuAuthorized ? 'xhs-btn-secondary' : 'xhs-btn-primary'}`}
                onClick={xiaohongshuAuthorized ? checkXiaohongshuAuth : handleXiaohongshuAuth}
                disabled={xiaohongshuLoading}
                style={{ fontSize: '12px', padding: '6px 14px', opacity: xiaohongshuLoading ? 0.7 : 1 }}
              >
                {xiaohongshuLoading ? (
                  <span style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
                    <span
                      className="loading-spinner"
                      style={{
                        display: 'inline-block',
                        width: '12px',
                        height: '12px',
                        border: '2px solid rgba(0,0,0,0.1)',
                        borderTopColor: 'var(--primary-color)',
                        borderRadius: '50%',
                        animation: 'spin 0.8s linear infinite'
                      }}
                    />
                    检测中...
                  </span>
                ) : xiaohongshuAuthorized ? (
                  '🔄 刷新'
                ) : (
                  '🔗 授权'
                )}
              </button>
            </div>
          </div>
          {xiaohongshuAuthorized && userInfo && (
            <div
              style={{
                marginTop: '12px',
                padding: '10px 12px',
                background: 'linear-gradient(135deg, rgba(255, 36, 66, 0.08), rgba(255, 36, 66, 0.02))',
                borderRadius: 'var(--radius-md)',
                border: '1px solid rgba(255, 36, 66, 0.1)'
              }}
            >
              <div style={{ fontSize: '12px', color: 'var(--text-secondary)' }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: '6px', marginBottom: '4px' }}>
                  <span>👤</span>
                  <span style={{ fontWeight: 500 }}>{userInfo.nickname}</span>
                </div>
                <div style={{ display: 'flex', alignItems: 'center', gap: '6px', fontSize: '11px' }}>
                  <span>🔑</span>
                  <span>用户ID: {userInfo.userId}</span>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* 智能知识库开关 */}
      <div className="px-4 pb-2">
        <div className="xhs-card glass-card">
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
              <div
                style={{
                  width: '40px',
                  height: '40px',
                  borderRadius: '50%',
                  background: knowledgeBaseEnabled
                    ? 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)'
                    : 'linear-gradient(135deg, #999 0%, #666 100%)',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  fontSize: '18px',
                  boxShadow: knowledgeBaseEnabled ? '0 4px 14px rgba(102, 126, 234, 0.35)' : 'none'
                }}
              >
                📚
              </div>
              <div>
                <div style={{ fontSize: '14px', fontWeight: 600, color: 'var(--text-primary)' }}>智能知识库</div>
                <div style={{ fontSize: '11px', color: 'var(--text-hint)', marginTop: '2px' }}>AI智能分析 + 主题归档</div>
              </div>
            </div>
            <div
              className={`xhs-switch ${knowledgeBaseEnabled ? 'active' : ''}`}
              onClick={toggleKnowledgeBase}
              style={{ background: knowledgeBaseEnabled ? 'var(--primary-gradient)' : 'var(--border-color)', cursor: 'pointer' }}
            />
          </div>
          {knowledgeBaseEnabled && (
            <div style={{ marginTop: '12px', padding: '10px 12px', background: 'var(--bg-secondary)', borderRadius: 'var(--radius-md)' }}>
              <div style={{ fontSize: '11px', color: 'var(--text-secondary)', marginBottom: '8px' }}>已启用功能：</div>
              <div style={{ display: 'flex', flexWrap: 'wrap', gap: '6px' }}>
                {['🤖 AI分析', '📂 主题归档', '🏷️ 智能标签', '🔍 内容索引', '🛤️ 学习路径'].map((item) => (
                  <span
                    key={item}
                    style={{
                      display: 'flex',
                      alignItems: 'center',
                      gap: '4px',
                      padding: '4px 8px',
                      background: 'white',
                      borderRadius: '6px',
                      fontSize: '11px',
                      fontWeight: 500,
                      color: 'var(--text-primary)'
                    }}
                  >
                    {item}
                  </span>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>

      {/* 同步进度展示 */}
      {syncProgress > 0 && syncProgress < 100 && (
        <div className="px-4 pb-2 animate-fade-in">
          <div className="xhs-card glass-card" style={{ padding: '12px 16px' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '16px' }}>
              <CircularProgress progress={syncProgress} size={56} strokeWidth={4} />
              <div style={{ flex: 1 }}>
                <div style={{ fontSize: '13px', fontWeight: 500, color: 'var(--text-primary)' }}>
                  正在同步中...
                  {syncStatusText && (
                    <span style={{ fontSize: '12px', color: 'var(--text-secondary)', marginLeft: '8px' }}>({syncStatusText})</span>
                  )}
                </div>
                <div className="sync-progress-detail">
                  <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                    <span>已完成</span>
                    <span style={{ color: 'var(--primary-color)' }}>{Math.round(syncProgress)}%</span>
                  </div>
                  <div className="sync-progress-bar-container">
                    <div className="sync-progress-bar" style={{ width: `${syncProgress}%` }} />
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Tab 切换 */}
      <div className="px-4">
        <div className="glass-card" style={{ padding: '4px', display: 'flex' }}>
          <button
            onClick={() => setActiveTab('sync')}
            className={`xhs-btn ${activeTab === 'sync' ? 'xhs-btn-primary' : 'xhs-btn-secondary'}`}
            style={{ flex: 1, borderRadius: 'var(--radius-md)', boxShadow: activeTab === 'sync' ? 'var(--shadow-sm)' : 'none' }}
          >
            📥 同步管理
          </button>
          <button
            onClick={() => setActiveTab('config')}
            className={`xhs-btn ${activeTab === 'config' ? 'xhs-btn-primary' : 'xhs-btn-secondary'}`}
            style={{ flex: 1, borderRadius: 'var(--radius-md)', boxShadow: activeTab === 'config' ? 'var(--shadow-sm)' : 'none' }}
          >
            ⚙️ 配置设置
          </button>
        </div>
      </div>

      {/* 同步管理面板 */}
      {activeTab === 'sync' && (
        <div className="p-4">
          <div className="xhs-card glass-card">
            <div className="xhs-card-title">同步内容</div>
            <SyncCard
              title="个人帖子"
              icon="📝"
              iconClass="post"
              isActive={syncPostStatus}
              lastSyncTime={lastPostSyncTime}
              onToggle={() => toggleSync('rednotePost')}
              disabled={!licenseActivated || !xiaohongshuAuthorized}
            />
            <SyncCard
              title="收藏内容"
              icon="⭐"
              iconClass="bookmark"
              isActive={syncBookmarkStatus}
              lastSyncTime={lastBookmarkSyncTime}
              onToggle={() => toggleSync('rednoteBookmark')}
              disabled={!licenseActivated || !xiaohongshuAuthorized}
            />
            <SyncCard
              title="点赞内容"
              icon="❤️"
              iconClass="like"
              isActive={syncLikeStatus}
              lastSyncTime={lastLikeSyncTime}
              onToggle={() => toggleSync('rednoteLike')}
              disabled={!licenseActivated || !xiaohongshuAuthorized}
            />
          </div>

          <div className="xhs-card glass-card">
            <div className="xhs-card-title">快捷操作</div>
            <div style={{ display: 'flex', gap: '10px' }}>
              <button className="xhs-btn xhs-btn-secondary xhs-btn-block" onClick={stopAllSync} disabled={!licenseActivated}>
                ⏹️ 停止全部
              </button>
              <button className="xhs-btn xhs-btn-outline xhs-btn-block" onClick={clearCache} disabled={!licenseActivated}>
                🗑️ 清除缓存
              </button>
            </div>
          </div>

          {aiEnableClassify && (
            <div className="xhs-card glass-card" style={{ background: 'linear-gradient(135deg, #FFF5F5 0%, #FFFFFF 100%)' }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                <span style={{ fontSize: '20px' }}>🤖</span>
                <div>
                  <div style={{ fontWeight: 600, fontSize: '14px' }}>AI智能分类已启用</div>
                  <div style={{ fontSize: '12px', color: 'var(--text-hint)' }}>
                    当前使用: {currentPreset?.name} · {aiModel}
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
      )}

      {/* 配置设置面板 */}
      {activeTab === 'config' && (
        <div className="p-4">
          <div className="xhs-card glass-card">
            <div className="xhs-card-title">Notion 配置</div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: '14px' }}>
              <div>
                <label className="xhs-input-label">API Key</label>
                <input
                  type="password"
                  value={notionApiKey}
                  onChange={(e) => setNotionApiKey(e.target.value)}
                  className="xhs-input"
                  placeholder="输入 Notion Integration Token"
                  disabled={!licenseActivated}
                />
              </div>
              <div>
                <label className="xhs-input-label">数据库 ID</label>
                <input
                  type="text"
                  value={notionDatabaseId}
                  onChange={(e) => setNotionDatabaseId(e.target.value)}
                  className="xhs-input"
                  placeholder="输入 Notion 数据库 ID"
                  disabled={!licenseActivated}
                />
              </div>
            </div>
          </div>

          <div className="xhs-card glass-card">
            <div className="xhs-card-title">🗂️ 数据库管理</div>
            {notionDatabaseId && (
              <div style={{ marginBottom: '12px', padding: '10px', background: '#F0F9FF', borderRadius: '8px' }}>
                <div style={{ fontSize: '12px', color: 'var(--text-secondary)' }}>当前数据库ID</div>
                <div style={{ fontSize: '13px', fontWeight: 500, wordBreak: 'break-all' }}>{notionDatabaseId}</div>
                {databaseUrl && (
                  <a href={databaseUrl} target="_blank" rel="noopener noreferrer" style={{ fontSize: '12px', color: 'var(--info-color)' }}>
                    在Notion中打开 →
                  </a>
                )}
              </div>
            )}
            <div style={{ marginBottom: '12px' }}>
              <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '8px' }}>
                <label className="xhs-input-label" style={{ margin: 0 }}>
                  选择父页面
                </label>
                <button
                  className="xhs-btn xhs-btn-secondary xhs-btn-sm"
                  onClick={loadNotionPages}
                  disabled={loading || !licenseActivated}
                >
                  {loading ? '获取中...' : '获取页面列表'}
                </button>
              </div>
              <select
                className="xhs-input"
                value={selectedPageId}
                onChange={(e) => setSelectedPageId(e.target.value)}
                disabled={!licenseActivated}
              >
                <option value="">请选择一个页面</option>
                {notionPages.map((page) => (
                  <option key={page.id} value={page.id}>
                    {page.icon} {page.title}
                  </option>
                ))}
              </select>
            </div>
            <button
              className="xhs-btn xhs-btn-primary xhs-btn-block"
              onClick={handleCreateDatabase}
              disabled={creating || !selectedPageId || !licenseActivated}
            >
              {creating ? '创建中...' : '🚀 一键创建完整数据库'}
            </button>
            {notionDatabaseId && (
              <button
                className="xhs-btn xhs-btn-secondary xhs-btn-block"
                onClick={handleCheckDatabase}
                style={{ marginTop: '8px' }}
                disabled={!licenseActivated}
              >
                🔍 检查数据库完整性
              </button>
            )}
            <div style={{ marginTop: '12px', padding: '10px', background: '#FFF7ED', borderRadius: '8px', fontSize: '12px' }}>
              <div style={{ fontWeight: 500, marginBottom: '4px' }}>💡 创建多视图提示</div>
              <div style={{ color: 'var(--text-secondary)' }}>
                数据库创建后，在Notion中可添加多种视图：
                <br />
                • 📅 日历视图（按发布时间）
                <br />
                • 📊 看板视图（按分类）
                <br />
                • 🖼️ 画廊视图（封面为主）
                <br />
                • 📋 时间轴视图（按收藏时间）
              </div>
            </div>
          </div>

          {/* 关联数据库创建 */}
          <div className="xhs-card glass-card">
            <div className="xhs-card-title">🔗 关联数据库</div>
            <p style={{ fontSize: '12px', color: 'var(--text-hint)', marginBottom: '12px' }}>
              创建作者库、标签库等辅助数据库，与主数据库建立关联
            </p>
            <div style={{ marginBottom: '12px' }}>
              <label style={{ display: 'flex', alignItems: 'center', gap: '8px', fontSize: '13px' }}>
                <input
                  type="checkbox"
                  checked={relationConfig.enableAuthorDB}
                  onChange={(e) => setRelationConfig({ ...relationConfig, enableAuthorDB: e.target.checked })}
                  disabled={!licenseActivated}
                /> 创建作者库
              </label>
              <label style={{ display: 'flex', alignItems: 'center', gap: '8px', fontSize: '13px', marginTop: '6px' }}>
                <input
                  type="checkbox"
                  checked={relationConfig.enableTagDB}
                  onChange={(e) => setRelationConfig({ ...relationConfig, enableTagDB: e.target.checked })}
                  disabled={!licenseActivated}
                /> 创建标签库
              </label>
              <label style={{ display: 'flex', alignItems: 'center', gap: '8px', fontSize: '13px', marginTop: '6px' }}>
                <input
                  type="checkbox"
                  checked={relationConfig.enableAlbumDB}
                  onChange={(e) => setRelationConfig({ ...relationConfig, enableAlbumDB: e.target.checked })}
                  disabled={!licenseActivated}
                /> 创建专辑库
              </label>
            </div>
            <button
              className="xhs-btn xhs-btn-secondary xhs-btn-block"
              onClick={handleCreateRelationDatabases}
              disabled={creatingRelationDB || !notionDatabaseId || !licenseActivated}
            >
              {creatingRelationDB ? '创建中...' : '📚 创建关联数据库'}
            </button>
            {relationDBResult && (
              <div style={{ marginTop: '12px', fontSize: '12px', color: 'var(--success-color)' }}>
                ✅ 关联数据库已创建
                {relationDBResult.authorDBId && <div>作者库: {relationDBResult.authorDBId}</div>}
                {relationDBResult.tagDBId && <div>标签库: {relationDBResult.tagDBId}</div>}
                {relationDBResult.albumDBId && <div>专辑库: {relationDBResult.albumDBId}</div>}
              </div>
            )}
          </div>

          {/* AI 配置 */}
          <div className="xhs-card glass-card">
            <div className="xhs-card-title">🤖 AI 智能分类</div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: '14px' }}>
              <div>
                <label className="xhs-input-label">AI 模型提供商</label>
                <select
                  className="xhs-input"
                  value={aiProvider}
                  onChange={(e) => {
                    const provider = e.target.value as AIProvider;
                    const preset = AI_MODEL_PRESETS[provider];
                    setAiProvider(provider);
                    setAiModel(preset.defaultModel);
                  }}
                  style={{ cursor: 'pointer' }}
                  disabled={!licenseActivated}
                >
                  {Object.entries(AI_MODEL_PRESETS).map(([key, preset]) => (
                    <option key={key} value={key}>
                      {preset.name}
                    </option>
                  ))}
                </select>
                {currentPreset && (
                  <div style={{ fontSize: '11px', color: 'var(--text-hint)', marginTop: '4px' }}>{currentPreset.description}</div>
                )}
              </div>
              <div>
                <label className="xhs-input-label">具体模型</label>
                <input
                  type="text"
                  className="xhs-input"
                  value={aiModel}
                  onChange={(e) => setAiModel(e.target.value)}
                  placeholder={currentPreset?.defaultModel || '输入模型名称，如 gpt-4o'}
                  disabled={!licenseActivated}
                />
                {currentPreset?.models && currentPreset.models.length > 0 && (
                  <div style={{ fontSize: '11px', color: 'var(--text-hint)', marginTop: '4px' }}>
                    常用模型：{currentPreset.models.join('、')}
                  </div>
                )}
              </div>
              <div>
                <label className="xhs-input-label">API Key</label>
                <div style={{ display: 'flex', gap: '8px' }}>
                  <input
                    type="password"
                    value={aiApiKey}
                    onChange={(e) => setAiApiKey(e.target.value)}
                    className="xhs-input"
                    placeholder={currentPreset?.getKeyPlaceholder || '输入 API Key'}
                    style={{ flex: 1 }}
                    disabled={!licenseActivated}
                  />
                  <button
                    className="xhs-btn xhs-btn-secondary"
                    onClick={handleTestConnection}
                    disabled={testingConnection || !aiApiKey || !licenseActivated}
                    style={{ whiteSpace: 'nowrap', padding: '0 12px', fontSize: '12px' }}
                  >
                    {testingConnection ? '测试中...' : '测试连接'}
                  </button>
                </div>
              </div>
              <div
                style={{
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'space-between',
                  paddingTop: '8px',
                  borderTop: '1px solid var(--border-color)'
                }}
              >
                <div>
                  <div style={{ fontWeight: 500, fontSize: '14px' }}>启用AI分类</div>
                  <div style={{ fontSize: '12px', color: 'var(--text-hint)' }}>自动为内容添加智能标签</div>
                </div>
                <div
                  className={`xhs-switch ${aiEnableClassify ? 'active' : ''}`}
                  onClick={() => licenseActivated && setAiEnableClassify(!aiEnableClassify)}
                  style={{ opacity: !licenseActivated ? 0.5 : 1 }}
                />
              </div>
              {aiEnableClassify && aiApiKey && (
                <div
                  style={{
                    fontSize: '11px',
                    color: 'var(--text-hint)',
                    background: 'var(--bg-secondary)',
                    padding: '8px 10px',
                    borderRadius: 'var(--radius-sm)'
                  }}
                >
                  💡 使用 {currentPreset?.name} 的 {aiModel} 模型进行智能分类
                </div>
              )}
            </div>
          </div>

          {/* 智能知识库配置 */}
          <div className="xhs-card glass-card">
            <div className="xhs-card-title">📚 智能知识库</div>
            <div
              style={{
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'space-between',
                marginBottom: '16px',
                padding: '14px 16px',
                background: knowledgeBaseEnabled
                  ? 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)'
                  : 'var(--bg-secondary)',
                borderRadius: '12px',
                color: knowledgeBaseEnabled ? 'white' : 'var(--text-primary)',
                transition: 'all 0.3s ease'
              }}
            >
              <div>
                <div style={{ fontWeight: 600, fontSize: '15px' }}>启用智能知识库</div>
                <div style={{ fontSize: '12px', opacity: knowledgeBaseEnabled ? 0.9 : 0.7, marginTop: '2px' }}>
                  AI智能分析 + 主题归档 + 学习路径
                </div>
              </div>
              <div
                className={`xhs-switch ${knowledgeBaseEnabled ? 'active' : ''}`}
                onClick={toggleKnowledgeBase}
                style={{
                  background: knowledgeBaseEnabled ? 'rgba(255,255,255,0.3)' : 'var(--border-color)',
                  cursor: licenseActivated ? 'pointer' : 'not-allowed',
                  opacity: !licenseActivated ? 0.5 : 1
                }}
              />
            </div>
            {knowledgeBaseEnabled && (
              <>
                <div style={{ marginBottom: '16px' }}>
                  <div style={{ fontWeight: 500, marginBottom: '10px', fontSize: '13px' }}>功能模块</div>
                  <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '8px', padding: '8px 12px', background: 'var(--bg-secondary)', borderRadius: '8px', fontSize: '13px' }}>
                      <span>🤖</span> <span>AI自动分析</span> <span style={{ fontSize: '11px', color: 'var(--text-hint)', marginLeft: 'auto' }}>自动生成摘要、关键词</span>
                    </div>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '8px', padding: '8px 12px', background: 'var(--bg-secondary)', borderRadius: '8px', fontSize: '13px' }}>
                      <span>📂</span> <span>主题归档</span> <span style={{ fontSize: '11px', color: 'var(--text-hint)', marginLeft: 'auto' }}>按知识领域分类</span>
                    </div>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '8px', padding: '8px 12px', background: 'var(--bg-secondary)', borderRadius: '8px', fontSize: '13px' }}>
                      <span>🏷️</span> <span>智能标签</span> <span style={{ fontSize: '11px', color: 'var(--text-hint)', marginLeft: 'auto' }}>AI生成#教程等标签</span>
                    </div>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '8px', padding: '8px 12px', background: 'var(--bg-secondary)', borderRadius: '8px', fontSize: '13px' }}>
                      <span>🔍</span> <span>内容索引</span> <span style={{ fontSize: '11px', color: 'var(--text-hint)', marginLeft: 'auto' }}>一句话摘要+关键词</span>
                    </div>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '8px', padding: '8px 12px', background: 'var(--bg-secondary)', borderRadius: '8px', fontSize: '13px' }}>
                      <span>🛤️</span> <span>学习路径</span> <span style={{ fontSize: '11px', color: 'var(--text-hint)', marginLeft: 'auto' }}>推荐学习顺序</span>
                    </div>
                  </div>
                </div>
                <button
                  className="xhs-btn xhs-btn-primary xhs-btn-block"
                  onClick={() => showToast('智能知识库功能开发中，敬请期待！', 'warning')}
                  style={{ marginBottom: '12px' }}
                >
                  🚀 创建智能知识库
                </button>
                <div style={{ padding: '12px', background: 'linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%)', borderRadius: '10px', fontSize: '12px' }}>
                  <div style={{ fontWeight: 600, marginBottom: '8px' }}>📋 视图创建指南</div>
                  <div style={{ marginBottom: '8px' }}>
                    <div style={{ fontWeight: 500, color: '#667eea' }}>📂 视图一：按主题浏览</div>
                    <div style={{ color: 'var(--text-secondary)' }}>看板视图 → 按「知识主题」分组</div>
                  </div>
                  <div style={{ marginBottom: '8px' }}>
                    <div style={{ fontWeight: 500, color: '#f093fb' }}>📈 视图二：学习进度</div>
                    <div style={{ color: 'var(--text-secondary)' }}>看板视图 → 按「学习状态」分组</div>
                  </div>
                  <div style={{ marginBottom: '8px' }}>
                    <div style={{ fontWeight: 500, color: '#4facfe' }}>🔍 视图三：快速检索</div>
                    <div style={{ color: 'var(--text-secondary)' }}>表格视图 → 显示摘要、关键词</div>
                  </div>
                  <div>
                    <div style={{ fontWeight: 500, color: '#43e97b' }}>🛤️ 视图四：学习路径</div>
                    <div style={{ color: 'var(--text-secondary)' }}>表格视图 → 按学习路径排序</div>
                  </div>
                </div>
                <div style={{ marginTop: '12px', padding: '10px', background: 'var(--bg-secondary)', borderRadius: '8px', fontSize: '11px' }}>
                  <div style={{ fontWeight: 500, marginBottom: '6px' }}>📚 知识主题分类</div>
                  <div style={{ display: 'flex', flexWrap: 'wrap', gap: '4px' }}>
                    {['编程开发', '设计美学', '理财投资', '职场成长', '健康生活', '语言学习', '效率工具', '兴趣爱好', '其他'].map((topic) => (
                      <span
                        key={topic}
                        style={{
                          padding: '2px 6px',
                          background: 'white',
                          borderRadius: '4px',
                          fontSize: '10px',
                          color: 'var(--text-secondary)'
                        }}
                      >
                        {topic}
                      </span>
                    ))}
                  </div>
                </div>
              </>
            )}
          </div>

          {/* 调试工具 */}
          <div className="xhs-card glass-card">
            <div className="xhs-card-title">🛠️ 调试工具</div>
            <button className="xhs-btn xhs-btn-outline xhs-btn-block" onClick={handleExportLogs}>
              📋 导出调试日志
            </button>
            <p style={{ fontSize: '11px', color: 'var(--text-hint)', marginTop: '8px' }}>
              导出日志文件，便于反馈问题时提供给开发者
            </p>
          </div>

          <button
            className="xhs-btn xhs-btn-primary xhs-btn-block"
            onClick={saveConfig}
            disabled={!licenseActivated}
            style={{ marginTop: '16px' }}
          >
            💾 保存所有配置
          </button>
        </div>
      )}

      <Toast message={toast.message} type={toast.type} show={toast.show} />
    </div>
  );
};

export default SidePanel;

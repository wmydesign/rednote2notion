import React, { useState, useEffect } from 'react';
import { resetSyncCount, getCurrentLicense, LicenseType } from './lib/license';
import './style.css';

const OptionsPage = () => {
  const [globalConfig, setGlobalConfig] = useState({
    syncInterval: 5,
    autoStartSync: false,
    maxSyncPerTime: 20,
    requestDelay: 800,
    enableErrorLog: true,
    autoRetryCount: 3
  });

  const [notionConfig, setNotionConfig] = useState({
    autoCreateField: true,
    defaultCategory: '未分类',
    pageMaxBlockCount: 100
  });

  const [licenseInfo, setLicenseInfo] = useState<any>(null);
  const [loading, setLoading] = useState(false);

  // 加载配置
  useEffect(() => {
    loadConfig();
    loadLicenseInfo();
  }, []);

  const loadConfig = async () => {
    const storageData = await chrome.storage.local.get([
      'global_sync_config',
      'notion_global_config'
    ]);

    if (storageData.global_sync_config) {
      setGlobalConfig(storageData.global_sync_config);
    }
    if (storageData.notion_global_config) {
      setNotionConfig(storageData.notion_global_config);
    }
  };

  const loadLicenseInfo = async () => {
    const license = await getCurrentLicense();
    setLicenseInfo(license);
  };

  // 保存配置
  const saveAllConfig = async () => {
    setLoading(true);
    await chrome.storage.local.set({
      'global_sync_config': globalConfig,
      'notion_global_config': notionConfig
    });
    await loadConfig();
    setLoading(false);
    alert('全局配置保存成功！');
  };

  // 重置同步计数（仅管理员/永久版可用）
  const handleResetSyncCount = async () => {
    if (!licenseInfo || licenseInfo.licenseType !== LicenseType.PERMANENT) {
      alert('仅永久版可重置同步计数');
      return;
    }
    if (confirm('确定要重置同步计数吗？仅重置计数，不会删除已同步的内容')) {
      await resetSyncCount();
      await loadLicenseInfo();
      alert('同步计数已重置');
    }
  };

  // 清除所有配置
  const handleClearAllConfig = async () => {
    if (confirm('确定要清除所有配置吗？此操作不可恢复，将重置所有设置和同步进度')) {
      await chrome.storage.local.clear();
      await loadConfig();
      await loadLicenseInfo();
      alert('所有配置已清除');
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 p-8 pb-20">
      <div className="max-w-4xl mx-auto">
        <h1 className="text-3xl font-bold text-gray-800 mb-6">Rednote2Notion 全局设置</h1>
        
        {/* 授权信息卡片 */}
        {licenseInfo && (
          <div className="bg-white rounded-lg shadow-sm p-6 mb-6 border-l-4 border-red-500">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-xl font-semibold text-gray-800">
                  授权版本：
                  <span className={`ml-2 ${licenseInfo.licenseType === LicenseType.PERMANENT ? 'text-green-600' : licenseInfo.licenseType === LicenseType.TRIAL ? 'text-blue-600' : 'text-gray-600'}`}>
                    {licenseInfo.licenseType === LicenseType.FREE ? '免费版' : 
                     licenseInfo.licenseType === LicenseType.TRIAL ? '7天体验版' : '永久版'}
                  </span>
                </h2>
                <p className="text-sm text-gray-600 mt-1">
                  已同步数量：{licenseInfo.usedSyncCount} / {licenseInfo.maxSyncCount === Infinity ? '无限制' : licenseInfo.maxSyncCount} 篇
                  {licenseInfo.licenseType === LicenseType.TRIAL && (
                    <span className="ml-4">有效期至：{new Date(licenseInfo.expireTime).toLocaleString()}</span>
                  )}
                </p>
                {!licenseInfo.isValid && (
                  <p className="text-sm text-red-500 mt-1">授权异常：{licenseInfo.errorMsg}</p>
                )}
              </div>
              {licenseInfo.licenseType === LicenseType.PERMANENT && (
                <button
                  onClick={handleResetSyncCount}
                  className="px-4 py-2 bg-gray-200 text-gray-800 rounded-md hover:bg-gray-300 text-sm"
                >
                  重置同步计数
                </button>
              )}
            </div>
          </div>
        )}

        {/* 同步核心设置 */}
        <div className="bg-white rounded-lg shadow-sm p-6 mb-6">
          <h2 className="text-xl font-semibold mb-4 text-gray-800 border-b pb-2">同步核心设置</h2>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                同步间隔（分钟）
              </label>
              <input
                type="number"
                min="1"
                max="120"
                value={globalConfig.syncInterval}
                onChange={(e) => setGlobalConfig({ ...globalConfig, syncInterval: parseInt(e.target.value) })}
                className="w-full px-3 py-2 border border-gray-300 rounded-md"
              />
              <p className="text-xs text-gray-500 mt-1">建议设置5-10分钟，避免触发小红书风控</p>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                单次同步最大数量
              </label>
              <input
                type="number"
                min="1"
                max="100"
                value={globalConfig.maxSyncPerTime}
                onChange={(e) => setGlobalConfig({ ...globalConfig, maxSyncPerTime: parseInt(e.target.value) })}
                className="w-full px-3 py-2 border border-gray-300 rounded-md"
              />
              <p className="text-xs text-gray-500 mt-1">单次同步的笔记上限，降低可减少风控风险</p>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                请求间隔（毫秒）
              </label>
              <input
                type="number"
                min="200"
                max="5000"
                value={globalConfig.requestDelay}
                onChange={(e) => setGlobalConfig({ ...globalConfig, requestDelay: parseInt(e.target.value) })}
                className="w-full px-3 py-2 border border-gray-300 rounded-md"
              />
              <p className="text-xs text-gray-500 mt-1">数值越大，风控风险越低，同步速度越慢</p>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                失败自动重试次数
              </label>
              <input
                type="number"
                min="0"
                max="10"
                value={globalConfig.autoRetryCount}
                onChange={(e) => setGlobalConfig({ ...globalConfig, autoRetryCount: parseInt(e.target.value) })}
                className="w-full px-3 py-2 border border-gray-300 rounded-md"
              />
              <p className="text-xs text-gray-500 mt-1">API请求失败时的自动重试次数</p>
            </div>
          </div>
          <div className="flex flex-wrap gap-6 mt-4">
            <div className="flex items-center">
              <input
                type="checkbox"
                id="autoStartSync"
                checked={globalConfig.autoStartSync}
                onChange={(e) => setGlobalConfig({ ...globalConfig, autoStartSync: e.target.checked })}
                className="w-4 h-4 text-red-500 rounded"
              />
              <label htmlFor="autoStartSync" className="ml-2 text-sm text-gray-700">
                浏览器启动时自动恢复同步任务
              </label>
            </div>
            <div className="flex items-center">
              <input
                type="checkbox"
                id="enableErrorLog"
                checked={globalConfig.enableErrorLog}
                onChange={(e) => setGlobalConfig({ ...globalConfig, enableErrorLog: e.target.checked })}
                className="w-4 h-4 text-red-500 rounded"
              />
              <label htmlFor="enableErrorLog" className="ml-2 text-sm text-gray-700">
                启用错误日志记录
              </label>
            </div>
          </div>
        </div>

        {/* Notion全局设置 */}
        <div className="bg-white rounded-lg shadow-sm p-6 mb-6">
          <h2 className="text-xl font-semibold mb-4 text-gray-800 border-b pb-2">Notion全局设置</h2>
          <div className="space-y-4">
            <div className="flex items-center">
              <input
                type="checkbox"
                id="autoCreateField"
                checked={notionConfig.autoCreateField}
                onChange={(e) => setNotionConfig({ ...notionConfig, autoCreateField: e.target.checked })}
                className="w-4 h-4 text-red-500 rounded"
              />
              <label htmlFor="autoCreateField" className="ml-2 text-sm text-gray-700">
                自动创建AI加工模板对应的Notion字段
              </label>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  默认分类名称
                </label>
                <input
                  type="text"
                  value={notionConfig.defaultCategory}
                  onChange={(e) => setNotionConfig({ ...notionConfig, defaultCategory: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md"
                  placeholder="未分类"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  单页面最大内容块数量
                </label>
                <input
                  type="number"
                  min="50"
                  max="500"
                  value={notionConfig.pageMaxBlockCount}
                  onChange={(e) => setNotionConfig({ ...notionConfig, pageMaxBlockCount: parseInt(e.target.value) })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md"
                />
                <p className="text-xs text-gray-500 mt-1">Notion单页面块数量上限，超出会自动截断</p>
              </div>
            </div>
          </div>
        </div>

        {/* 操作按钮 */}
        <div className="flex gap-4">
          <button
            onClick={saveAllConfig}
            disabled={loading}
            className="flex-1 py-3 bg-red-500 text-white rounded-md hover:bg-red-600 disabled:bg-gray-400 font-medium text-lg"
          >
            {loading ? '保存中...' : '保存全部配置'}
          </button>
          <button
            onClick={handleClearAllConfig}
            className="flex-1 py-3 bg-gray-200 text-gray-800 rounded-md hover:bg-gray-300 font-medium"
          >
            重置所有配置
          </button>
        </div>

        {/* 底部说明 */}
        <div className="mt-8 text-center text-sm text-gray-500">
          <p>Rednote2Notion V2.0.0 | 有问题请查看插件控制台错误日志</p>
        </div>
      </div>
    </div>
  );
};

export default OptionsPage;

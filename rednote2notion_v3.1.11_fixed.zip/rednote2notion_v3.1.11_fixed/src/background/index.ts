/**
 * Background Service Worker - V3.1.1
 * 重构：使用模块化消息处理器
 * 修复：并发状态、请求指纹随机化、间隔抖动、进度通知
 * 集成：统一日志管理器
 * 增强：动态规则集启用容错处理
 */

import { MessageType, platformConfig } from '../lib/types';
import { messageRouter } from '../lib/message-handlers';
import { stateManager } from '../lib/state-manager';
import { logger } from '../lib/logger';

const MODULE = 'Background';

// ==================== 插件安装初始化 ====================
chrome.runtime.onInstalled.addListener(async () => {
  try {
    logger.info(MODULE, 'Rednote2Notion V3.1.1 插件已安装');

    // 安全启用跨域规则集（避免因非法规则导致崩溃）
    await safelyEnableRuleset('ruleset_1');

  } catch (error) {
    logger.error(MODULE, '初始化过程中发生意外错误', error);
  }
});

/**
 * 安全启用规则集：先检查是否已启用，避免无效调用
 */
async function safelyEnableRuleset(rulesetId: string): Promise<void> {
  try {
    // 1. 检查规则集是否已存在且可访问
    const availableRulesets = await chrome.declarativeNetRequest.getAvailableStaticRuleCount();
    logger.debug(MODULE, `可用静态规则计数: ${availableRulesets}`);

    // 2. 获取当前已启用的规则集列表
    const enabledRulesets = await chrome.declarativeNetRequest.getEnabledRulesets();
    
    if (enabledRulesets.includes(rulesetId)) {
      logger.debug(MODULE, `规则集 ${rulesetId} 已处于启用状态，无需操作`);
      return;
    }

    // 3. 尝试启用目标规则集
    await chrome.declarativeNetRequest.updateEnabledRulesets({
      enableRulesetIds: [rulesetId]
    });
    
    logger.info(MODULE, `✅ 规则集 ${rulesetId} 动态启用成功`);

  } catch (error) {
    // 如果启用失败（通常因 rules.json 格式错误或包含非法规则），记录警告但不阻断插件
    logger.warn(
      MODULE,
      `⚠️ 规则集 ${rulesetId} 启用失败，请检查 src/rules.json 是否符合
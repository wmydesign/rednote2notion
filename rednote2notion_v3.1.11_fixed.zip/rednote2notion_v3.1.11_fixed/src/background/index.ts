/**
 * Background Service Worker - V3.1.1
 * 重构：使用模块化消息处理器
 * 修复：并发状态、请求指纹随机化、间隔抖动、进度通知
 * 集成：统一日志管理器
 * 增强：动态规则集启用容错处理，避免因 rules.json 非法导致扩展崩溃
 */

import { MessageType, platformConfig } from '../lib/types';
import { messageRouter } from '../lib/message-handlers';
import { stateManager } from '../lib/state-manager';
import { logger } from '../lib/logger';

const MODULE = 'Background';

// ==================== 安全启用静态规则集 ====================
async function safelyEnableRuleset(rulesetId: string): Promise<void> {
  try {
    // 检查规则集是否已处于启用状态
    const enabledRulesets = await chrome.declarativeNetRequest.getEnabledRulesets();
    if (enabledRulesets.includes(rulesetId)) {
      logger.debug(MODULE, `规则集 ${rulesetId} 已启用，无需重复操作`);
      return;
    }

    // 尝试启用规则集（若 rules.json 存在且格式合法）
    await chrome.declarativeNetRequest.updateEnabledRulesets({
      enableRulesetIds: [rulesetId]
    });
    logger.info(MODULE, `✅ 规则集 ${rulesetId} 动态启用成功`);
  } catch (error) {
    // 规则启用失败通常因 rules.json 缺失或包含非法规则（如修改 CORS 响应头）
    // 此处仅记录警告，不影响扩展其他功能
    logger.warn(
      MODULE,
      `⚠️ 规则集 ${rulesetId} 启用失败，请检查 src/rules.json 是否符合 Chrome 规范（不得修改 Access-Control-* 响应头）`,
      error
    );
  }
}

// ==================== 插件安装初始化 ====================
chrome.runtime.onInstalled.addListener(async () => {
  try {
    logger.info(MODULE, 'Rednote2Notion V3.1.1 插件已安装');

    // 启用跨域请求头修改规则（若 manifest 已设置 enabled: true，此调用为幂等操作）
    await safelyEnableRuleset('ruleset_1');

  } catch (error) {
    logger.error(MODULE, '初始化过程中发生意外错误', error);
  }
});

// ==================== 消息监听（使用模块化路由）====================
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  messageRouter.handle(message, sender)
    .then(result => sendResponse({ success: true, data: result }))
    .catch(error => {
      logger.error(MODULE, '消息处理失败', { message: message.name, error });
      sendResponse({ success: false, error: '内部错误，请重试' });
    });
  return true; // 保证异步响应
});

// ==================== 定时同步闹钟 ====================
chrome.alarms.onAlarm.addListener(async (alarm) => {
  if (!alarm.name.startsWith('rednote-sync-')) return;
  const platform = alarm.name.replace('rednote-sync-', '') as keyof typeof platformConfig;

  logger.info(MODULE, `定时同步闹钟触发`, { platform, timestamp: new Date().toISOString() });
  
  try {
    const isBusy = await stateManager.get('syncInProgress');
    if (isBusy) {
      logger.debug(MODULE, `同步任务已在进行中，跳过此次触发`, { platform });
      return;
    }
    await stateManager.set('syncInProgress', true);

    const config = await stateManager.get('sync_config') as any;
    if (!config?.notionApiKey || !config?.notionDatabaseId) {
      logger.warn(MODULE, `配置不完整，跳过同步`, { platform });
      return;
    }

    await messageRouter.handle({
      name: MessageType.SYNC_TO_NOTION,
      data: {
        platform,
        notionApiKey: config.notionApiKey,
        notionDatabaseId: config.notionDatabaseId,
        ...config
      }
    }, { tab: undefined });

    logger.info(MODULE, `定时同步完成`, { platform });
  } catch (error) {
    logger.error(MODULE, `定时同步失败`, { platform, error });
  } finally {
    await stateManager.set('syncInProgress', false);
  }
});

// ==================== 导出（供其他模块使用）====================
export { platformConfig };
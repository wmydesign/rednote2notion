/**
 * @deprecated 请使用 ai-service.ts 中的函数
 * 此文件保留用于向后兼容
 */
import { 
  classifyNoteWithAI as newClassifyNoteWithAI,
  processNoteWithAI as newProcessNoteWithAI,
  batchProcessNoteWithAI as newBatchProcessNoteWithAI,
  testAIConnection as newTestAIConnection,
  createAIClient as newCreateAIClient,
  AIProvider,
  AI_MODEL_PRESETS,
  DEFAULT_CATEGORIES,
  type AIModelConfig
} from './ai-service';
import type { RednoteNote, AIProcessTemplate, AIProcessResult } from './types';

// 导出新的类型和常量
export { AIProvider, AI_MODEL_PRESETS, DEFAULT_CATEGORIES };
export type { AIModelConfig };

// 导出新的测试连接函数
export const testAIConnection = newTestAIConnection;

// 导出新的客户端创建函数
export { newCreateAIClient as createAIClient };

/**
 * @deprecated 使用新版 classifyNoteWithAI(config, note) 替代
 */
export const classifyNoteWithAI = async (
  apiKey: string,
  note: RednoteNote,
  customCategories: string[] = DEFAULT_CATEGORIES
): Promise<string> => {
  return newClassifyNoteWithAI(
    { provider: AIProvider.OPENAI, apiKey, model: 'gpt-3.5-turbo' },
    note,
    customCategories
  );
};

/**
 * @deprecated 使用新版 processNoteWithAI(config, note, template) 替代
 */
export const processNoteWithAI = async (
  apiKey: string,
  note: RednoteNote,
  template: AIProcessTemplate
): Promise<AIProcessResult> => {
  return newProcessNoteWithAI(
    { provider: AIProvider.OPENAI, apiKey, model: 'gpt-3.5-turbo' },
    note,
    template
  );
};

/**
 * @deprecated 使用新版 batchProcessNoteWithAI(config, note, templates) 替代
 */
export const batchProcessNoteWithAI = async (
  apiKey: string,
  note: RednoteNote,
  templates: AIProcessTemplate[]
): Promise<AIProcessResult[]> => {
  return newBatchProcessNoteWithAI(
    { provider: AIProvider.OPENAI, apiKey, model: 'gpt-3.5-turbo' },
    note,
    templates
  );
};

/**
 * 消息处理器模块 (集成日志版)
 * 修复内容：
 * 1. 主动获取并注入 Cookie，解决登录态丢失问题
 * 2. 自动解析用户 ID，无需手动输入
 * 3. 修正分页结束判断，防止遗漏数据
 * 4. 记录失败笔记 ID，便于用户重试
 * 5. 集成统一日志管理器，实现全链路监控
 */

import { MessageType, KnowledgeType, platformConfig, AIProvider } from '../lib/types';
import { stateManager, startSync, completeSync, updateProgress, setSyncStep, sendError } from '../lib/state-manager';
import { RednoteParser } from '../lib/rednote-parser';
import { checkSyncPermission, updateSyncCount } from '../lib/license';
import { writeNoteToNotion, checkNoteIsSynced } from '../lib/notion';
import { classifyNoteWithAI } from '../lib/ai-service';
import { retryWithBackoff, createConcurrentQueue, createRateLimiter } from '../lib/concurrent';
import { getBrowserInfo, getBrowserSpecificHeaders } from '../lib/browser-polyfill';
import { logger } from '../lib/logger';
import type { AIModelConfig, RednoteNote, SyncSnapshot, SyncConfig } from '../lib/types';

// 模块标识
const MODULE = 'MessageRouter';

// ==================== Cookie 管理器（日志增强） ====================
class CookieManager {
  /**
   * 获取小红书域下所有 Cookie，并格式化为请求头字符串
   */
  static async getCookieHeader(): Promise<string> {
    try {
      const cookies = await chrome.cookies.getAll({ domain: '.xiaohongshu.com' });
      logger.debug(MODULE, `获取到 ${cookies.length} 个 Cookie`);
      return cookies.map(c => `${c.name}=${c.value}`).join('; ');
    } catch (error) {
      logger.error(MODULE, '获取 Cookie 失败', error);
      return '';
    }
  }

  /**
   * 从 Cookie 字符串中解析当前登录用户 ID
   */
  static getUserIdFromCookie(cookieString: string): string | null {
    const match = cookieString.match(/a1=([^;]+)/);
    if (match) {
      try {
        const decoded = decodeURIComponent(match[1]);
        const userMatch = decoded.match(/"userId":"(\d+)"/);
        if (userMatch) return userMatch[1];
      } catch {
        // 解析失败回退
      }
    }
    return null;
  }

  /**
   * 确保获取到用户 ID（优先缓存，其次从 Cookie 解析）
   */
  static async ensureUserId(): Promise<string> {
    // 1. 优先从状态管理器获取
    const currentUser = await stateManager.getCurrentUser();
    if (currentUser?.userId) {
      logger.debug(MODULE, '从缓存获取用户ID', { userId: currentUser.userId });
      return currentUser.userId;
    }

    // 2. 从 Cookie 解析
    const cookieStr = await this.getCookieHeader();
    const userIdFromCookie = this.getUserIdFromCookie(cookieStr);
    if (userIdFromCookie) {
      logger.info(MODULE, '从 Cookie 解析用户ID成功', { userId: userIdFromCookie });
      await stateManager.setCurrentUser({ userId: userIdFromCookie, nickname: '' });
      return userIdFromCookie;
    }

    logger.error(MODULE, '无法获取用户ID，Cookie可能已过期');
    throw new Error('无法获取小红书用户ID，请确保已登录');
  }
}

// ==================== 共享常量与接口 ====================
export const REDNOTE_STORAGE_KEYS = [
  'rednote_post_next_cursor', 'rednote_post_prev_cursor', 'rednote_post_all_sync',
  'rednote_bookmark_next_cursor', 'rednote_bookmark_prev_cursor', 'rednote_bookmark_all_sync',
  'rednote_like_next_cursor', 'rednote_like_prev_cursor', 'rednote_like_all_sync'
] as const;

export interface MessageHandler {
  handle(message: any, sender: any): Promise<any>;
}

// ==================== 账号切换处理器 ====================
export class AccountSwitchHandler implements MessageHandler {
  async handle(message: any) {
    const { userId, nickname, avatar } = message.data || {};
    
    try {
      const currentUser = await stateManager.getCurrentUser();
      if (currentUser?.userId) {
        await this.snapshotAccountState(currentUser.userId);
      }
      
      await stateManager.setCurrentUser({ userId, nickname, avatar });
      await this.restoreAccountState(userId);
      
      logger.info(MODULE, `账号切换成功`, { userId });
      return { success: true };
    } catch (error) {
      logger.error(MODULE, '账号切换失败', error);
      return { success: false, error: '账号切换失败' };
    }
  }

  private async snapshotAccountState(userId: string): Promise<void> {
    const storageData = await stateManager.getMany([...REDNOTE_STORAGE_KEYS]);
    const allState = await stateManager.get('rednote_per_account_state') || {};
    allState[userId] = { userId, static: storageData, timestamp: Date.now() };
    await stateManager.set('rednote_per_account_state', allState);
  }

  private async restoreAccountState(userId: string): Promise<void> {
    const allState = await stateManager.get('rednote_per_account_state') || {};
    const state = allState[userId];
    if (!state?.static) return;
    
    const updates: Record<string, any> = {};
    for (const [key, value] of Object.entries(state.static)) {
      if (value !== undefined) updates[key] = value;
    }
    if (Object.keys(updates).length > 0) {
      await stateManager.setMany(updates);
    }
  }
}

// ==================== 清除缓存处理器 ====================
export class ClearCacheHandler implements MessageHandler {
  async handle(message: any, sender: any) {
    for (const key of REDNOTE_STORAGE_KEYS) {
      await stateManager.remove(key);
    }
    logger.info(MODULE, '同步缓存已清除');
    return { success: true };
  }
}

// ==================== 获取Cookie处理器 ====================
export class GetCookieHandler implements MessageHandler {
  async handle(message: any, sender: any): Promise<any> {
    const tabId = sender?.tab?.id;
    if (!tabId) return { success: false, error: '无活动标签页' };
    
    try {
      const results = await chrome.scripting.executeScript({
        target: { tabId },
        func: () => document.cookie
      });
      return { success: true, data: results[0]?.result };
    } catch (err: any) {
      logger.error(MODULE, '获取Cookie失败', err);
      return { success: false, error: `获取Cookie失败: ${err.message}` };
    }
  }
}

// ==================== 停止同步处理器 ====================
export class StopAllSyncHandler implements MessageHandler {
  async handle(message: any, sender: any) {
    const allAlarms = await chrome.alarms.getAll();
    for (const alarm of allAlarms) {
      if (alarm.name.startsWith('rednote-sync-')) {
        await chrome.alarms.clear(alarm.name);
      }
    }
    
    for (const config of Object.values(platformConfig)) {
      await stateManager.updateSyncStatus(config.name, { isRunning: false, currentStep: '已停止' });
    }
    
    logger.info(MODULE, '所有同步任务已停止');
    return { success: true };
  }
}

// ==================== 同步到Notion处理器（核心修复 + 日志增强） ====================
export class SyncToNotionHandler implements MessageHandler {
  private parser = new RednoteParser();
  
  async handle(message: any, sender: any) {
    const config = message.data || {};
    const platformCfg = platformConfig[config.platform];
    
    if (!platformCfg) return { success: false, error: '无效的平台配置' };
    
    await stateManager.updateSyncStatus(config.platform, { isRunning: true, currentStep: '正在初始化...' });
    
    // 异步不阻塞
    this.executeSync(config).catch(err => logger.error(MODULE, `同步任务崩溃 [${config.platform}]`, err));
    return { success: true };
  }
  
  private async executeSync(config: any) {
    const { platform, notionApiKey, notionDatabaseId, aiProvider, aiModel, aiApiKey, enableAIClassify } = config;
    const platformCfg = platformConfig[platform];
    
    let progressInterval: NodeJS.Timeout | null = null;
    let syncTimeout: NodeJS.Timeout | null = null;
    let total = 0;
    let failed = 0;
    const failedNoteIds: string[] = [];
    
    const aiConfig: AIModelConfig | undefined = enableAIClassify && aiApiKey ? {
      provider: aiProvider || AIProvider.OPENAI,
      apiKey: aiApiKey,
      model: aiModel || 'gpt-3.5-turbo'
    } : undefined;
    
    logger.info(MODULE, `开始同步任务`, { platform, aiEnabled: !!aiConfig });
    
    try {
      await setSyncStep(platform, '正在验证授权...');
      const permission = await checkSyncPermission();
      if (!permission.hasPermission) {
        logger.warn(MODULE, '授权验证失败', { platform, error: permission.errorMsg });
        throw new Error(permission.errorMsg || '授权验证失败');
      }
      
      await setSyncStep(platform, '正在检查登录状态...');
      const userId = await CookieManager.ensureUserId();
      
      const concurrentQueue = createConcurrentQueue(3, {
        onProgress: (completed, totalCount) => {
          stateManager.updateSyncStatus(platform, {
            processed: completed,
            total: totalCount,
            progress: totalCount === 0 ? 0 : Math.round((completed / totalCount) * 100)
          });
        }
      });
      
      await setSyncStep(platform, '正在获取笔记列表...');
      const cursor = await stateManager.getCursor(platform as keyof typeof platformConfig) || '';
      const { apiUrl, requestMethod, requestBody } = this.buildApiRequest(platformCfg, userId, cursor);
      const browserHeaders = getBrowserSpecificHeaders();
      
      const cookieHeader = await CookieManager.getCookieHeader();
      if (!cookieHeader) {
        logger.error(MODULE, 'Cookie为空，无法发起请求', { platform });
        throw new Error('无法获取小红书登录Cookie，请刷新页面后重试');
      }
      
      await setSyncStep(platform, '正在请求小红书API...');
      logger.debug(MODULE, '发起小红书API请求', { platform, url: apiUrl });
      
      const response = await this.fetchWithRetry(apiUrl, {
        method: requestMethod,
        credentials: 'include',
        headers: {
          'Content-Type': 'application/json',
          'Referer': 'https://www.xiaohongshu.com/',
          'User-Agent': navigator.userAgent,
          'Cookie': cookieHeader,
          ...browserHeaders
        },
        body: requestBody
      });
      
      if (!response.ok) {
        logger.warn(MODULE, 'API请求失败', { platform, status: response.status });
        throw new Error(`API请求失败: ${response.status}`);
      }
      
      const data = await response.json();
      if (data.code !== 0) {
        logger.warn(MODULE, 'API返回业务错误', { platform, code: data.code, msg: data.msg });
        throw new Error(`API返回错误: ${data.msg}`);
      }
      
      const parseResult = this.parser.parseNoteList(data);
      if (!parseResult.success || !parseResult.data) {
        logger.error(MODULE, '笔记列表解析失败', { platform });
        throw new Error('笔记列表解析失败');
      }
      
      const notes = parseResult.data;
      total = notes.length;
      logger.info(MODULE, `获取到 ${total} 条笔记`, { platform });
      
      if (total === 0) {
         await completeSync(platform);
         logger.info(MODULE, '无新笔记，同步结束', { platform });
         return;
      }
      
      await stateManager.startSync(platform, total);
      
      const rateLimiter = createRateLimiter(1, 1000);
      
      progressInterval = setInterval(async () => {
        const status = concurrentQueue.getStatus();
        await updateProgress(platform, status.completed, failed);
      }, 2000);
      
      syncTimeout = setTimeout(() => {
        logger.warn(MODULE, '同步超时，强制暂停队列', { platform });
        concurrentQueue.pause();
      }, 5 * 60 * 1000);
      
      notes.forEach((rawNote: any, index: number) => {
        concurrentQueue.add(async () => {
          await this.randomDelay(500, 1000);
          await rateLimiter.acquire();
          
          const parsedNote = this.parser.parseNote(rawNote);
          if (!parsedNote.data) throw new Error('笔记解析失败');
          
          return this.processNote(parsedNote.data, notionApiKey, notionDatabaseId, aiConfig);
        }).catch(err => {
          failed++;
          const parsed = this.parser.parseNote(rawNote);
          const noteId = parsed.data?.id || rawNote.id || rawNote.note_id || 'unknown';
          failedNoteIds.push(noteId);
          logger.error(MODULE, `任务失败: 笔记 ${noteId}`, err);
        });
      });
      
      await concurrentQueue.waitForComplete();
      
      const finalStatus = concurrentQueue.getStatus();
      await updateProgress(platform, finalStatus.completed, failed);
      
      const nextCursor = data.data?.cursor || '';
      const hasMore = data.data?.has_more === true || (!!nextCursor && nextCursor !== cursor);
      
      if (hasMore && nextCursor) {
        await stateManager.setCursor(platform as keyof typeof platformConfig, nextCursor);
        logger.debug(MODULE, '保存下一页游标', { platform, cursor: nextCursor });
      } else {
        await stateManager.set(platformCfg.storage.allSync, true);
        logger.info(MODULE, '所有笔记已同步完毕', { platform });
      }
      
      if (failedNoteIds.length > 0) {
        await stateManager.set(`${platform}_failed_notes`, failedNoteIds);
        logger.warn(MODULE, `同步完成，但有 ${failedNoteIds.length} 条失败`, { platform, failedIds: failedNoteIds });
      } else {
        logger.info(MODULE, '同步完成，全部成功', { platform, total });
      }
      
    } catch (error: any) {
      logger.error(MODULE, `同步任务崩溃 [${platform}]`, { error: error.message, stack: error.stack });
      await sendError(platform, error.message);
    } finally {
      if (progressInterval) clearInterval(progressInterval);
      if (syncTimeout) clearTimeout(syncTimeout);
      await completeSync(platform);
    }
  }
  
  private buildApiRequest(platformCfg: any, userId: string, cursor: string) {
    switch (platformCfg.knowledgeType) {
      case KnowledgeType.POST:
        return {
          apiUrl: `https://edith.xiaohongshu.com/api/sns/web/v1/user/notes?cursor=${cursor}&num=20&user_id=${userId}`,
          requestMethod: 'GET',
          requestBody: null
        };
      case KnowledgeType.BOOKMARK:
        return {
          apiUrl: 'https://edith.xiaohongshu.com/api/sns/web/v2/note/collect/page',
          requestMethod: 'POST',
          requestBody: JSON.stringify({ cursor, num: 20 })
        };
      case KnowledgeType.LIKE:
        return {
          apiUrl: 'https://edith.xiaohongshu.com/api/sns/web/v1/note/like/page',
          requestMethod: 'POST',
          requestBody: JSON.stringify({ cursor, num: 20 })
        };
      default:
        return { apiUrl: '', requestMethod: 'GET', requestBody: null };
    }
  }
  
  private async fetchWithRetry(url: string, options: RequestInit, maxRetries: number = 3): Promise<Response> {
    let lastError: Error | null = null;
    for (let i = 0; i < maxRetries; i++) {
      try {
        const response = await fetch(url, options);
        if (response.status === 429) {
          const retryAfter = parseInt(response.headers.get('Retry-After') || '5');
          logger.debug(MODULE, `遇到429限流，等待 ${retryAfter}s 后重试`);
          await this.randomDelay(retryAfter * 1000, retryAfter * 1000 + 2000);
          continue;
        }
        return response;
      } catch (error) {
        lastError = error as Error;
        await this.randomDelay(1000 * Math.pow(2, i), 1500 * Math.pow(2, i));
      }
    }
    throw lastError || new Error('请求重试耗尽');
  }
  
  private async processNote(note: RednoteNote, notionApiKey: string, notionDatabaseId: string, aiConfig?: AIModelConfig): Promise<void> {
    const isSynced = await checkNoteIsSynced(notionApiKey, notionDatabaseId, note.id);
    if (isSynced) {
      logger.debug(MODULE, `笔记已存在，跳过`, { noteId: note.id });
      return;
    }
    
    if (aiConfig) {
      try {
        const aiResult = await Promise.race([
          classifyNoteWithAI(aiConfig, note),
          new Promise<null>((_, reject) => setTimeout(() => reject(new Error('AI分类超时')), 15000))
        ]) as any;
        note.aiCategory = aiResult;
        logger.debug(MODULE, `AI分类完成`, { noteId: note.id, category: aiResult });
      } catch (aiError: any) {
        logger.warn(MODULE, `AI分类超时，跳过`, { noteId: note.id });
      }
    }
    
    await retryWithBackoff(() => writeNoteToNotion(notionApiKey, notionDatabaseId, note), {
      maxRetries: 3,
      baseDelay: 1000,
      timeout: 20000
    });
    
    logger.debug(MODULE, `笔记写入成功`, { noteId: note.id });
    await updateSyncCount(1);
  }
  
  private randomDelay(min: number, max: number): Promise<void> {
    return new Promise(resolve => setTimeout(resolve, Math.floor(Math.random() * (max - min + 1)) + min));
  }
}

// ==================== 同步错误处理器 ====================
export class SyncErrorHandler implements MessageHandler {
  async handle(message: any, sender: any) {
    const { platform, error } = message.data || {};
    if (platform) {
      logger.warn(MODULE, `同步错误上报: ${platform}`, { error });
      await sendError(platform, error || '未知错误');
    }
    return { success: true };
  }
}

// ==================== 消息路由 ====================
export class MessageRouter {
  private handlers: Map<string, MessageHandler> = new Map();
  
  constructor() {
    this.register(MessageType.ACCOUNT_SWITCH, new AccountSwitchHandler());
    this.register(MessageType.CLEAR_CACHE, new ClearCacheHandler());
    this.register(MessageType.GET_COOKIE, new GetCookieHandler());
    this.register(MessageType.STOP_ALL_SYNC, new StopAllSyncHandler());
    this.register(MessageType.SYNC_TO_NOTION, new SyncToNotionHandler());
    this.register(MessageType.SYNC_ERROR, new SyncErrorHandler());
  }
  
  register(messageType: string, handler: MessageHandler): void {
    this.handlers.set(messageType, handler);
  }
  
  getHandler(messageType: string): MessageHandler | undefined {
    return this.handlers.get(messageType);
  }
  
  async handle(message: any, sender: any): Promise<any> {
    const handler = this.handlers.get(message.name);
    if (!handler) {
      logger.warn(MODULE, `未知的消息类型: ${message.name}`);
      return { success: false, error: '未知的消息类型' };
    }
    try {
      return await handler.handle(message, sender);
    } catch (error: any) {
      logger.error(MODULE, `消息处理异常: ${message.name}`, error);
      return { success: false, error: error.message };
    }
  }
}

export const messageRouter = new MessageRouter();
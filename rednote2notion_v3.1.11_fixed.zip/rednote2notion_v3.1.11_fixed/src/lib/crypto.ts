import CryptoJS from 'crypto-js';

// ==================== 硬编码密钥（确保工具端和插件端一致）====================
// 原始密钥: rednote2notion_license_secure_2024_v2
// SHA256 后截取前 32 位: 8074e1be19685b67cb1c1f889206f285
const LICENSE_KEY_32 = '8074e1be19685b67cb1c1f889206f285';
// 原始 IV: license_iv_2024_v2
// MD5 后截取前 16 位: 830d4d9fbc587895
const LICENSE_IV_16 = '830d4d9fbc587895';
// 原始密钥字符串（用于签名验证）
const LICENSE_SECRET_KEY = 'rednote2notion_license_secure_2024_v2';

// 安全获取环境变量（兼容不同运行环境）
const getEnvVar = (key: string, defaultValue: string): string => {
  try {
    // 尝试从 import.meta.env 获取（Plasmo 编译时注入）
    if (typeof import.meta !== 'undefined' && import.meta.env && import.meta.env[key]) {
      return import.meta.env[key];
    }
    // 尝试从 process.env 获取（Node 环境）
    if (typeof process !== 'undefined' && process.env && process.env[key]) {
      return process.env[key];
    }
    return defaultValue;
  } catch {
    return defaultValue;
  }
};

// 加密密钥（通用配置加密用）
const SECRET_KEY = getEnvVar('PLASMO_PUBLIC_CRYPTO_KEY', 'rednote2notion_v2_official_2024_secure_key');
const SECRET_IV = getEnvVar('PLASMO_PUBLIC_CRYPTO_IV', 'rednote2notion_v2_iv_2024');

/**
 * ==================== 通用AES-CBC加密（配置数据用） ====================
 */

/**
 * AES-CBC加密
 * @param data 待加密数据
 * @returns 加密后的字符串
 */
export const encryptAES = (data: string): string => {
  const key = CryptoJS.enc.Utf8.parse(SECRET_KEY);
  const iv = CryptoJS.enc.Utf8.parse(SECRET_IV);
  const encrypted = CryptoJS.AES.encrypt(data, key, {
    iv: iv,
    mode: CryptoJS.mode.CBC,
    padding: CryptoJS.pad.Pkcs7
  });
  return encrypted.toString();
};

/**
 * AES-CBC解密
 * @param encryptedData 加密后的字符串
 * @returns 解密后的原始数据
 */
export const decryptAES = (encryptedData: string): string => {
  try {
    const key = CryptoJS.enc.Utf8.parse(SECRET_KEY);
    const iv = CryptoJS.enc.Utf8.parse(SECRET_IV);
    const decrypted = CryptoJS.AES.decrypt(encryptedData, key, {
      iv: iv,
      mode: CryptoJS.mode.CBC,
      padding: CryptoJS.pad.Pkcs7
    });
    return decrypted.toString(CryptoJS.enc.Utf8);
  } catch (error) {
    console.error('AES解密失败', error);
    throw new Error('数据解密失败，可能已被篡改');
  }
};

/**
 * ==================== 授权码专用加密（防篡改/防倒卖） ====================
 */

/**
 * 授权码加密（专用密钥，与通用加密隔离）
 * @param data 授权原始数据
 * @returns 加密后的授权码
 */
export const encryptLicense = (data: string): string => {
  const key = CryptoJS.enc.Utf8.parse(LICENSE_KEY_32);
  const iv = CryptoJS.enc.Utf8.parse(LICENSE_IV_16);
  // 先加签名防篡改
  const signature = CryptoJS.MD5(data + LICENSE_SECRET_KEY).toString();
  const dataWithSign = JSON.stringify({ data, signature });
  // 双重加密
  const encrypted = CryptoJS.AES.encrypt(dataWithSign, key, {
    iv: iv,
    mode: CryptoJS.mode.CBC,
    padding: CryptoJS.pad.Pkcs7
  });
  // Base64编码后替换特殊字符，方便用户复制
  return encrypted.toString().replace(/\+/g, '-').replace(/\//g, '_').replace(/=/g, '');
};

/**
 * 授权码解密+防篡改校验（支持新旧两种加密方式）
 * @param licenseCode 授权码
 * @returns 解密后的授权数据
 */
export const decryptLicense = (licenseCode: string): string => {
  // 还原Base64特殊字符
  const normalizedCode = licenseCode.replace(/-/g, '+').replace(/_/g, '/');
  // 补全Base64 padding
  const padLength = 4 - (normalizedCode.length % 4);
  const paddedCode = normalizedCode + '='.repeat(padLength < 4 ? padLength : 0);

  // 尝试新版本解密（哈希派生密钥）
  try {
    const key = CryptoJS.enc.Utf8.parse(LICENSE_KEY_32);
    const iv = CryptoJS.enc.Utf8.parse(LICENSE_IV_16);
    const decrypted = CryptoJS.AES.decrypt(paddedCode, key, {
      iv: iv,
      mode: CryptoJS.mode.CBC,
      padding: CryptoJS.pad.Pkcs7
    });
    const decryptedStr = decrypted.toString(CryptoJS.enc.Utf8);
    
    if (decryptedStr) {
      const { data, signature } = JSON.parse(decryptedStr);
      const validSignature = CryptoJS.MD5(data + LICENSE_SECRET_KEY).toString();
      if (signature === validSignature) {
        console.log('授权码验证成功（新版本加密）');
        return data;
      }
    }
  } catch (e) {
    console.log('新版本解密失败，尝试旧版本...');
  }

  // 尝试旧版本解密（直接使用原始字符串截断）
  try {
    const keyOld = CryptoJS.enc.Utf8.parse(LICENSE_SECRET_KEY.slice(0, 32));
    const ivOld = CryptoJS.enc.Utf8.parse(LICENSE_SECRET_IV.slice(0, 16));
    const decrypted = CryptoJS.AES.decrypt(paddedCode, keyOld, {
      iv: ivOld,
      mode: CryptoJS.mode.CBC,
      padding: CryptoJS.pad.Pkcs7
    });
    const decryptedStr = decrypted.toString(CryptoJS.enc.Utf8);
    
    if (decryptedStr) {
      const { data, signature } = JSON.parse(decryptedStr);
      const validSignature = CryptoJS.MD5(data + LICENSE_SECRET_KEY).toString();
      if (signature === validSignature) {
        console.log('授权码验证成功（旧版本加密）');
        return data;
      }
    }
  } catch (e) {
    console.log('旧版本解密也失败');
  }

  console.error('授权码解密失败');
  throw new Error('授权码无效，非官方生成');
};

/**
 * ==================== 不可逆哈希工具 ====================
 */

/**
 * SHA256哈希（不可逆，用于设备指纹）
 * @param data 原始数据
 * @returns 哈希字符串
 */
export const sha256Hash = async (data: string): Promise<string> => {
  const encoder = new TextEncoder();
  const buffer = encoder.encode(data);
  const hashBuffer = await crypto.subtle.digest('SHA-256', buffer);
  const hashArray = Array.from(new Uint8Array(hashBuffer));
  return hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
};

/**
 * MD5哈希（快速校验用）
 * @param data 原始数据
 * @returns MD5字符串
 */
export const md5Hash = (data: string): string => {
  return CryptoJS.MD5(data).toString();
};

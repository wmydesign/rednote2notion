/**
 * 浏览器适配核心模块 V3.1.1
 * 支持 Chrome 和 Edge 双浏览器深度适配
 * 动态检测浏览器类型，生成匹配的请求指纹
 * 新增：随机化指纹因子，防止被识别
 */

// ==================== 类型定义 ====================
export type BrowserType = 'chrome' | 'edge' | 'firefox' | 'safari' | 'unknown';

export interface BrowserInfo {
  type: BrowserType;
  name: string;
  version: string;
  brandColor: string;
  storeName: string;
  storeUrl: string;
  userAgent: string;
}

export interface BrowserFingerprint {
  secChUa: string;
  secChUaMobile: string;
  secChUaPlatform: string;
  userAgent: string;
}

// ==================== 浏览器配置 ====================
const BROWSER_CONFIGS: Record<BrowserType, Omit<BrowserInfo, 'version' | 'userAgent'>> = {
  chrome: {
    type: 'chrome',
    name: 'Google Chrome',
    brandColor: '#FF2442',
    storeName: 'Chrome Web Store',
    storeUrl: 'https://chrome.google.com/webstore/detail/',
  },
  edge: {
    type: 'edge',
    name: 'Microsoft Edge',
    brandColor: '#0078D4',
    storeName: 'Edge Add-ons',
    storeUrl: 'https://microsoftedge.microsoft.com/addons/',
  },
  firefox: {
    type: 'firefox',
    name: 'Mozilla Firefox',
    brandColor: '#FF7139',
    storeName: 'Firefox Add-ons',
    storeUrl: 'https://addons.mozilla.org/',
  },
  safari: {
    type: 'safari',
    name: 'Apple Safari',
    brandColor: '#006CFF',
    storeName: 'App Store',
    storeUrl: 'https://apps.apple.com/',
  },
  unknown: {
    type: 'unknown',
    name: 'Unknown Browser',
    brandColor: '#666666',
    storeName: 'Unknown Store',
    storeUrl: '',
  },
};

// ==================== 随机化指纹因子 ====================

/**
 * 生成随机版本变体
 * 在真实版本基础上添加微小随机偏移
 */
const generateVersionVariant = (baseVersion: string, variance: number = 5): string => {
  const base = parseInt(baseVersion, 10);
  if (isNaN(base)) return baseVersion;
  
  // 生成-1到+1的随机偏移
  const offset = Math.floor(Math.random() * (variance * 2 + 1)) - variance;
  return String(Math.max(base + offset, 100));
};

/**
 * 生成随机品牌列表
 * 从常见品牌中随机选择组合
 */
const generateBrandList = (browserType: BrowserType, version: string): string[] => {
  const baseVersion = version;
  const brands: string[] = [];
  
  switch (browserType) {
    case 'chrome':
      brands.push(`"Chromium";v="${baseVersion}"`);
      brands.push(`"Google Chrome";v="${baseVersion}"`);
      // 随机添加其他品牌
      if (Math.random() > 0.3) {
        brands.push(`"Not-A.Brand";v="99"`);
      }
      if (Math.random() > 0.7) {
        brands.push(`"Chromium";v="${generateVersionVariant(baseVersion, 2)}"`);
      }
      break;
    case 'edge':
      brands.push(`"Chromium";v="${baseVersion}"`);
      brands.push(`"Microsoft Edge";v="${baseVersion}"`);
      if (Math.random() > 0.5) {
        brands.push(`"Not-A.Brand";v="24"`);
      }
      break;
    case 'firefox':
      brands.push(`"Firefox";v="${baseVersion}"`);
      break;
    case 'safari':
      brands.push(`"Safari";v="${baseVersion}"`);
      if (Math.random() > 0.6) {
        brands.push(`"Version";v="${baseVersion}"`);
      }
      break;
    default:
      brands.push(`"Chromium";v="${baseVersion}"`);
      brands.push(`"Google Chrome";v="${baseVersion}"`);
  }
  
  return brands;
};

/**
 * 随机化 sec-ch-ua-full-version-list
 */
const generateFullVersionList = (browserType: BrowserType, version: string): string => {
  const brands = generateBrandList(browserType, version);
  return brands.join(', ');
};

/**
 * 生成随机平台信息
 */
const generatePlatformVariant = (): string => {
  const platforms = [
    '"Windows"',
    '"macOS"',
    '"Linux"',
  ];
  return platforms[Math.floor(Math.random() * platforms.length)];
};

// ==================== 核心函数 ====================

/**
 * 检测当前浏览器类型
 */
export const detectBrowserType = (): BrowserType => {
  if (typeof navigator === 'undefined') {
    return 'unknown';
  }

  const ua = navigator.userAgent;

  // Edge 检测（必须在 Chrome 之前）
  if (ua.includes('Edg/')) {
    return 'edge';
  }

  // Chrome 检测
  if (ua.includes('Chrome/') && !ua.includes('Edg/')) {
    return 'chrome';
  }

  // Firefox 检测
  if (ua.includes('Firefox/')) {
    return 'firefox';
  }

  // Safari 检测
  if (ua.includes('Safari/') && !ua.includes('Chrome/')) {
    return 'safari';
  }

  return 'unknown';
};

/**
 * 从 User-Agent 提取浏览器版本
 */
export const extractBrowserVersion = (browserType: BrowserType): string => {
  const ua = navigator.userAgent;
  let match: RegExpMatchArray | null = null;

  switch (browserType) {
    case 'chrome':
      match = ua.match(/Chrome\/(\d+)/);
      break;
    case 'edge':
      match = ua.match(/Edg\/(\d+)/);
      break;
    case 'firefox':
      match = ua.match(/Firefox\/(\d+)/);
      break;
    case 'safari':
      match = ua.match(/Version\/(\d+)/);
      break;
    default:
      return '124';
  }

  return match ? match[1] : '124';
};

/**
 * 获取当前浏览器完整信息
 */
export const getBrowserInfo = (): BrowserInfo => {
  const type = detectBrowserType();
  const version = extractBrowserVersion(type);
  const config = BROWSER_CONFIGS[type];

  return {
    ...config,
    version,
    userAgent: navigator.userAgent,
  };
};

/**
 * 生成浏览器匹配的 sec-ch-ua 请求头（带随机化）
 */
export const generateSecChUa = (browserType: BrowserType, version: string): string => {
  const brands = generateBrandList(browserType, version);
  return brands.join(', ');
};

/**
 * 生成 sec-ch-ua-full-version-list（带随机化）
 */
export const generateSecChUaFullVersionList = (browserType: BrowserType, version: string): string => {
  return generateFullVersionList(browserType, version);
};

/**
 * 生成 sec-ch-ua-mobile
 */
export const generateSecChUaMobile = (): string => {
  // 根据实际设备类型随机化
  if (typeof navigator !== 'undefined' && navigator.userAgent) {
    const ua = navigator.userAgent;
    if (ua.includes('Mobile') || ua.includes('Android')) {
      return Math.random() > 0.1 ? '?0' : '?1'; // 90%概率返回?0
    }
  }
  return '?0';
};

/**
 * 生成完整的浏览器指纹（每次调用生成不同的指纹）
 */
export const generateBrowserFingerprint = (): BrowserFingerprint => {
  const browserType = detectBrowserType();
  const version = extractBrowserVersion(browserType);

  return {
    secChUa: generateSecChUa(browserType, version),
    secChUaMobile: generateSecChUaMobile(),
    secChUaPlatform: detectPlatform(),
    userAgent: navigator.userAgent,
  };
};

/**
 * 生成随机化的浏览器特定请求头
 */
export const getBrowserSpecificHeaders = (): Record<string, string> => {
  const browserType = detectBrowserType();
  const version = extractBrowserVersion(browserType);

  const headers: Record<string, string> = {
    'sec-ch-ua': generateSecChUa(browserType, version),
    'sec-ch-ua-mobile': generateSecChUaMobile(),
    'sec-ch-ua-platform': detectPlatform(),
  };

  // 添加 full-version-list（某些API需要）
  if (browserType === 'chrome' || browserType === 'edge') {
    headers['sec-ch-ua-full-version-list'] = generateFullVersionList(browserType, version);
  }

  // 添加 sec-ch-ua-platform-version
  headers['sec-ch-ua-platform-version'] = getPlatformVersion();

  return headers;
};

/**
 * 检测操作系统平台
 */
const detectPlatform = (): string => {
  const platform = navigator.platform.toLowerCase();

  if (platform.includes('win')) {
    return '"Windows"';
  }
  if (platform.includes('mac')) {
    return '"macOS"';
  }
  if (platform.includes('linux')) {
    return '"Linux"';
  }

  return '"Windows"'; // 默认值
};

/**
 * 获取平台版本
 */
const getPlatformVersion = (): string => {
  const platform = navigator.platform.toLowerCase();

  if (platform.includes('win')) {
    // Windows版本
    const match = navigator.userAgent.match(/Windows NT ([\d.]+)/);
    if (match) {
      return `"${match[1]}"`;
    }
    return '"10.0"';
  }
  if (platform.includes('mac')) {
    // macOS版本
    const match = navigator.userAgent.match(/Mac OS X ([\d_]+)/);
    if (match) {
      return `"${match[1].replace(/_/g, '.')}"`;
    }
    return '"14.0"';
  }
  if (platform.includes('linux')) {
    return '"15.0.0"';
  }

  return '"10.0"';
};

/**
 * 生成随机的 Accept-Language
 */
export const generateAcceptLanguage = (): string => {
  const languages = [
    'zh-CN,zh;q=0.9,en;q=0.8',
    'zh-CN,zh;q=0.9,en-GB;q=0.8,en;q=0.7',
    'zh-CN,zh;q=0.9,en-US;q=0.8,en;q=0.7',
    'zh,en;q=0.9',
    'en-US,en;q=0.9,zh-CN;q=0.8',
  ];
  return languages[Math.floor(Math.random() * languages.length)];
};

/**
 * 生成随机的 Accept-Encoding
 */
export const generateAcceptEncoding = (): string => {
  return 'gzip, deflate, br';
};

/**
 * 获取完整请求配置（用于fetch请求）
 */
export const getRandomizedRequestHeaders = (options?: {
  includeUserAgent?: boolean;
  includeAcceptLanguage?: boolean;
}): Record<string, string> => {
  const headers: Record<string, string> = {
    ...getBrowserSpecificHeaders(),
  };

  if (options?.includeAcceptLanguage ?? true) {
    headers['Accept-Language'] = generateAcceptLanguage();
  }

  headers['Accept-Encoding'] = generateAcceptEncoding();

  // 可选：使用随机的User-Agent变体
  if (options?.includeUserAgent ?? false) {
    // 添加一个轻微变体的User-Agent
    const ua = navigator.userAgent;
    if (Math.random() > 0.5 && browserType !== 'firefox') {
      // 50%概率使用略带不同的User-Agent
      headers['User-Agent'] = ua.replace(
        /Chrome\/[\d.]+/,
        `Chrome/${parseInt(extractBrowserVersion('chrome')) + Math.floor(Math.random() * 3)}`
      );
    }
  }

  return headers;
};

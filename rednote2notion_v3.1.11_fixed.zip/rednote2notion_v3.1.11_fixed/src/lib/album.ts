/**
 * 小红书专辑 API 模块（集成日志版）
 * 提供专辑列表、专辑内笔记、笔记详情、评论获取功能
 */

import { RednoteAlbum } from './types';
import { logger } from './logger';

const MODULE = 'AlbumAPI';

/**
 * 带重试和限流的fetch封装
 */
const fetchWithRetry = async (
  url: string,
  options: RequestInit,
  maxRetries: number = 3,
  baseDelay: number = 1000
): Promise<Response> => {
  let lastError: Error | null = null;
  
  for (let attempt = 0; attempt < maxRetries; attempt++) {
    try {
      // 添加随机延迟防止限流
      if (attempt > 0) {
        const delay = baseDelay * Math.pow(2, attempt - 1) + Math.random() * 500;
        await new Promise(resolve => setTimeout(resolve, delay));
      }
      
      const response = await fetch(url, options);
      
      // 检查是否被限流
      if (response.status === 429) {
        const retryAfter = response.headers.get('Retry-After');
        const waitTime = retryAfter ? parseInt(retryAfter) * 1000 : baseDelay * 2;
        logger.warn(MODULE, `请求被限流，等待 ${waitTime}ms 后重试`, { url, attempt: attempt + 1 });
        await new Promise(resolve => setTimeout(resolve, waitTime));
        continue;
      }
      
      if (!response.ok && attempt < maxRetries - 1) {
        throw new Error(`HTTP ${response.status}`);
      }
      
      return response;
    } catch (error) {
      lastError = error as Error;
      logger.warn(MODULE, `请求失败，第 ${attempt + 1} 次重试`, { url, error: lastError.message });
    }
  }
  
  throw lastError || new Error('请求失败');
};

/**
 * 获取用户所有收藏专辑列表
 * @returns 专辑列表
 */
export const getUserAlbumList = async (): Promise<RednoteAlbum[]> => {
  try {
    logger.debug(MODULE, '获取用户收藏专辑列表');
    
    const response = await fetchWithRetry(
      'https://edith.xiaohongshu.com/api/sns/web/v1/album/list',
      {
        method: 'POST',
        credentials: 'include',
        headers: {
          'Content-Type': 'application/json',
          'Referer': 'https://www.xiaohongshu.com/',
          'Origin': 'https://www.xiaohongshu.com'
        },
        body: JSON.stringify({
          page_size: 100,
          cursor: ''
        })
      },
      3,
      1000
    );

    const data = await response.json();
    if (data.code !== 0) {
      throw new Error(`API返回错误: ${data.msg}`);
    }

    const albums = data.data?.albums || [];
    logger.info(MODULE, `获取到 ${albums.length} 个专辑`);
    
    return albums.map((album: any) => ({
      albumId: album.id,
      albumName: album.name,
      coverUrl: album.cover?.url || '',
      noteCount: album.note_count || 0,
      updateTime: album.update_time || 0,
      isDefault: album.is_default || false
    }));

  } catch (error) {
    logger.error(MODULE, '获取收藏专辑列表失败', error);
    return [];
  }
};

/**
 * 获取指定专辑内的笔记列表
 */
export const getAlbumNoteList = async (
  albumId: string,
  cursor: string = '',
  pageSize: number = 20
): Promise<{ notes: any[]; nextCursor: string; hasMore: boolean }> => {
  try {
    logger.debug(MODULE, '获取专辑笔记列表', { albumId, cursor });
    
    const response = await fetchWithRetry(
      'https://edith.xiaohongshu.com/api/sns/web/v1/album/note/list',
      {
        method: 'POST',
        credentials: 'include',
        headers: {
          'Content-Type': 'application/json',
          'Referer': 'https://www.xiaohongshu.com/',
          'Origin': 'https://www.xiaohongshu.com'
        },
        body: JSON.stringify({
          album_id: albumId,
          cursor,
          page_size: pageSize
        })
      },
      3,
      1000
    );

    const data = await response.json();
    if (data.code !== 0) {
      throw new Error(`API返回错误: ${data.msg}`);
    }

    const notes = data.data?.notes || [];
    logger.debug(MODULE, `获取到 ${notes.length} 条笔记`, { albumId, hasMore: data.data?.has_more });

    return {
      notes,
      nextCursor: data.data?.cursor || '',
      hasMore: data.data?.has_more || false
    };

  } catch (error) {
    logger.error(MODULE, '获取专辑笔记列表失败', { albumId, error });
    return {
      notes: [],
      nextCursor: '',
      hasMore: false
    };
  }
};

/**
 * 获取笔记详情
 */
export const getNoteDetail = async (noteId: string): Promise<any> => {
  try {
    logger.debug(MODULE, '获取笔记详情', { noteId });
    
    const response = await fetchWithRetry(
      `https://edith.xiaohongshu.com/api/sns/web/v1/feed/note_detail?note_id=${noteId}`,
      {
        method: 'GET',
        credentials: 'include',
        headers: {
          'Content-Type': 'application/json',
          'Referer': 'https://www.xiaohongshu.com/',
          'Origin': 'https://www.xiaohongshu.com'
        }
      },
      3,
      1000
    );

    const data = await response.json();
    if (data.code !== 0) {
      throw new Error(`API返回错误: ${data.msg}`);
    }

    logger.debug(MODULE, '笔记详情获取成功', { noteId });
    return data.data;

  } catch (error) {
    logger.error(MODULE, '获取笔记详情失败', { noteId, error });
    return null;
  }
};

/**
 * 获取笔记评论列表
 */
export const getNoteCommentList = async (
  noteId: string,
  cursor: string = '',
  pageSize: number = 20
): Promise<{ comments: any[]; nextCursor: string; hasMore: boolean }> => {
  try {
    logger.debug(MODULE, '获取笔记评论列表', { noteId, cursor });
    
    const response = await fetchWithRetry(
      'https://edith.xiaohongshu.com/api/sns/web/v2/comment/page',
      {
        method: 'POST',
        credentials: 'include',
        headers: {
          'Content-Type': 'application/json',
          'Referer': 'https://www.xiaohongshu.com/',
          'Origin': 'https://www.xiaohongshu.com'
        },
        body: JSON.stringify({
          note_id: noteId,
          cursor,
          page_size: pageSize,
          top_comment_id: '',
          image_formats: 'jpg,webp,avif'
        })
      },
      3,
      1000
    );

    const data = await response.json();
    if (data.code !== 0) {
      throw new Error(`API返回错误: ${data.msg}`);
    }

    const comments = data.data?.comments || [];
    logger.debug(MODULE, `获取到 ${comments.length} 条评论`, { noteId, hasMore: data.data?.has_more });

    return {
      comments,
      nextCursor: data.data?.cursor || '',
      hasMore: data.data?.has_more || false
    };

  } catch (error) {
    logger.error(MODULE, '获取评论列表失败', { noteId, error });
    return {
      comments: [],
      nextCursor: '',
      hasMore: false
    };
  }
};
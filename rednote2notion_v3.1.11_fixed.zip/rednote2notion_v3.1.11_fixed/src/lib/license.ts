import { encryptLicense, decryptLicense, sha256Hash, md5Hash } from './crypto';
import { v4 as uuidv4 } from 'uuid';

// ==================== 类型定义 ====================
export enum LicenseType {
  FREE = 'free',
  TRIAL = 'trial',
  PERMANENT = 'permanent'
}

export interface LicenseInfo {
  licenseCode: string;
  licenseType: LicenseType;
  activateTime: number;
  expireTime: number;
  deviceFingerprint: string;
  maxSyncCount: number;
  usedSyncCount: number;
  isValid: boolean;
  isActivated: boolean;
  errorMsg?: string;
}

export interface LicenseGenerateConfig {
  licenseType: LicenseType;
  validDays?: number;
  deviceFingerprint?: string;
  batchCount?: number;
}

export interface LicenseParseResult {
  licenseId: string;
  licenseType: LicenseType;
  generateTime: number;
  expireTime: number;
  deviceFingerprint: string;
  isActivated: boolean;
  isValid: boolean;
  errorMsg?: string;
}

// ==================== 常量配置 ====================
export const FREE_VERSION_MAX_SYNC = 5;
export const TRIAL_DEFAULT_DAYS = 7;
export const PERMANENT_VALID_YEARS = 99;
export const UNACTIVATED_DEVICE_FLAG = 'UNACTIVATED_CARD';
export const LICENSE_STORAGE_KEY = 'rednote_license_code';
export const LICENSE_USED_COUNT_KEY = 'license_used_sync_count';
export const LICENSE_ACTIVATED_KEY = 'rednote_license_activated';

// ==================== 工具函数 ====================
// 设备指纹函数已移除，改用固定指纹

/**
 * 固定设备指纹（统一授权系统）
 * 所有授权码和激活验证都使用固定指纹，无需绑定设备
 * @returns 固定指纹值
 */
export const generateDeviceFingerprint = async (): Promise<string> => {
  // 返回固定指纹，不再动态生成
  return 'FIXED_FINGERPRINT_2024';
};

/**
 * ==================== 卖家核心：生成授权码/卡密 ====================
 * 支持单条/批量生成，使用固定指纹
 */
export const generateLicenseCode = async (config: LicenseGenerateConfig): Promise<string[]> => {
  const { licenseType, validDays, batchCount = 1 } = config;
  const generatedCodes: string[] = [];

  for (let i = 0; i < batchCount; i++) {
    const licenseId = uuidv4().replace(/-/g, '');
    const generateTime = Date.now();
    let expireTime = 0;

    if (licenseType === LicenseType.TRIAL) {
      const days = validDays || TRIAL_DEFAULT_DAYS;
      expireTime = generateTime + days * 24 * 60 * 60 * 1000;
    } else if (licenseType === LicenseType.PERMANENT) {
      expireTime = generateTime + PERMANENT_VALID_YEARS * 365 * 24 * 60 * 60 * 1000;
    } else {
      // 免费版
      expireTime = generateTime + 99 * 365 * 24 * 60 * 60 * 1000;
    }

    // 计算同步上限
    let maxSyncCount = -1; // -1 表示无限制
    if (licenseType === LicenseType.FREE) {
      maxSyncCount = FREE_VERSION_MAX_SYNC;
    }

    const rawLicense = {
      licenseId,
      licenseType,
      generateTime,
      expireTime,
      deviceFingerprint: 'FIXED_FINGERPRINT_2024',  // 始终使用固定指纹
      validDays: licenseType === LicenseType.TRIAL ? validDays || TRIAL_DEFAULT_DAYS : 0,
      maxSyncCount,
      isPreGenerated: true
    };

    const licenseStr = JSON.stringify(rawLicense);
    const licenseCode = encryptLicense(licenseStr);
    generatedCodes.push(licenseCode);
  }

  return generatedCodes;
};

/**
 * 解析授权码信息
 */
export const parseLicenseCode = async (licenseCode: string): Promise<LicenseParseResult> => {
  const defaultResult: LicenseParseResult = {
    licenseId: '',
    licenseType: LicenseType.FREE,
    generateTime: 0,
    expireTime: 0,
    deviceFingerprint: '',
    isActivated: false,
    isValid: false,
    errorMsg: '授权码格式错误'
  };

  if (!licenseCode || licenseCode.trim() === '') {
    return { ...defaultResult, errorMsg: '授权码不能为空' };
  }

  try {
    const decryptedStr = decryptLicense(licenseCode);
    const licenseData = JSON.parse(decryptedStr);

    if (!licenseData.licenseId || !licenseData.licenseType) {
      return { ...defaultResult, errorMsg: '授权码无效，非官方生成' };
    }

    const isActivated = licenseData.deviceFingerprint === 'FIXED_FINGERPRINT_2024';
    const now = Date.now();
    let isValid = true;
    let errorMsg = '';

    if (licenseData.expireTime < now) {
      isValid = false;
      errorMsg = '授权码已过期';
    }

    return {
      licenseId: licenseData.licenseId,
      licenseType: licenseData.licenseType,
      generateTime: licenseData.generateTime,
      expireTime: licenseData.expireTime,
      deviceFingerprint: licenseData.deviceFingerprint,
      isActivated,
      isValid,
      errorMsg
    };
  } catch (error) {
    return { ...defaultResult, errorMsg: '授权码解析失败' };
  }
};

/**
 * 激活授权码（无需绑定设备，使用固定指纹）
 */
export const activateLicenseCode = async (licenseCode: string): Promise<LicenseInfo> => {
  const parseResult = await parseLicenseCode(licenseCode);
  
  if (!parseResult.isValid) {
    return {
      licenseCode,
      licenseType: LicenseType.FREE,
      activateTime: 0,
      expireTime: 0,
      deviceFingerprint: '',
      maxSyncCount: 0,
      usedSyncCount: 0,
      isValid: false,
      isActivated: false,
      errorMsg: parseResult.errorMsg || '授权码无效'
    };
  }

  // 使用固定指纹，无需验证设备绑定
  const currentFingerprint = await generateDeviceFingerprint();

  const activateTime = Date.now();
  let expireTime = parseResult.expireTime;
  let maxSyncCount = 0;

  if (parseResult.licenseType === LicenseType.TRIAL) {
    maxSyncCount = 100;
    if (parseResult.deviceFingerprint === UNACTIVATED_DEVICE_FLAG) {
      expireTime = activateTime + (parseResult.validDays || TRIAL_DEFAULT_DAYS) * 24 * 60 * 60 * 1000;
    }
  } else if (parseResult.licenseType === LicenseType.PERMANENT) {
    maxSyncCount = -1; // -1 表示无限制（避免 JSON 序列化问题）
  }

  const licenseInfo: LicenseInfo = {
    licenseCode,
    licenseType: parseResult.licenseType,
    activateTime,
    expireTime,
    deviceFingerprint: currentFingerprint,
    maxSyncCount,
    usedSyncCount: 0,
    isValid: true,
    isActivated: true
  };

  await chrome.storage.local.set({ [LICENSE_STORAGE_KEY]: licenseCode });
  await chrome.storage.local.set({ [LICENSE_ACTIVATED_KEY]: true });

  return licenseInfo;
};

/**
 * 获取当前授权信息
 */
export const getCurrentLicense = async (): Promise<LicenseInfo> => {
  try {
    const result = await chrome.storage.local.get([LICENSE_STORAGE_KEY, LICENSE_USED_COUNT_KEY, LICENSE_ACTIVATED_KEY]);
    const licenseCode = result[LICENSE_STORAGE_KEY];
    
    if (!licenseCode) {
      return {
        licenseCode: '',
        licenseType: LicenseType.FREE,
        activateTime: 0,
        expireTime: 0,
        deviceFingerprint: '',
        maxSyncCount: FREE_VERSION_MAX_SYNC,
        usedSyncCount: 0,
        isValid: true,
        isActivated: false
      };
    }

    const parseResult = await parseLicenseCode(licenseCode);
    const usedSyncCount = result[LICENSE_USED_COUNT_KEY] || 0;
    const isActivated = result[LICENSE_ACTIVATED_KEY] || parseResult.isActivated;

    if (!parseResult.isValid) {
      return {
        licenseCode,
        licenseType: parseResult.licenseType,
        activateTime: 0,
        expireTime: parseResult.expireTime,
        deviceFingerprint: '',
        maxSyncCount: 0,
        usedSyncCount,
        isValid: false,
        isActivated: false,
        errorMsg: parseResult.errorMsg
      };
    }

    let maxSyncCount = 0;
    if (parseResult.licenseType === LicenseType.TRIAL) {
      maxSyncCount = 100;
    } else if (parseResult.licenseType === LicenseType.PERMANENT) {
      maxSyncCount = -1; // -1 表示无限制（避免 JSON 序列化问题）
    } else {
      maxSyncCount = FREE_VERSION_MAX_SYNC;
    }

    return {
      licenseCode,
      licenseType: parseResult.licenseType,
      activateTime: parseResult.generateTime,
      expireTime: parseResult.expireTime,
      deviceFingerprint: parseResult.deviceFingerprint,
      maxSyncCount,
      usedSyncCount,
      isValid: true,
      isActivated
    };
  } catch (error) {
    return {
      licenseCode: '',
      licenseType: LicenseType.FREE,
      activateTime: 0,
      expireTime: 0,
      deviceFingerprint: '',
      maxSyncCount: FREE_VERSION_MAX_SYNC,
      usedSyncCount: 0,
      isValid: true,
      isActivated: false
    };
  }
};

/**
 * 保存授权码
 */
export const saveLicenseCode = async (licenseCode: string): Promise<void> => {
  await chrome.storage.local.set({ [LICENSE_STORAGE_KEY]: licenseCode });
};

/**
 * 更新同步计数
 */
export const updateSyncCount = async (count: number): Promise<void> => {
  const result = await chrome.storage.local.get(LICENSE_USED_COUNT_KEY);
  const currentCount = result[LICENSE_USED_COUNT_KEY] || 0;
  await chrome.storage.local.set({ [LICENSE_USED_COUNT_KEY]: currentCount + count });
};

/**
 * 重置同步计数
 */
export const resetSyncCount = async (): Promise<void> => {
  await chrome.storage.local.set({ [LICENSE_USED_COUNT_KEY]: 0 });
};

/**
 * 检查同步权限
 */
export const checkSyncPermission = async (): Promise<{ hasPermission: boolean; errorMsg?: string }> => {
  const licenseInfo = await getCurrentLicense();
  
  if (!licenseInfo.isValid) {
    return { hasPermission: false, errorMsg: licenseInfo.errorMsg || '授权无效' };
  }
  
  if (!licenseInfo.isActivated) {
    return { hasPermission: false, errorMsg: '请先激活授权码' };
  }
  
  if (licenseInfo.expireTime < Date.now()) {
    return { hasPermission: false, errorMsg: '授权已过期' };
  }
  
  // -1 表示无限制，跳过上限检查
  if (licenseInfo.maxSyncCount !== -1 && licenseInfo.usedSyncCount >= licenseInfo.maxSyncCount) {
    return { hasPermission: false, errorMsg: '已达到同步上限' };
  }
  
  return { hasPermission: true };
};
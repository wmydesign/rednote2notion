/**
 * 断点续传快照模块（集成日志版）
 * 实现同步进度快照保存、恢复、失败重试机制
 * 支持：每5条自动保存、中断后5分钟内可恢复、失败记录单独重试
 * 集成统一日志管理器，记录快照生命周期
 */

import { detectBrowserType, BrowserType } from './browser-polyfill';
import { logger } from './logger';

const MODULE = 'SyncSnapshot';

// ==================== 类型定义 ====================
export interface SyncSnapshot {
  id: string;                    // 快照唯一ID
  userId: string;                // 当前登录用户ID
  platform: string;              // 同步平台 (post/bookmark/like)
  startTime: number;             // 同步开始时间戳
  lastUpdateTime: number;        // 最后更新时间
  total: number;                 // 笔记总数
  processed: number;             // 已处理数量
  successful: string[];          // 成功的笔记ID列表
  failed: FailedNote[];          // 失败的笔记列表
  cursor: string;                // 小红书分页游标
  status: SyncStatus;            // 同步状态
  browserType: BrowserType;      // 浏览器类型
  config: SyncConfig;            // 同步配置
}

export interface FailedNote {
  noteId: string;
  noteTitle: string;
  error: string;
  retryCount: number;
  lastRetryTime: number;
}

export interface SyncConfig {
  notionApiKey: string;
  notionDatabaseId: string;
  aiProvider?: string;
  aiModel?: string;
  aiApiKey?: string;
  enableAIClassify?: boolean;
}

export type SyncStatus = 'running' | 'paused' | 'completed' | 'failed' | 'recovering';

// ==================== 常量配置 ====================
const SNAPSHOT_STORAGE_KEY = 'rednote_sync_snapshot';
const SNAPSHOT_EXPIRE_TIME = 5 * 60 * 1000; // 5分钟过期
const SNAPSHOT_SAVE_INTERVAL = 5; // 每5条保存一次
const MAX_RETRY_COUNT = 3; // 最大重试次数

// ==================== 核心函数 ====================

/**
 * 生成唯一ID
 */
const generateId = (): string => {
  return `snapshot_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
};

/**
 * 创建新的同步快照
 */
export const createSyncSnapshot = (
  userId: string,
  platform: string,
  total: number,
  config: SyncConfig
): SyncSnapshot => {
  const browserType = detectBrowserType();

  const snapshot: SyncSnapshot = {
    id: generateId(),
    userId,
    platform,
    startTime: Date.now(),
    lastUpdateTime: Date.now(),
    total,
    processed: 0,
    successful: [],
    failed: [],
    cursor: '',
    status: 'running',
    browserType,
    config,
  };

  logger.info(MODULE, `创建同步快照`, { 
    snapshotId: snapshot.id, 
    platform, 
    total, 
    browserType 
  });

  return snapshot;
};

/**
 * 保存快照到本地存储
 */
export const saveSyncSnapshot = async (snapshot: SyncSnapshot): Promise<void> => {
  try {
    snapshot.lastUpdateTime = Date.now();
    await chrome.storage.local.set({
      [SNAPSHOT_STORAGE_KEY]: snapshot,
    });
    logger.debug(MODULE, `快照已保存`, { 
      snapshotId: snapshot.id, 
      processed: snapshot.processed, 
      total: snapshot.total,
      failed: snapshot.failed.length 
    });
  } catch (error) {
    logger.error(MODULE, '保存快照失败', error);
  }
};

/**
 * 获取当前快照
 */
export const getCurrentSnapshot = async (): Promise<SyncSnapshot | null> => {
  try {
    const result = await chrome.storage.local.get(SNAPSHOT_STORAGE_KEY);
    const snapshot = result[SNAPSHOT_STORAGE_KEY] || null;
    if (snapshot) {
      logger.debug(MODULE, '读取当前快照', { snapshotId: snapshot.id, status: snapshot.status });
    }
    return snapshot;
  } catch (error) {
    logger.error(MODULE, '获取快照失败', error);
    return null;
  }
};

/**
 * 检查是否有可恢复的同步任务
 */
export const checkRecoverableSync = async (userId: string): Promise<SyncSnapshot | null> => {
  const snapshot = await getCurrentSnapshot();

  if (!snapshot) {
    return null;
  }

  // 检查是否过期
  const now = Date.now();
  if (now - snapshot.lastUpdateTime > SNAPSHOT_EXPIRE_TIME) {
    logger.info(MODULE, '快照已过期，清除', { snapshotId: snapshot.id, age: Math.round((now - snapshot.lastUpdateTime) / 1000) + 's' });
    await clearSyncSnapshot();
    return null;
  }

  // 检查用户是否匹配
  if (snapshot.userId !== userId) {
    logger.info(MODULE, '用户不匹配，清除快照', { snapshotUserId: snapshot.userId, currentUserId: userId });
    await clearSyncSnapshot();
    return null;
  }

  // 检查状态是否可恢复
  if (snapshot.status !== 'running' && snapshot.status !== 'paused') {
    logger.debug(MODULE, '快照状态不可恢复', { snapshotId: snapshot.id, status: snapshot.status });
    return null;
  }

  logger.info(MODULE, '发现可恢复的快照', { 
    snapshotId: snapshot.id, 
    platform: snapshot.platform,
    processed: snapshot.processed,
    total: snapshot.total,
    failed: snapshot.failed.length
  });

  return snapshot;
};

/**
 * 更新快照进度
 */
export const updateSnapshotProgress = async (
  snapshot: SyncSnapshot,
  processed: number,
  noteId?: string,
  cursor?: string
): Promise<void> => {
  snapshot.processed = processed;
  if (noteId) {
    snapshot.successful.push(noteId);
  }
  if (cursor) {
    snapshot.cursor = cursor;
  }

  // 每隔一定数量保存一次
  if (processed % SNAPSHOT_SAVE_INTERVAL === 0) {
    await saveSyncSnapshot(snapshot);
  }
};

/**
 * 记录失败笔记
 */
export const recordFailedNote = async (
  snapshot: SyncSnapshot,
  noteId: string,
  noteTitle: string,
  error: string
): Promise<void> => {
  const existingFail = snapshot.failed.find(f => f.noteId === noteId);

  if (existingFail) {
    existingFail.retryCount++;
    existingFail.lastRetryTime = Date.now();
    existingFail.error = error;
    logger.warn(MODULE, `笔记同步失败 (重试 ${existingFail.retryCount}/${MAX_RETRY_COUNT})`, { 
      noteId, 
      noteTitle, 
      error 
    });
  } else {
    snapshot.failed.push({
      noteId,
      noteTitle,
      error,
      retryCount: 0,
      lastRetryTime: Date.now(),
    });
    logger.warn(MODULE, '笔记同步失败', { noteId, noteTitle, error });
  }

  await saveSyncSnapshot(snapshot);
};

/**
 * 标记同步完成
 */
export const markSyncCompleted = async (snapshot: SyncSnapshot): Promise<void> => {
  snapshot.status = 'completed';
  snapshot.lastUpdateTime = Date.now();
  await saveSyncSnapshot(snapshot);

  logger.info(MODULE, '同步完成', { 
    snapshotId: snapshot.id, 
    platform: snapshot.platform,
    total: snapshot.total,
    successful: snapshot.successful.length,
    failed: snapshot.failed.length
  });

  // 完成后延迟清除快照
  setTimeout(async () => {
    await clearSyncSnapshot();
  }, 30000); // 30秒后清除
};

/**
 * 标记同步暂停
 */
export const markSyncPaused = async (snapshot: SyncSnapshot): Promise<void> => {
  snapshot.status = 'paused';
  snapshot.lastUpdateTime = Date.now();
  await saveSyncSnapshot(snapshot);
  logger.info(MODULE, '同步暂停', { snapshotId: snapshot.id, platform: snapshot.platform });
};

/**
 * 标记同步失败
 */
export const markSyncFailed = async (snapshot: SyncSnapshot, error: string): Promise<void> => {
  snapshot.status = 'failed';
  snapshot.lastUpdateTime = Date.now();
  await saveSyncSnapshot(snapshot);
  logger.error(MODULE, `同步失败: ${snapshot.platform}`, { snapshotId: snapshot.id, error });
};

/**
 * 清除快照
 */
export const clearSyncSnapshot = async (): Promise<void> => {
  try {
    await chrome.storage.local.remove(SNAPSHOT_STORAGE_KEY);
    logger.debug(MODULE, '快照已清除');
  } catch (error) {
    logger.error(MODULE, '清除快照失败', error);
  }
};

/**
 * 获取失败笔记列表
 */
export const getFailedNotes = async (): Promise<FailedNote[]> => {
  const snapshot = await getCurrentSnapshot();
  return snapshot?.failed || [];
};

/**
 * 重试单个失败笔记
 */
export const retryFailedNote = async (noteId: string): Promise<boolean> => {
  const snapshot = await getCurrentSnapshot();

  if (!snapshot) {
    return false;
  }

  const failedNote = snapshot.failed.find(f => f.noteId === noteId);

  if (!failedNote) {
    return false;
  }

  // 检查重试次数
  if (failedNote.retryCount >= MAX_RETRY_COUNT) {
    logger.warn(MODULE, `笔记已达最大重试次数，不再重试`, { noteId, retryCount: failedNote.retryCount });
    return false;
  }

  return true;
};

/**
 * 移除失败笔记（重试成功后）
 */
export const removeFailedNote = async (noteId: string): Promise<void> => {
  const snapshot = await getCurrentSnapshot();

  if (!snapshot) {
    return;
  }

  const beforeCount = snapshot.failed.length;
  snapshot.failed = snapshot.failed.filter(f => f.noteId !== noteId);
  snapshot.successful.push(noteId);
  
  if (beforeCount !== snapshot.failed.length) {
    logger.info(MODULE, '失败笔记已转为成功', { noteId, remainingFailed: snapshot.failed.length });
  }
  
  await saveSyncSnapshot(snapshot);
};

/**
 * 获取同步统计信息
 */
export const getSyncStats = async (): Promise<{
  total: number;
  processed: number;
  successful: number;
  failed: number;
  percentage: number;
} | null> => {
  const snapshot = await getCurrentSnapshot();

  if (!snapshot) {
    return null;
  }

  return {
    total: snapshot.total,
    processed: snapshot.processed,
    successful: snapshot.successful.length,
    failed: snapshot.failed.length,
    percentage: Math.round((snapshot.processed / snapshot.total) * 100),
  };
};

/**
 * 检查是否需要保存快照
 */
export const shouldSaveSnapshot = (processed: number): boolean => {
  return processed % SNAPSHOT_SAVE_INTERVAL === 0;
};

// ==================== 导出 ====================
export default {
  createSyncSnapshot,
  saveSyncSnapshot,
  getCurrentSnapshot,
  checkRecoverableSync,
  updateSnapshotProgress,
  recordFailedNote,
  markSyncCompleted,
  markSyncPaused,
  markSyncFailed,
  clearSyncSnapshot,
  getFailedNotes,
  retryFailedNote,
  removeFailedNote,
  getSyncStats,
  shouldSaveSnapshot,
  SNAPSHOT_SAVE_INTERVAL,
  MAX_RETRY_COUNT,
};
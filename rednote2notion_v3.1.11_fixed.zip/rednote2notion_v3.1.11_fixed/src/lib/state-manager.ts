/**
 * 统一状态管理器（修复版）
 * 修复内容：
 * 1. 移除解构导出，仅导出单例 stateManager，避免 this 丢失
 * 2. 修复 updateSyncStatus 合并逻辑，确保默认字段存在
 * 3. 移除无用的脏缓存与定时器，简化缓存实现
 * 4. 保存定时器 ID 并在 Service Worker 卸载时清理
 * 5. 移除重复的错误广播
 * 6. 增强类型安全
 */

import { platformConfig } from './types';

// ==================== 存储键枚举 ====================
export const StorageKeys = {
  CURRENT_USER: 'current_user',
  PER_ACCOUNT_STATE: 'rednote_per_account_state',
  SYNC_STATUS: 'sync_status',
  LAST_SYNC_TIME: 'last_sync_time',
  NEXT_CURSOR: 'next_cursor',
  PREV_CURSOR: 'prev_cursor',
  ALL_SYNC: 'all_sync',
  SYNC_SNAPSHOT: 'sync_snapshot',
  NOTION_CONFIG: 'notion_config',
  AI_CONFIG: 'ai_config',
  SYNC_CONFIG: 'sync_config',
  LICENSE_INFO: 'license_info',
} as const;

// ==================== 存储值类型 ====================
export interface StoredUser {
  userId: string;
  nickname: string;
  avatar?: string;
}

export interface SyncStatusData {
  isRunning: boolean;
  progress: number;
  total: number;
  processed: number;
  failed: number;
  currentStep: string;
  error?: string;
}

export interface SyncProgressEvent {
  type: 'progress' | 'complete' | 'error' | 'step';
  platform: string;
  progress?: number;
  total?: number;
  processed?: number;
  failed?: number;
  step?: string;
  error?: string;
  timestamp: number;
}

// ==================== 状态管理器类 ====================
class StateManager {
  private listeners: Map<string, Set<(data: any) => void>> = new Map();
  private cache: Map<string, { value: any; timestamp: number }> = new Map();
  private cacheTTL: number = 5000;
  private flushIntervalId: NodeJS.Timeout | null = null;

  constructor() {
    // 可选：启动定期缓存清理（非必须）
    // 在 Service Worker 环境中建议不启动长期间隔
    if (typeof chrome !== 'undefined' && chrome.runtime) {
      chrome.runtime.onSuspend.addListener(() => {
        this.destroy();
      });
    }
  }

  /**
   * 清理资源
   */
  destroy(): void {
    if (this.flushIntervalId) {
      clearInterval(this.flushIntervalId);
      this.flushIntervalId = null;
    }
  }

  // ==================== 基础 CRUD ====================

  async get<T>(key: string): Promise<T | undefined> {
    const cached = this.cache.get(key);
    if (cached && Date.now() - cached.timestamp < this.cacheTTL) {
      return cached.value as T;
    }

    const result = await chrome.storage.local.get(key);
    const value = result[key] as T | undefined;

    this.cache.set(key, { value, timestamp: Date.now() });
    return value;
  }

  async set<T>(key: string, value: T): Promise<void> {
    await chrome.storage.local.set({ [key]: value });
    this.cache.set(key, { value, timestamp: Date.now() });
    this.notifyListeners(key, value);
  }

  async getMany<T>(keys: string[]): Promise<Record<string, T>> {
    const result = await chrome.storage.local.get(keys);
    // 更新缓存
    for (const key of keys) {
      if (key in result) {
        this.cache.set(key, { value: result[key], timestamp: Date.now() });
      }
    }
    return result as Record<string, T>;
  }

  async setMany(items: Record<string, any>): Promise<void> {
    await chrome.storage.local.set(items);
    for (const [key, value] of Object.entries(items)) {
      this.cache.set(key, { value, timestamp: Date.now() });
      this.notifyListeners(key, value);
    }
  }

  async remove(key: string): Promise<void> {
    await chrome.storage.local.remove(key);
    this.cache.delete(key);
  }

  async clear(): Promise<void> {
    await chrome.storage.local.clear();
    this.cache.clear();
  }

  // ==================== 用户状态管理 ====================

  async getCurrentUser(): Promise<StoredUser | undefined> {
    return this.get<StoredUser>(StorageKeys.CURRENT_USER);
  }

  async setCurrentUser(user: StoredUser): Promise<void> {
    await this.set(StorageKeys.CURRENT_USER, user);
  }

  async clearCurrentUser(): Promise<void> {
    await this.remove(StorageKeys.CURRENT_USER);
  }

  // ==================== 同步状态管理 ====================

  private getDefaultSyncStatus(): SyncStatusData {
    return {
      isRunning: false,
      progress: 0,
      total: 0,
      processed: 0,
      failed: 0,
      currentStep: '',
    };
  }

  async getSyncStatus(platform?: string): Promise<SyncStatusData | Record<string, SyncStatusData>> {
    const allStatus = await this.get<Record<string, SyncStatusData>>(StorageKeys.SYNC_STATUS);
    if (platform) {
      return allStatus?.[platform] || this.getDefaultSyncStatus();
    }
    return allStatus || {};
  }

  async updateSyncStatus(platform: string, status: Partial<SyncStatusData>): Promise<void> {
    const allStatus = await this.get<Record<string, SyncStatusData>>(StorageKeys.SYNC_STATUS) || {};
    const current = allStatus[platform] || this.getDefaultSyncStatus();
    const updated = { ...current, ...status };
    allStatus[platform] = updated;
    await this.set(StorageKeys.SYNC_STATUS, allStatus);

    this.broadcastProgress({
      type: updated.isRunning ? 'progress' : 'complete',
      platform,
      progress: updated.progress,
      total: updated.total,
      processed: updated.processed,
      failed: updated.failed,
      step: updated.currentStep,
      timestamp: Date.now(),
    });
  }

  async startSync(platform: string, total: number): Promise<void> {
    await this.updateSyncStatus(platform, {
      isRunning: true,
      total,
      processed: 0,
      failed: 0,
      progress: 0,
      currentStep: '正在获取笔记列表...',
    });
  }

  async updateProgress(platform: string, processed: number, failed: number = 0): Promise<void> {
    const status = await this.getSyncStatus(platform) as SyncStatusData;
    if (!status) return;

    const progress = status.total > 0 ? Math.round((processed / status.total) * 100) : 0;
    await this.updateSyncStatus(platform, { processed, failed, progress });
  }

  async completeSync(platform: string, error?: string): Promise<void> {
    await this.updateSyncStatus(platform, {
      isRunning: false,
      currentStep: error ? `同步失败: ${error}` : '同步完成',
      error,
    });

    if (!error) {
      await this.set(`${platform}_last_sync_time`, Date.now());
    }
  }

  async setSyncStep(platform: string, step: string): Promise<void> {
    await this.updateSyncStatus(platform, { currentStep: step });
  }

  // ==================== 游标管理 ====================

  async getCursor(platform: keyof typeof platformConfig): Promise<string> {
    const key = platformConfig[platform].storage.nextPos;
    const value = await this.get<string>(key);
    return value || '';
  }

  async setCursor(platform: keyof typeof platformConfig, cursor: string): Promise<void> {
    const key = platformConfig[platform].storage.nextPos;
    await this.set(key, cursor);
  }

  async resetCursor(platform: keyof typeof platformConfig): Promise<void> {
    const key = platformConfig[platform].storage.nextPos;
    await this.remove(key);
  }

  // ==================== 事件订阅 ====================

  subscribe(key: string, callback: (data: any) => void): () => void {
    if (!this.listeners.has(key)) {
      this.listeners.set(key, new Set());
    }
    this.listeners.get(key)!.add(callback);
    return () => {
      this.listeners.get(key)?.delete(callback);
    };
  }

  private notifyListeners(key: string, data: any): void {
    this.listeners.get(key)?.forEach(cb => cb(data));
    this.listeners.get('*')?.forEach(cb => cb({ key, data }));
  }

  // ==================== 进度广播 ====================

  private broadcastProgress(event: SyncProgressEvent): void {
    try {
      chrome.runtime.sendMessage({
        name: 'SYNC_PROGRESS',
        data: event,
      }).catch(() => {});
    } catch (error) {
      // 忽略
    }
  }

  async sendError(platform: string, error: string): Promise<void> {
    await this.updateSyncStatus(platform, { error });
    // updateSyncStatus 已广播，无需重复
  }
}

// ==================== 导出单例 ====================
export const stateManager = new StateManager();

// 为方便使用，提供类型导出
export type StateManagerType = StateManager;
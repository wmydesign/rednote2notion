/**
 * 授权码生成工具（Node.js 原生 crypto 库）
 * 在 Node.js 环境中使用原生 crypto 库避免 UTF-8 问题
 */

const crypto = require('crypto');
const { v4: uuidv4 } = require('uuid');

// 加密配置
const LICENSE_SECRET_KEY = 'rednote2notion_license_secure_2024_v2';
const LICENSE_SECRET_IV = 'license_iv_2024_v2';
const FIXED_FINGERPRINT = 'FIXED_FINGERPRINT_2024';

/**
 * 加密函数（与插件 encryptLicense 兼容）
 * 使用哈希派生固定长度的密钥和IV，与 CryptoJS 版本一致
 */
function encrypt(text) {
  // 派生固定长度的密钥和IV（与 CryptoJS 版本一致）
  const keyHex = crypto.createHash('sha256').update(LICENSE_SECRET_KEY).digest('hex').substring(0, 32);
  const ivHex = crypto.createHash('md5').update(LICENSE_SECRET_IV).digest('hex').substring(0, 16);
  
  const key = Buffer.from(keyHex, 'utf8');
  const iv = Buffer.from(ivHex, 'utf8');
  
  // MD5 签名防篡改
  const signature = crypto.createHash('md5').update(text + LICENSE_SECRET_KEY).digest('hex');
  const dataWithSign = JSON.stringify({ data: text, signature });
  
  // AES 加密
  const cipher = crypto.createCipheriv('aes-256-cbc', key, iv);
  let encrypted = cipher.update(dataWithSign, 'utf8', 'base64');
  encrypted += cipher.final('base64');
  
  // Base64 编码后替换特殊字符
  return encrypted.replace(/\+/g, '-').replace(/\//g, '_').replace(/=/g, '');
}

/**
 * 生成授权码
 */
function generateLicenseCode(config) {
  const { type = 'permanent', validDays = 7, count = 1 } = config;
  const codes = [];

  for (let i = 0; i < count; i++) {
    const licenseId = uuidv4().replace(/-/g, '');
    const generateTime = Date.now();
    let expireTime = 0;
    let maxSyncCount = -1;

    if (type === 'free') {
      expireTime = generateTime + 99 * 365 * 24 * 60 * 60 * 1000;
      maxSyncCount = 5;
    } else if (type === 'trial') {
      expireTime = generateTime + validDays * 24 * 60 * 60 * 1000;
    } else {
      expireTime = generateTime + 99 * 365 * 24 * 60 * 60 * 1000;
    }

    const rawLicense = {
      licenseId,
      licenseType: type,
      generateTime,
      expireTime,
      deviceFingerprint: FIXED_FINGERPRINT,
      validDays: type === 'trial' ? validDays : 0,
      maxSyncCount,
      isPreGenerated: true
    };

    const code = encrypt(JSON.stringify(rawLicense));
    codes.push(code);
  }

  return codes;
}

// 命令行使用
if (require.main === module) {
  const args = process.argv.slice(2);
  const type = args[0] || 'permanent';
  const count = parseInt(args[1]) || 1;
  const validDays = parseInt(args[2]) || 7;

  console.log(`\n🚀 生成 ${count} 条 ${type} 授权码...\n`);
  const codes = generateLicenseCode({ type, count, validDays });
  codes.forEach((code, index) => {
    console.log(`${index + 1}. ${code}`);
  });
  console.log(`\n✅ 完成`);
}

module.exports = { generateLicenseCode };

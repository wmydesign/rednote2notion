/**
 * 飞书授权码管理系统
 * 功能：生成授权码 + 自动写入飞书多维表格
 */

const crypto = require('crypto');
const https = require('https');

// ==================== 配置 ====================
const CONFIG = {
  // 飞书多维表格配置
  BASE_TOKEN: 'XJzBb9Dbha2CbDsgfNKcnIHZn0e',
  TABLE_ID: 'tbleOSe8ticHFbl3',
  
  // 字段ID映射
  FIELDS: {
    LICENSE_CODE: 'fldulKoRdV',      // 授权码
    TYPE: 'fldoRMkIsv',               // 类型
    SYNC_LIMIT: 'fldvygCZ5N',         // 同步上限
    VALID_DAYS: 'fldjRUtQqx',         // 有效天数
    STATUS: 'fldbpHRjKR',             // 状态
    DISTRIBUTEE: 'fldhSrLwPa',        // 分发对象
    DISTRIBUTE_TIME: 'fldzh0tHqU',    // 分发时间
    ACTIVATE_TIME: 'fldplVJ6aS',      // 激活时间
    DEVICE_FINGERPRINT: 'fldARMPYKU', // 设备指纹
    REMARK: 'fldvo01hJB'              // 备注
  },
  
  // 加密密钥（与插件保持一致）
  ENCRYPTION_KEY: 'Rednote2Notion_License_2024_Secret_Key_32Byte!',
  IV_LENGTH: 16
};

// ==================== 授权码类型 ====================
const LicenseType = {
  FREE: 'free',
  TRIAL: 'trial',
  PERMANENT: 'permanent'
};

// ==================== 加密函数 ====================
function encrypt(text) {
  const iv = crypto.randomBytes(CONFIG.IV_LENGTH);
  const cipher = crypto.createCipheriv(
    'aes-256-cbc',
    Buffer.from(CONFIG.ENCRYPTION_KEY),
    iv
  );
  let encrypted = cipher.update(text);
  encrypted = Buffer.concat([encrypted, cipher.final()]);
  return iv.toString('hex') + ':' + encrypted.toString('hex');
}

// ==================== 授权码生成 ====================
function generateLicenseCode(type, validDays = 7) {
  const licenseId = crypto.randomUUID().replace(/-/g, '');
  const generateTime = Date.now();
  let expireTime = 0;
  let maxSyncCount = Infinity;

  // 计算过期时间和同步上限
  if (type === LicenseType.FREE) {
    expireTime = generateTime + 99 * 365 * 24 * 60 * 60 * 1000;
    maxSyncCount = 5;
  } else if (type === LicenseType.TRIAL) {
    expireTime = generateTime + 365 * 24 * 60 * 60 * 1000;
  } else {
    expireTime = generateTime + 99 * 365 * 24 * 60 * 60 * 1000;
  }

  const rawLicense = {
    licenseId,
    licenseType: type,
    generateTime,
    expireTime,
    deviceFingerprint: 'UNACTIVATED_CARD',
    validDays: type === LicenseType.TRIAL ? validDays : 0,
    maxSyncCount,
    isPreGenerated: true
  };

  return encrypt(JSON.stringify(rawLicense));
}

// ==================== 飞书API调用 ====================
async function callFeishuAPI(method, path, data = null) {
  return new Promise((resolve, reject) => {
    // 获取lark-cli的access token
    const { execSync } = require('child_process');
    let accessToken = '';
    try {
      const result = execSync('lark-cli auth status --format json 2>/dev/null', { encoding: 'utf-8' });
      const authInfo = JSON.parse(result);
      // 这里需要从lark-cli配置中获取token，简化处理直接用API
    } catch (e) {}
    
    const options = {
      hostname: 'open.feishu.cn',
      port: 443,
      path: path,
      method: method,
      headers: {
        'Content-Type': 'application/json'
      }
    };

    const req = https.request(options, (res) => {
      let body = '';
      res.on('data', (chunk) => body += chunk);
      res.on('end', () => {
        try {
          resolve(JSON.parse(body));
        } catch (e) {
          resolve({ error: body });
        }
      });
    });

    req.on('error', reject);
    if (data) {
      req.write(JSON.stringify(data));
    }
    req.end();
  });
}

// ==================== 写入飞书多维表格 ====================
async function writeToFeishu(licenseCode, type, validDays, remark = '') {
  const typeNames = {
    'free': '🆓 免费版',
    'trial': '⏰ 体验版',
    'permanent': '💎 永久版'
  };
  
  const syncLimits = {
    'free': 5,
    'trial': 999,
    'permanent': 999
  };

  const record = {
    fields: {}
  };
  
  // 使用字段ID
  record.fields[CONFIG.FIELDS.LICENSE_CODE] = licenseCode;
  record.fields[CONFIG.FIELDS.TYPE] = typeNames[type];
  record.fields[CONFIG.FIELDS.SYNC_LIMIT] = syncLimits[type];
  record.fields[CONFIG.FIELDS.STATUS] = '📋 未分发';
  record.fields[CONFIG.FIELDS.REMARK] = remark;
  
  if (type === 'trial') {
    record.fields[CONFIG.FIELDS.VALID_DAYS] = validDays;
  }

  // 使用lark-cli写入
  const { execSync } = require('child_process');
  const jsonStr = JSON.stringify(record.fields);
  const cmd = `lark-cli base +record-upsert --base-token "${CONFIG.BASE_TOKEN}" --table-id "${CONFIG.TABLE_ID}" --json '${jsonStr}'`;
  
  try {
    const result = execSync(cmd, { encoding: 'utf-8', timeout: 30000 });
    return { success: true, result: JSON.parse(result) };
  } catch (error) {
    return { success: false, error: error.message };
  }
}

// ==================== 批量生成并写入 ====================
async function batchGenerateAndWrite(type, count, validDays = 7, remark = '') {
  console.log(`\n🚀 正在生成 ${count} 条授权码并写入飞书...\n`);
  
  const results = [];
  const typeNames = {
    'free': '免费版',
    'trial': '体验版',
    'permanent': '永久版'
  };
  
  for (let i = 0; i < count; i++) {
    const licenseCode = generateLicenseCode(type, validDays);
    const result = await writeToFeishu(licenseCode, type, validDays, remark || `${typeNames[type]}授权码 #${i + 1}`);
    
    results.push({
      index: i + 1,
      licenseCode,
      success: result.success
    });
    
    // 避免API限流
    if (i < count - 1) {
      await new Promise(resolve => setTimeout(resolve, 500));
    }
    
    process.stdout.write(`\r进度: ${i + 1}/${count}`);
  }
  
  console.log('\n\n✅ 完成！');
  
  const successCount = results.filter(r => r.success).length;
  const failCount = results.filter(r => !r.success).length;
  
  console.log(`\n📊 统计:`);
  console.log(`   成功: ${successCount} 条`);
  console.log(`   失败: ${failCount} 条`);
  
  return results;
}

// ==================== 命令行入口 ====================
async function main() {
  const args = process.argv.slice(2);
  
  if (args.length === 0) {
    console.log(`
╔═══════════════════════════════════════════════════════════════╗
║        🔑 飞书授权码管理系统 - 生成并同步到多维表格          ║
╠═══════════════════════════════════════════════════════════════╣
║  使用方法：                                                   ║
║                                                               ║
║  1. 生成免费版授权码（自动写入飞书）：                       ║
║     node feishu-license-manager.js free 5                     ║
║                                                               ║
║  2. 生成永久版授权码（自动写入飞书）：                       ║
║     node feishu-license-manager.js permanent 10              ║
║                                                               ║
║  3. 生成体验版授权码（自动写入飞书）：                       ║
║     node feishu-license-manager.js trial 5 7                 ║
║     (最后参数为有效天数)                                      ║
║                                                               ║
║  4. 查看库存统计：                                            ║
║     node feishu-license-manager.js stats                      ║
║                                                               ║
╚═══════════════════════════════════════════════════════════════╝
    `);
    return;
  }
  
  const command = args[0];
  
  if (command === 'stats') {
    // 查询库存统计
    const { execSync } = require('child_process');
    try {
      const result = execSync(
        `lark-cli base +record-list --base-token "${CONFIG.BASE_TOKEN}" --table-id "${CONFIG.TABLE_ID}"`,
        { encoding: 'utf-8', timeout: 60000 }
      );
      console.log('\n📊 库存统计:\n');
      console.log(result);
    } catch (e) {
      console.log('查询失败:', e.message);
    }
    return;
  }
  
  const type = command;
  const count = parseInt(args[1]) || 1;
  const validDays = parseInt(args[2]) || 7;
  const remark = args[3] || '';
  
  if (!['free', 'trial', 'permanent'].includes(type)) {
    console.log('❌ 无效的授权类型，请使用: free, trial, permanent');
    return;
  }
  
  await batchGenerateAndWrite(type, count, validDays, remark);
}

module.exports = {
  generateLicenseCode,
  writeToFeishu,
  batchGenerateAndWrite
};

if (require.main === module) {
  main();
}

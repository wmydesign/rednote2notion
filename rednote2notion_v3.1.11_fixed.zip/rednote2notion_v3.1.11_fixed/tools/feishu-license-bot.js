/**
 * 飞书授权码生成机器人
 * 
 * 功能：监控飞书消息，根据指令生成授权码并写入多维表格
 * 
 * 使用方法：
 * 1. 在飞书中给机器人发送消息，格式：
 *    - "生成5条永久版"
 *    - "生成10条体验版 7天"
 *    - "生成3条免费版"
 * 
 * 2. 机器人自动生成授权码并写入多维表格
 */

const crypto = require('crypto');
const { execSync } = require('child_process');

// ==================== 配置 ====================
const CONFIG = {
  BASE_TOKEN: 'XJzBb9Dbha2CbDsgfNKcnIHZn0e',
  TABLE_ID: 'tbleOSe8ticHFbl3',
  FIELDS: {
    LICENSE_CODE: 'fldulKoRdV',
    TYPE: 'fldoRMkIsv',
    SYNC_LIMIT: 'fldvygCZ5N',
    VALID_DAYS: 'fldjRUtQqx',
    STATUS: 'fldbpHRjKR',
    REMARK: 'fldvo01hJB'
  },
  ENCRYPTION_KEY: 'Rednote2Notion_License_2024_Secret_Key_32Byte!',
  IV_LENGTH: 16
};

// ==================== 核心函数 ====================

function encrypt(text) {
  const iv = crypto.randomBytes(CONFIG.IV_LENGTH);
  const cipher = crypto.createCipheriv('aes-256-cbc', Buffer.from(CONFIG.ENCRYPTION_KEY), iv);
  let encrypted = cipher.update(text);
  encrypted = Buffer.concat([encrypted, cipher.final()]);
  return iv.toString('hex') + ':' + encrypted.toString('hex');
}

function generateLicenseCode(type, validDays = 7) {
  const licenseId = crypto.randomUUID().replace(/-/g, '');
  const generateTime = Date.now();
  let expireTime = 0;
  let maxSyncCount = Infinity;

  if (type === 'free') {
    expireTime = generateTime + 99 * 365 * 24 * 60 * 60 * 1000;
    maxSyncCount = 5;
  } else if (type === 'trial') {
    expireTime = generateTime + 365 * 24 * 60 * 60 * 1000;
  } else {
    expireTime = generateTime + 99 * 365 * 24 * 60 * 60 * 1000;
  }

  const rawLicense = {
    licenseId,
    licenseType: type,
    generateTime,
    expireTime,
    deviceFingerprint: 'UNACTIVATED_CARD',
    validDays: type === 'trial' ? validDays : 0,
    maxSyncCount,
    isPreGenerated: true
  };

  return encrypt(JSON.stringify(rawLicense));
}

function writeToFeishu(licenseCode, type, validDays, remark) {
  const typeNames = { 'free': '🆓 免费版', 'trial': '⏰ 体验版', 'permanent': '💎 永久版' };
  const syncLimits = { 'free': 5, 'trial': 999, 'permanent': 999 };

  const fields = {};
  fields[CONFIG.FIELDS.LICENSE_CODE] = licenseCode;
  fields[CONFIG.FIELDS.TYPE] = typeNames[type];
  fields[CONFIG.FIELDS.SYNC_LIMIT] = syncLimits[type];
  fields[CONFIG.FIELDS.STATUS] = '📋 未分发';
  fields[CONFIG.FIELDS.REMARK] = remark;
  
  if (type === 'trial') {
    fields[CONFIG.FIELDS.VALID_DAYS] = validDays;
  }

  const cmd = `lark-cli base +record-upsert --base-token "${CONFIG.BASE_TOKEN}" --table-id "${CONFIG.TABLE_ID}" --json '${JSON.stringify(fields)}'`;
  
  try {
    execSync(cmd, { encoding: 'utf-8', timeout: 30000 });
    return true;
  } catch (error) {
    console.error('写入失败:', error.message);
    return false;
  }
}

// ==================== 命令行入口 ====================

async function main() {
  const args = process.argv.slice(2);
  
  if (args.length === 0) {
    console.log(`
╔═══════════════════════════════════════════════════════════════╗
║           🔑 飞书授权码生成器 - 直接生成版                   ║
╠═══════════════════════════════════════════════════════════════╣
║  使用方法：                                                   ║
║                                                               ║
║  node feishu-license-bot.js <类型> <数量> [有效天数]         ║
║                                                               ║
║  示例：                                                       ║
║    node feishu-license-bot.js free 5                         ║
║    node feishu-license-bot.js permanent 10                   ║
║    node feishu-license-bot.js trial 5 7                      ║
║                                                               ║
╚═══════════════════════════════════════════════════════════════╝
    `);
    return;
  }

  const type = args[0];
  const count = parseInt(args[1]) || 1;
  const validDays = parseInt(args[2]) || 7;

  if (!['free', 'trial', 'permanent'].includes(type)) {
    console.log('❌ 无效类型，请使用: free, trial, permanent');
    return;
  }

  const typeNames = { 'free': '免费版', 'trial': '体验版', 'permanent': '永久版' };
  console.log(`\n🚀 正在生成 ${count} 条${typeNames[type]}授权码...\n`);

  let success = 0;
  for (let i = 0; i < count; i++) {
    const licenseCode = generateLicenseCode(type, validDays);
    const remark = `${typeNames[type]}授权码 #${i + 1}`;
    
    if (writeToFeishu(licenseCode, type, validDays, remark)) {
      success++;
      console.log(`✅ ${i + 1}/${count}: ${licenseCode.substring(0, 30)}...`);
    } else {
      console.log(`❌ ${i + 1}/${count}: 写入失败`);
    }
    
    // 避免API限流
    if (i < count - 1) {
      await new Promise(r => setTimeout(r, 300));
    }
  }

  console.log(`\n📊 完成：成功 ${success} 条，失败 ${count - success} 条`);
  console.log(`\n🔗 查看表格: https://bcnz0t21nl5j.feishu.cn/base/${CONFIG.BASE_TOKEN}`);
}

module.exports = { generateLicenseCode, writeToFeishu };

if (require.main === module) {
  main();
}

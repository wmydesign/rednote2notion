/**
 * 授权码生成工具 - 卖家专用
 * 
 * 使用方法：
 * 1. 安装依赖：npm install uuid crypto-js
 * 2. 运行脚本：node generate-license.js
 * 
 * 或者在 Node.js 环境中直接引入使用
 */

const CryptoJS = require('crypto-js');
const { v4: uuidv4 } = require('uuid');

// ==================== 加密配置（与插件 crypto.ts 完全一致）====================
const LICENSE_SECRET_KEY = 'rednote2notion_license_secure_2024_v2';
const LICENSE_SECRET_IV = 'license_iv_2024_v2';
const FIXED_FINGERPRINT = 'FIXED_FINGERPRINT_2024';

/**
 * 加密函数（与插件 encryptLicense 完全一致）
 */
function encrypt(text) {
  const key = CryptoJS.enc.Utf8.parse(LICENSE_SECRET_KEY);
  const iv = CryptoJS.enc.Utf8.parse(LICENSE_SECRET_IV);
  
  // MD5 签名防篡改
  const signature = CryptoJS.MD5(text + LICENSE_SECRET_KEY).toString();
  const dataWithSign = JSON.stringify({ data: text, signature });
  
  // AES 加密
  const encrypted = CryptoJS.AES.encrypt(dataWithSign, key, {
    iv: iv,
    mode: CryptoJS.mode.CBC,
    padding: CryptoJS.pad.Pkcs7
  });
  
  // Base64 编码后替换特殊字符，方便用户复制
  return encrypted.toString().replace(/\+/g, '-').replace(/\//g, '_').replace(/=/g, '');
}

/**
 * 解密函数（用于验证）
 */
function decrypt(text) {
  try {
    // 还原 Base64 特殊字符
    const normalizedCode = text.replace(/-/g, '+').replace(/_/g, '/');
    // 补全 Base64 padding
    const padLength = 4 - (normalizedCode.length % 4);
    const paddedCode = normalizedCode + '='.repeat(padLength < 4 ? padLength : 0);
    
    const key = CryptoJS.enc.Utf8.parse(LICENSE_SECRET_KEY);
    const iv = CryptoJS.enc.Utf8.parse(LICENSE_SECRET_IV);
    
    // 解密
    const decrypted = CryptoJS.AES.decrypt(paddedCode, key, {
      iv: iv,
      mode: CryptoJS.mode.CBC,
      padding: CryptoJS.pad.Pkcs7
    });
    const decryptedStr = decrypted.toString(CryptoJS.enc.Utf8);
    
    // 校验签名防篡改
    const { data, signature } = JSON.parse(decryptedStr);
    const validSignature = CryptoJS.MD5(data + LICENSE_SECRET_KEY).toString();
    if (signature !== validSignature) {
      throw new Error('授权码已被篡改，无效授权');
    }
    
    return data;
  } catch (e) {
    throw new Error('授权码无效，非官方生成');
  }
}

// ==================== 授权码类型 ====================
const LicenseType = {
  FREE: 'free',
  TRIAL: 'trial',
  PERMANENT: 'permanent'
};

// ==================== 常量配置 ====================
const TRIAL_DEFAULT_DAYS = 7;
const PERMANENT_VALID_YEARS = 99;

// ==================== 核心生成函数 ====================

/**
 * 生成授权码（使用固定指纹）
 * @param {Object} config 配置参数
 * @param {string} config.type - 授权类型：'free' | 'trial' | 'permanent'
 * @param {number} config.validDays - 体验版有效天数（默认7天）
 * @param {number} config.count - 生成数量（默认1条）
 * @returns {Array} 授权码数组
 */
function generateLicenseCode(config) {
  const {
    type = 'permanent',
    validDays = 7,
    count = 1
  } = config;

  const codes = [];

  for (let i = 0; i < count; i++) {
    const licenseId = uuidv4().replace(/-/g, '');
    const generateTime = Date.now();
    let expireTime = 0;
    let maxSyncCount = -1; // -1 表示无限制（避免 JSON 序列化问题）

    // 计算过期时间和同步上限
    if (type === LicenseType.FREE) {
      // 免费版：99年有效，5篇同步上限
      expireTime = generateTime + 99 * 365 * 24 * 60 * 60 * 1000;
      maxSyncCount = 5;
    } else if (type === LicenseType.TRIAL) {
      // 体验版：指定天数有效
      expireTime = generateTime + validDays * 24 * 60 * 60 * 1000;
    } else if (type === LicenseType.PERMANENT) {
      // 永久版：99年
      expireTime = generateTime + PERMANENT_VALID_YEARS * 365 * 24 * 60 * 60 * 1000;
    } else {
      expireTime = generateTime + 99 * 365 * 24 * 60 * 60 * 1000;
    }

    // 构建授权码数据（使用固定指纹）
    const rawLicense = {
      licenseId,
      licenseType: type,
      generateTime,
      expireTime,
      deviceFingerprint: FIXED_FINGERPRINT,  // 使用固定指纹
      validDays: type === LicenseType.TRIAL ? validDays : 0,
      maxSyncCount: maxSyncCount,
      isPreGenerated: true
    };

    // 加密生成授权码
    const licenseStr = JSON.stringify(rawLicense);
    const licenseCode = encrypt(licenseStr);
    codes.push(licenseCode);
  }

  return codes;
}

/**
 * 解析授权码（售后验证用）
 * @param {string} licenseCode 授权码
 * @returns {Object} 解析结果
 */
function parseLicenseCode(licenseCode) {
  try {
    const decryptedStr = decrypt(licenseCode);
    const data = JSON.parse(decryptedStr);
    
    const isActivated = data.deviceFingerprint === FIXED_FINGERPRINT;
    const now = Date.now();
    let isValid = true;
    let status = '';

    if (data.expireTime < now) {
      isValid = false;
      status = '已过期';
    } else if (isActivated) {
      status = '有效';
    } else {
      status = '有效';
    }

    const typeNames = {
      'free': '免费版',
      'trial': '体验版',
      'permanent': '永久版'
    };

    return {
      licenseId: data.licenseId,
      type: data.licenseType,
      typeName: typeNames[data.licenseType] || data.licenseType,
      generateTime: new Date(data.generateTime).toLocaleString('zh-CN'),
      expireTime: new Date(data.expireTime).toLocaleString('zh-CN'),
      validDays: data.validDays || '无限制',
      maxSyncCount: data.maxSyncCount || '无限制',
      isActivated,
      isValid,
      status
    };
  } catch (error) {
    return { error: '授权码无效' };
  }
}

// ==================== 命令行工具 ====================

function printUsage() {
  console.log(`
╔═══════════════════════════════════════════════════════════════╗
║           🔑 Rednote2Notion 授权码生成工具 v2.0              ║
╠═══════════════════════════════════════════════════════════════╣
║  使用方法：                                                   ║
║                                                               ║
║  1. 生成免费版授权码（5篇上限）：                             ║
║     node generate-license.js free 10                          ║
║                                                               ║
║  2. 生成体验版授权码（7天有效）：                             ║
║     node generate-license.js trial 10                         ║
║                                                               ║
║  3. 生成永久版授权码（无限制）：                              ║
║     node generate-license.js permanent 10                     ║
║                                                               ║
║  4. 解析授权码：                                              ║
║     node generate-license.js parse <授权码>                   ║
║                                                               ║
╚═══════════════════════════════════════════════════════════════╝
`);
}

// 命令行入口
if (require.main === module) {
  const args = process.argv.slice(2);
  
  if (args.length === 0) {
    printUsage();
    process.exit(0);
  }
  
  const command = args[0].toLowerCase();
  
  if (command === 'parse') {
    // 解析授权码
    const code = args[1];
    if (!code) {
      console.log('❌ 请提供授权码');
      process.exit(1);
    }
    
    const result = parseLicenseCode(code);
    if (result.error) {
      console.log('❌', result.error);
    } else {
      console.log('\n📋 授权码信息：');
      console.log('─'.repeat(50));
      console.log(`授权ID：${result.licenseId}`);
      console.log(`类型：${result.typeName}`);
      console.log(`生成时间：${result.generateTime}`);
      console.log(`过期时间：${result.expireTime}`);
      console.log(`同步上限：${result.maxSyncCount}`);
      console.log(`状态：${result.status}`);
      console.log('─'.repeat(50));
    }
  } else if (['free', 'trial', 'permanent'].includes(command)) {
    // 生成授权码
    const count = parseInt(args[1]) || 1;
    const validDays = parseInt(args[2]) || 7;
    
    console.log(`\n🚀 正在生成 ${count} 条 ${command === 'free' ? '免费版' : command === 'trial' ? '体验版' : '永久版'} 授权码...\n`);
    
    const codes = generateLicenseCode({
      type: command,
      count,
      validDays
    });
    
    codes.forEach((code, index) => {
      console.log(`${index + 1}. ${code}`);
    });
    
    console.log(`\n✅ 已生成 ${codes.length} 条授权码`);
  } else {
    console.log('❌ 未知命令');
    printUsage();
  }
}

// 导出模块
module.exports = {
  generateLicenseCode,
  parseLicenseCode,
  LicenseType
};

// ==================== 原有基础类型 ====================
// 消息类型枚举
export enum MessageType {
  SYNC_TO_NOTION = 'sync-to-notion',
  GET_COOKIE = 'get-cookie',
  ACCOUNT_SWITCH = 'account-switch',
  STOP_ALL_SYNC = 'stop-all-sync',
  CLEAR_CACHE = 'clear-cache',
  GET_ALBUM_LIST = 'get-album-list',
  GET_NOTE_DETAIL = 'get-note-detail',
  SYNC_ERROR = 'sync-error'
}

// 知识类型枚举
export enum KnowledgeType {
  BOOKMARK = '收藏',
  POST = '个人帖子',
  LIKE = '点赞',
  ALBUM = '指定专辑'
}

// 平台配置类型
export interface PlatformConfig {
  name: string;
  knowledgeType: KnowledgeType;
  url: string;
  storage: {
    syncStatusKey: string;
    nextPos: string;
    prevPos: string;
    allSync: string;
  };
}

// 小红书用户信息
export interface RednoteUser {
  userId: string;
  nickname: string;
  avatar: string;
}

// ==================== 新增类型 ====================
// 小红书收藏专辑类型
export interface RednoteAlbum {
  albumId: string;
  albumName: string;
  coverUrl: string;
  noteCount: number;
  updateTime: number;
  isDefault: boolean;
}

// 高级筛选规则类型
export interface FilterRule {
  id: string;
  field: 'title' | 'desc' | 'tags' | 'publishTime' | 'collectTime' | 'likeCount' | 'collectCount' | 'commentCount' | 'noteType' | 'authorName';
  operator: 'contains' | 'notContains' | 'equals' | 'notEquals' | 'greaterThan' | 'lessThan' | 'between' | 'in' | 'notIn' | 'tagContains';
  value: any;
  logic: 'and' | 'or';
}

// AI加工模板类型
export interface AIProcessTemplate {
  id: string;
  name: string;
  fieldName: string;
  prompt: string;
  enable: boolean;
  isCustom?: boolean;
}

// AI加工结果类型
export interface AIProcessResult {
  fieldName: string;
  content: string;
}

// 笔记评论类型
export interface NoteComment {
  commentId: string;
  content: string;
  authorName: string;
  isAuthor: boolean;
  likeCount: number;
  publishTime: number;
}

// 升级后的小红书笔记数据
export interface RednoteNote {
  id: string;
  title: string;
  desc: string;
  coverUrl: string;
  allImages: string[]; // 新增：所有图片列表
  authorName: string;
  authorId: string;
  publishTime: number;
  collectTime?: number; // 新增：收藏时间
  likeCount: number;
  collectCount: number;
  commentCount: number;
  shareCount: number;
  noteUrl: string;
  noteType: 'normal' | 'video' | 'image'; // 新增：笔记类型
  tags: string[];
  albumId?: string; // 新增：所属专辑ID
  albumName?: string; // 新增：所属专辑名称
  aiCategory?: string;
  aiProcessResults?: AIProcessResult[]; // 新增：AI深度加工结果
  comments?: NoteComment[]; // 新增：评论列表
  authorComments?: NoteComment[]; // 新增：作者评论
}

// 同步状态
export interface SyncStatus {
  isRunning: boolean;
  total: number;
  synced: number;
  lastSyncTime: number;
  error?: string;
}

// 账号状态快照
export interface AccountState {
  userId: string;
  static: Record<string, any>;
  bookmarkCateAllSync: Record<string, boolean>;
  selectedAlbums?: string[];
  albumCategoryMap?: Record<string, string>;
}

// 同步配置
export interface SyncConfig {
  platform: keyof typeof platformConfig;
  notionApiKey: string;
  notionDatabaseId: string;
  openaiApiKey?: string;
  enableAIClassify?: boolean;
  // 新增配置
  selectedAlbums: string[];
  albumCategoryMap: Record<string, string>;
  filterRules: FilterRule[];
  enableAIProcess: boolean;
  aiProcessTemplates: AIProcessTemplate[];
  syncAuthorComments: boolean;
  syncTopComments: number;
}

// ==================== AI模型相关类型 ====================

// AI模型提供商枚举
export enum AIProvider {
  OPENAI = 'openai',
  GEMINI = 'gemini',
  DOUBAO = 'doubao',
  DEEPSEEK = 'deepseek'
}

// AI模型配置类型
export interface AIModelConfig {
  provider: AIProvider;
  apiKey: string;
  model: string;
  baseUrl?: string;
}

// AI模型预设配置
export const AI_MODEL_PRESETS: Record<AIProvider, { 
  name: string; 
  baseUrl: string; 
  models: string[];
  defaultModel: string;
  getKeyPlaceholder: string;
  description: string;
}> = {
  [AIProvider.OPENAI]: {
    name: 'OpenAI',
    baseUrl: 'https://api.openai.com/v1',
    models: ['gpt-3.5-turbo', 'gpt-4', 'gpt-4-turbo', 'gpt-4o', 'gpt-4o-mini'],
    defaultModel: 'gpt-3.5-turbo',
    getKeyPlaceholder: 'sk-...',
    description: '支持 GPT-3.5/4/4o 系列模型'
  },
  [AIProvider.GEMINI]: {
    name: 'Google Gemini',
    baseUrl: 'https://generativelanguage.googleapis.com/v1beta',
    models: ['gemini-pro', 'gemini-1.5-flash', 'gemini-1.5-pro'],
    defaultModel: 'gemini-pro',
    getKeyPlaceholder: 'AIza...',
    description: '支持 Gemini Pro/1.5 系列模型'
  },
  [AIProvider.DOUBAO]: {
    name: '豆包 (字节跳动)',
    baseUrl: 'https://ark.cn-beijing.volces.com/api/v3',
    models: ['doubao-pro-32k', 'doubao-lite-32k', 'doubao-pro-128k'],
    defaultModel: 'doubao-pro-32k',
    getKeyPlaceholder: '输入火山引擎API Key',
    description: '支持豆包Pro/Lite系列模型'
  },
  [AIProvider.DEEPSEEK]: {
    name: 'Deepseek',
    baseUrl: 'https://api.deepseek.com/v1',
    models: ['deepseek-chat', 'deepseek-coder'],
    defaultModel: 'deepseek-chat',
    getKeyPlaceholder: 'sk-...',
    description: '支持 Deepseek Chat/Coder 模型'
  }
};

// AI配置存储结构
export interface AIConfigStorage {
  provider: AIProvider;
  apiKey: string;
  model: string;
  enableAIClassify: boolean;
}

// ==================== Notion数据库模板与视图相关类型 ====================

// 数据库视图类型枚举
export type DatabaseViewType = 'table' | 'calendar' | 'board' | 'gallery' | 'timeline';

// 数据库视图配置
export interface DatabaseView {
  name: string;
  type: DatabaseViewType;
  dateProperty?: string; // 日历/时间轴视图使用的日期属性
  groupProperty?: string; // 看板视图使用的分组属性
  coverProperty?: string; // 画廊视图使用的封面属性
}

// 数据库模板配置
export interface DatabaseTemplate {
  name: string;
  description: string;
  properties: Record<string, any>;
  views: DatabaseView[];
}

// Notion页面信息
export interface NotionPage {
  id: string;
  title: string;
  url: string;
  icon: string;
}

// 数据库完整性检查结果
export interface DatabaseCompletenessResult {
  isComplete: boolean;
  missingFields: string[];
  missingLearningFields?: string[]; // 学习场景缺失字段
  isLearningMode?: boolean; // 是否启用了学习模式
}

// 数据库创建结果
export interface DatabaseCreateResult {
  databaseId: string;
  databaseUrl: string;
}

// ==================== 学习场景相关类型 ====================

// 学习进度枚举
export enum LearningProgress {
  NOT_STARTED = '未开始',
  IN_PROGRESS = '学习中',
  MASTERED = '已掌握',
  NEEDS_REVIEW = '需复习'
}

// 学习优先级枚举
export enum LearningPriority {
  HIGH = '高',
  MEDIUM = '中',
  LOW = '低'
}

// 知识领域枚举
export enum KnowledgeDomain {
  PROGRAMMING = '编程',
  DESIGN = '设计',
  WORKPLACE = '职场',
  LANGUAGE = '语言',
  FINANCE = '理财',
  LIFE_SKILLS = '生活技能',
  OTHER = '其他'
}

// 难度等级枚举
export enum DifficultyLevel {
  BEGINNER = '入门',
  INTERMEDIATE = '进阶',
  ADVANCED = '高级',
  EXPERT = '专家'
}

// 学习类型枚举
export enum LearningType {
  TUTORIAL = '教程',
  CASE_STUDY = '案例',
  THEORY = '理论',
  TOOL = '工具',
  EXPERIENCE = '经验分享'
}

// 学习场景视图类型
export interface LearningViewTemplate {
  id: string;
  name: string;
  icon: string;
  description: string;
  viewType: DatabaseViewType;
  config: {
    groupProperty?: string;
    dateProperty?: string;
    coverProperty?: string;
    filters?: Array<{
      property: string;
      condition: string;
      value: any;
    }>;
    sorts?: Array<{
      property: string;
      direction: 'ascending' | 'descending';
    }>;
  };
  usage: string; // 用途说明
}

// 学习统计信息
export interface LearningStats {
  total: number;
  notStarted: number;
  inProgress: number;
  mastered: number;
  needsReview: number;
  totalEstimatedMinutes: number;
  totalActualMinutes: number;
  byDomain: Record<string, number>;
  byDifficulty: Record<string, number>;
}

// ==================== 智能知识库整合方案类型 ====================

// 知识主题枚举
export type KnowledgeTopic = 
  | '编程开发' 
  | '设计美学' 
  | '理财投资' 
  | '职场成长' 
  | '健康生活' 
  | '语言学习' 
  | '效率工具' 
  | '兴趣爱好' 
  | '其他';

// AI智能分析结果
export interface AIAnalysisResult {
  // 主题归类
  topic: KnowledgeTopic;
  subTopic: string; // 如 Python、UI设计、基金定投
  
  // 智能标签
  tags: string[]; // #教程 #案例 #工具 #干货
  
  // 内容索引
  summary: string; // 一句话摘要（50字以内）
  keywords: string[]; // 3-5个关键词
  applicableScenarios: string; // 适用场景描述
  
  // 路径关联
  relatedNoteIds: string[]; // 相关笔记ID（用于学习路径）
  learningPathSuggestion: string; // 学习路径建议
}

// 学习状态
export type LearningStatus = '未学' | '学习中' | '已掌握' | '待复习';

// 学习优先级
export type LearningPriority = '高' | '中' | '低';

// 智能知识库笔记（扩展原有 RednoteNote）
export interface SmartKnowledgeNote {
  // 原有字段保留
  id: string;
  title: string;
  desc: string;
  coverUrl: string;
  authorName: string;
  authorId: string;
  publishTime: number;
  likeCount: number;
  collectCount: number;
  commentCount: number;
  noteUrl: string;
  noteType: '图文' | '视频';
  tags: string[];
  
  // === 新增：智能知识库字段 ===
  
  // 主题归档（AI自动）
  knowledgeTopic: KnowledgeTopic;
  subTopic: string;
  
  // 智能标签（AI自动 + 用户手动）
  aiTags: string[];
  userTags: string[];
  
  // 内容索引（AI生成）
  oneLineSummary: string;
  keywords: string[];
  applicableScenarios: string;
  
  // 学习管理（用户设置）
  learningStatus: LearningStatus;
  learningPriority: LearningPriority;
  learningNotes: string; // 用户的学习心得
  
  // 路径关联（AI推荐）
  relatedNoteIds: string[];
  learningPathId?: string; // 所属学习路径
}

// 学习路径
export interface LearningPath {
  id: string;
  name: string;
  topic: KnowledgeTopic;
  noteIds: string[]; // 按顺序排列的笔记ID
  createdAt: number;
  updatedAt: number;
}

// 智能知识库配置
export interface SmartKnowledgeConfig {
  enabled: boolean; // 是否启用智能知识库
  autoAIAnalysis: boolean; // 是否自动AI分析
  enableTopicArchive: boolean; // 是否启用主题归档
  enableSmartTags: boolean; // 是否启用智能标签
  enableContentIndex: boolean; // 是否启用内容索引
  enableLearningPath: boolean; // 是否启用学习路径
  defaultLearningStatus: LearningStatus; // 默认学习状态
  defaultLearningPriority: LearningPriority; // 默认学习优先级
}

// 智能知识库统计
export interface SmartKnowledgeStats {
  totalNotes: number;
  byTopic: Record<KnowledgeTopic, number>;
  byStatus: Record<LearningStatus, number>;
  byPriority: Record<LearningPriority, number>;
  learningPaths: number;
}

// ==================== 关联数据库相关类型 ====================

// 关联数据库配置
export interface RelationDatabaseConfig {
  enableAuthorDB: boolean;    // 启用作者库
  enableTagDB: boolean;       // 启用标签库
  enableAlbumDB: boolean;     // 启用专辑库
}

// 作者信息
export interface AuthorInfo {
  authorId: string;
  authorName: string;
  avatarUrl?: string;
  noteCount: number;
  followerCount?: number;
  lastUpdateTime: number;
}

// 标签信息
export interface TagInfo {
  tagName: string;
  noteCount: number;
  relatedTags: string[];
  lastUpdateTime: number;
}

// 专辑信息
export interface AlbumInfo {
  albumId: string;
  albumName: string;
  coverUrl: string;
  noteCount: number;
  lastUpdateTime: number;
}

// 关联数据库创建结果
export interface RelationDatabaseResult {
  authorDBId?: string;
  tagDBId?: string;
  albumDBId?: string;
  authorDBUrl?: string;
  tagDBUrl?: string;
  albumDBUrl?: string;
}

// 页面模板类型
export interface PageTemplate {
  id: string;
  name: string;
  description: string;
  sections: PageTemplateSection[];
}

export interface PageTemplateSection {
  id: string;
  title: string;
  icon: string;
  type: 'info' | 'summary' | 'tags' | 'content' | 'images' | 'link' | 'notes' | 'custom';
  enabled: boolean;
  order: number;
}

// ==================== 平台配置 ====================
export const platformConfig: Record<string, PlatformConfig> = {
  post: {
    name: 'post',
    knowledgeType: KnowledgeType.POST,
    url: 'https://www.xiaohongshu.com/user/profile',
    storage: {
      syncStatusKey: 'rednote_post_sync_status',
      nextPos: 'rednote_post_next_cursor',
      prevPos: 'rednote_post_prev_cursor',
      allSync: 'rednote_post_all_sync',
    },
  },
  bookmark: {
    name: 'bookmark',
    knowledgeType: KnowledgeType.BOOKMARK,
    url: 'https://www.xiaohongshu.com/collection',
    storage: {
      syncStatusKey: 'rednote_bookmark_sync_status',
      nextPos: 'rednote_bookmark_next_cursor',
      prevPos: 'rednote_bookmark_prev_cursor',
      allSync: 'rednote_bookmark_all_sync',
    },
  },
  like: {
    name: 'like',
    knowledgeType: KnowledgeType.LIKE,
    url: 'https://www.xiaohongshu.com/like',
    storage: {
      syncStatusKey: 'rednote_like_sync_status',
      nextPos: 'rednote_like_next_cursor',
      prevPos: 'rednote_like_prev_cursor',
      allSync: 'rednote_like_all_sync',
    },
  },
};
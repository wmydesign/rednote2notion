/**
 * 统一状态管理器
 * 集中管理 chrome.storage 调用，解决状态管理分散问题
 */

import { platformConfig, KnowledgeType } from './types';

// ==================== 存储键枚举 ====================
export const StorageKeys = {
  // 用户相关
  CURRENT_USER: 'current_user',
  PER_ACCOUNT_STATE: 'rednote_per_account_state',
  
  // 同步状态
  SYNC_STATUS: 'sync_status',
  LAST_SYNC_TIME: 'last_sync_time',
  SYNC_ERROR: 'sync_error',
  
  // 游标
  NEXT_CURSOR: 'next_cursor',
  PREV_CURSOR: 'prev_cursor',
  ALL_SYNC: 'all_sync',
  
  // 同步快照
  SYNC_SNAPSHOT: 'sync_snapshot',
  
  // 配置
  NOTION_CONFIG: 'notion_config',
  AI_CONFIG: 'ai_config',
  SYNC_CONFIG: 'sync_config',
  
  // 许可证
  LICENSE_INFO: 'license_info',
} as const;

// ==================== 存储值类型 ====================
export interface StoredUser {
  userId: string;
  nickname: string;
  avatar?: string;
}

export interface SyncStatusData {
  isRunning: boolean;
  progress: number;
  total: number;
  processed: number;
  failed: number;
  currentStep: string;
  error?: string;
}

export interface SyncProgressEvent {
  type: 'progress' | 'complete' | 'error' | 'step';
  platform: string;
  progress?: number;
  total?: number;
  processed?: number;
  failed?: number;
  step?: string;
  error?: string;
  timestamp: number;
}

// ==================== 状态管理器类 ====================
class StateManager {
  private listeners: Map<string, Set<(data: any) => void>> = new Map();
  private cache: Map<string, any> = new Map();
  private cacheDirty: Set<string> = new Set();
  
  // 缓存过期时间（毫秒）
  private cacheTTL: number = 5000;

  constructor() {
    // 定期刷新脏缓存到存储
    this.startFlushInterval();
  }

  /**
   * 获取存储值
   */
  async get<T>(key: string): Promise<T | undefined> {
    // 先检查内存缓存
    if (!this.cacheDirty.has(key)) {
      const cached = this.cache.get(key);
      if (cached && Date.now() - cached.timestamp < this.cacheTTL) {
        return cached.value;
      }
    }

    // 从chrome.storage获取
    const result = await chrome.storage.local.get(key);
    const value = result[key] as T | undefined;
    
    // 更新缓存
    this.cache.set(key, { value, timestamp: Date.now() });
    this.cacheDirty.delete(key);
    
    return value;
  }

  /**
   * 设置存储值
   */
  async set<T>(key: string, value: T): Promise<void> {
    await chrome.storage.local.set({ [key]: value });
    
    // 更新缓存
    this.cache.set(key, { value, timestamp: Date.now() });
    this.cacheDirty.delete(key);
    
    // 通知监听器
    this.notifyListeners(key, value);
  }

  /**
   * 批量获取
   */
  async getMany<T>(keys: string[]): Promise<Record<string, T>> {
    const result = await chrome.storage.local.get(keys);
    return result as Record<string, T>;
  }

  /**
   * 批量设置
   */
  async setMany(items: Record<string, any>): Promise<void> {
    await chrome.storage.local.set(items);
    
    // 更新缓存
    for (const [key, value] of Object.entries(items)) {
      this.cache.set(key, { value, timestamp: Date.now() });
      this.cacheDirty.delete(key);
      this.notifyListeners(key, value);
    }
  }

  /**
   * 删除存储值
   */
  async remove(key: string): Promise<void> {
    await chrome.storage.local.remove(key);
    this.cache.delete(key);
    this.cacheDirty.delete(key);
  }

  /**
   * 清除所有存储
   */
  async clear(): Promise<void> {
    await chrome.storage.local.clear();
    this.cache.clear();
    this.cacheDirty.clear();
  }

  // ==================== 用户状态管理 ====================

  /**
   * 获取当前用户
   */
  async getCurrentUser(): Promise<StoredUser | undefined> {
    return this.get<StoredUser>(StorageKeys.CURRENT_USER);
  }

  /**
   * 设置当前用户
   */
  async setCurrentUser(user: StoredUser): Promise<void> {
    await this.set(StorageKeys.CURRENT_USER, user);
  }

  /**
   * 清除当前用户
   */
  async clearCurrentUser(): Promise<void> {
    await this.remove(StorageKeys.CURRENT_USER);
  }

  // ==================== 同步状态管理 ====================

  /**
   * 获取同步状态
   */
  async getSyncStatus(platform?: string): Promise<SyncStatusData | Record<string, SyncStatusData>> {
    if (platform) {
      const allStatus = await this.get<Record<string, SyncStatusData>>(StorageKeys.SYNC_STATUS);
      return allStatus?.[platform] || { isRunning: false, progress: 0, total: 0, processed: 0, failed: 0, currentStep: '' };
    }
    return this.get<Record<string, SyncStatusData>>(StorageKeys.SYNC_STATUS) || {};
  }

  /**
   * 更新同步状态
   */
  async updateSyncStatus(platform: string, status: Partial<SyncStatusData>): Promise<void> {
    const allStatus = await this.get<Record<string, SyncStatusData>>(StorageKeys.SYNC_STATUS) || {};
    allStatus[platform] = {
      ...allStatus[platform],
      ...status,
    } as SyncStatusData;
    await this.set(StorageKeys.SYNC_STATUS, allStatus);
    
    // 发送进度通知到前端
    this.broadcastProgress({
      type: status.isRunning ? 'progress' : 'complete',
      platform,
      progress: status.progress,
      total: status.total,
      processed: status.processed,
      failed: status.failed,
      step: status.currentStep,
      timestamp: Date.now(),
    });
  }

  /**
   * 标记同步开始
   */
  async startSync(platform: string, total: number): Promise<void> {
    await this.updateSyncStatus(platform, {
      isRunning: true,
      total,
      processed: 0,
      failed: 0,
      progress: 0,
      currentStep: '正在获取笔记列表...',
    });
  }

  /**
   * 更新同步进度
   */
  async updateProgress(platform: string, processed: number, failed: number = 0): Promise<void> {
    const status = await this.getSyncStatus(platform) as SyncStatusData;
    if (!status) return;
    
    const progress = status.total > 0 ? Math.round((processed / status.total) * 100) : 0;
    await this.updateSyncStatus(platform, {
      processed,
      failed,
      progress,
    });
  }

  /**
   * 标记同步完成
   */
  async completeSync(platform: string, error?: string): Promise<void> {
    const status = await this.getSyncStatus(platform) as SyncStatusData;
    await this.updateSyncStatus(platform, {
      isRunning: false,
      currentStep: error ? `同步失败: ${error}` : '同步完成',
      error,
    });
    
    if (!error) {
      await this.set(`${platform}_last_sync_time`, Date.now());
    }
  }

  /**
   * 标记同步步骤
   */
  async setSyncStep(platform: string, step: string): Promise<void> {
    await this.updateSyncStatus(platform, { currentStep: step });
  }

  // ==================== 游标管理 ====================

  /**
   * 获取游标
   */
  async getCursor(platform: keyof typeof platformConfig): Promise<string> {
    const key = platformConfig[platform].storage.nextPos;
    const value = await this.get<string>(key);
    return value || '';
  }

  /**
   * 设置游标
   */
  async setCursor(platform: keyof typeof platformConfig, cursor: string): Promise<void> {
    const key = platformConfig[platform].storage.nextPos;
    await this.set(key, cursor);
  }

  /**
   * 重置游标
   */
  async resetCursor(platform: keyof typeof platformConfig): Promise<void> {
    const key = platformConfig[platform].storage.nextPos;
    await this.remove(key);
  }

  // ==================== 事件监听 ====================

  /**
   * 订阅状态变化
   */
  subscribe(key: string, callback: (data: any) => void): () => void {
    if (!this.listeners.has(key)) {
      this.listeners.set(key, new Set());
    }
    this.listeners.get(key)!.add(callback);
    
    // 返回取消订阅函数
    return () => {
      this.listeners.get(key)?.delete(callback);
    };
  }

  /**
   * 通知监听器
   */
  private notifyListeners(key: string, data: any): void {
    this.listeners.get(key)?.forEach(callback => callback(data));
    // 也通知通配符监听器
    this.listeners.get('*')?.forEach(callback => callback({ key, data }));
  }

  // ==================== 进度广播 ====================

  /**
   * 广播同步进度到前端
   */
  private broadcastProgress(event: SyncProgressEvent): void {
    try {
      chrome.runtime.sendMessage({
        name: 'SYNC_PROGRESS',
        data: event,
      }).catch(() => {
        // 忽略发送失败（前端可能未连接）
      });
    } catch (error) {
      console.warn('进度广播失败:', error);
    }
  }

  /**
   * 发送错误到前端
   */
  async sendError(platform: string, error: string): Promise<void> {
    await this.updateSyncStatus(platform, { error });
    this.broadcastProgress({
      type: 'error',
      platform,
      error,
      timestamp: Date.now(),
    });
  }

  // ==================== 缓存管理 ====================

  /**
   * 使缓存失效
   */
  invalidate(key: string): void {
    this.cacheDirty.add(key);
  }

  /**
   * 清空脏缓存
   */
  private startFlushInterval(): void {
    // 定期检查并刷新脏缓存
    setInterval(async () => {
      if (this.cacheDirty.size > 0) {
        const dirtyKeys = Array.from(this.cacheDirty);
        const items: Record<string, any> = {};
        
        for (const key of dirtyKeys) {
          const cached = this.cache.get(key);
          if (cached) {
            items[key] = cached.value;
          }
        }
        
        if (Object.keys(items).length > 0) {
          await chrome.storage.local.set(items);
          dirtyKeys.forEach(key => this.cacheDirty.delete(key));
        }
      }
    }, 10000); // 每10秒检查一次
  }
}

// ==================== 导出单例 ====================
export const stateManager = new StateManager();

// 快捷导出
export const {
  get,
  set,
  getMany,
  setMany,
  remove,
  getCurrentUser,
  setCurrentUser,
  getSyncStatus,
  updateSyncStatus,
  startSync,
  updateProgress,
  completeSync,
  setSyncStep,
  getCursor,
  setCursor,
  subscribe,
} = stateManager;

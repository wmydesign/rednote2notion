/**
 * 消息处理器模块
 * 模块化消息处理，解决模块耦合度高问题
 */

import { MessageType, KnowledgeType, platformConfig, AIProvider } from '../lib/types';
import { stateManager, startSync, completeSync, updateProgress, setSyncStep, sendError } from '../lib/state-manager';
import { RednoteParser } from '../lib/rednote-parser';
import { checkSyncPermission, updateSyncCount } from '../lib/license';
import { writeNoteToNotion, checkNoteIsSynced } from '../lib/notion';
import { classifyNoteWithAI } from '../lib/ai-service';
import { retryWithBackoff, createConcurrentQueue, createRateLimiter } from '../lib/concurrent';
import { getBrowserInfo, getBrowserSpecificHeaders } from '../lib/browser-polyfill';
import type { AIModelConfig, RednoteNote, SyncSnapshot, SyncConfig } from '../lib/types';

// ==================== 处理器接口 ====================
export interface MessageHandler {
  handle(message: any, sender: any): Promise<any>;
}

// ==================== 账号切换处理器 ====================
export class AccountSwitchHandler implements MessageHandler {
  async handle(message: any, sender: any) {
    const { userId, nickname, avatar } = message.data;
    console.log('检测到账号切换', userId);
    
    // 保存当前账号状态
    const currentUser = await stateManager.getCurrentUser();
    if (currentUser?.userId) {
      await this.snapshotAccountState(currentUser.userId);
    }
    
    // 更新当前用户
    await stateManager.setCurrentUser({ userId, nickname, avatar });
    
    // 恢复新账号状态
    await this.restoreAccountState(userId);
    
    return { success: true };
  }

  private async snapshotAccountState(userId: string): Promise<void> {
    const staticKeys = [
      'rednote_post_next_cursor', 'rednote_post_prev_cursor', 'rednote_post_all_sync',
      'rednote_bookmark_next_cursor', 'rednote_bookmark_prev_cursor', 'rednote_bookmark_all_sync',
      'rednote_like_next_cursor', 'rednote_like_prev_cursor', 'rednote_like_all_sync'
    ];
    
    const state: any = { userId, static: {} };
    const storageData = await stateManager.getMany(staticKeys);
    state.static = storageData;
    
    const allState = await stateManager.get('rednote_per_account_state') || {};
    allState[userId] = state;
    await stateManager.set('rednote_per_account_state', allState);
  }

  private async restoreAccountState(userId: string): Promise<void> {
    const allState = await stateManager.get('rednote_per_account_state') || {};
    const state = allState[userId];
    if (!state?.static) return;
    
    const updates: Record<string, any> = {};
    for (const [key, value] of Object.entries(state.static)) {
      if (value !== undefined) {
        updates[key] = value;
      }
    }
    if (Object.keys(updates).length > 0) {
      await stateManager.setMany(updates);
    }
  }
}

// ==================== 清除缓存处理器 ====================
export class ClearCacheHandler implements MessageHandler {
  async handle(message: any, sender: any) {
    const staticKeys = [
      'rednote_post_next_cursor', 'rednote_post_prev_cursor', 'rednote_post_all_sync',
      'rednote_bookmark_next_cursor', 'rednote_bookmark_prev_cursor', 'rednote_bookmark_all_sync',
      'rednote_like_next_cursor', 'rednote_like_prev_cursor', 'rednote_like_all_sync'
    ];
    
    for (const key of staticKeys) {
      await stateManager.remove(key);
    }
    
    console.log('同步缓存已清除');
    return { success: true };
  }
}

// ==================== 获取Cookie处理器 ====================
export class GetCookieHandler implements MessageHandler {
  async handle(message: any, sender: any) {
    const tabId = sender.tab?.id;
    if (!tabId) return { success: false, error: '无活动标签页' };
    
    await chrome.scripting.executeScript({
      target: { tabId },
      func: () => document.cookie
    });
    
    return { success: true };
  }
}

// ==================== 停止同步处理器 ====================
export class StopAllSyncHandler implements MessageHandler {
  async handle(message: any, sender: any) {
    // 清除所有定时任务
    const allAlarms = await chrome.alarms.getAll();
    for (const alarm of allAlarms) {
      if (alarm.name.startsWith('rednote-sync-')) {
        await chrome.alarms.clear(alarm.name);
      }
    }
    
    // 标记所有同步状态为停止
    for (const config of Object.values(platformConfig)) {
      await stateManager.updateSyncStatus(config.name, { isRunning: false, currentStep: '已停止' });
    }
    
    console.log('所有同步任务已停止');
    return { success: true };
  }
}

// ==================== 同步到Notion处理器 ====================
export class SyncToNotionHandler implements MessageHandler {
  private parser = new RednoteParser();
  
  async handle(message: any, sender: any) {
    const { platform, notionApiKey, notionDatabaseId, aiProvider, aiModel, aiApiKey, enableAIClassify } = message.data;
    const platformCfg = platformConfig[platform];
    
    if (!platformCfg) {
      return { success: false, error: '无效的平台配置' };
    }
    
    // 标记同步状态为运行中
    await stateManager.updateSyncStatus(platform, { isRunning: true, currentStep: '正在初始化...' });
    
    // 异步执行同步
    this.executeSync({
      platform,
      notionApiKey,
      notionDatabaseId,
      aiProvider,
      aiModel,
      aiApiKey,
      enableAIClassify
    });
    
    return { success: true };
  }
  
  private async executeSync(config: {
    platform: string;
    notionApiKey: string;
    notionDatabaseId: string;
    aiProvider?: AIProvider;
    aiModel?: string;
    aiApiKey?: string;
    enableAIClassify?: boolean;
  }) {
    const { platform, notionApiKey, notionDatabaseId, aiProvider, aiModel, aiApiKey, enableAIClassify } = config;
    const platformCfg = platformConfig[platform];
    const browserInfo = getBrowserInfo();
    
    console.log(`[V3.1.1] 同步启动 - 浏览器: ${browserInfo.name} ${browserInfo.version}`);
    
    // 构建AI配置
    const aiConfig: AIModelConfig | undefined = enableAIClassify && aiApiKey ? {
      provider: aiProvider || AIProvider.OPENAI,
      apiKey: aiApiKey,
      model: aiModel || 'gpt-3.5-turbo'
    } : undefined;
    
    try {
      // 授权检查
      await setSyncStep(platform, '正在验证授权...');
      const permission = await checkSyncPermission();
      if (!permission.hasPermission) {
        throw new Error(permission.errorMsg || '授权验证失败');
      }
      
      // 检查小红书登录状态
      await setSyncStep(platform, '正在检查登录状态...');
      const currentUser = await stateManager.getCurrentUser();
      if (!currentUser) {
        throw new Error('请先在小红书网页版登录并授权');
      }
      
      // 创建并发队列（带请求间隔随机化）
      const concurrentQueue = createConcurrentQueue(3, {
        onProgress: (completed, total) => {
          stateManager.updateSyncStatus(platform, {
            processed: completed,
            total,
            progress: Math.round((completed / total) * 100)
          });
        }
      });
      
      // 获取游标
      await setSyncStep(platform, '正在获取笔记列表...');
      const cursor = await stateManager.getCursor(platform as keyof typeof platformConfig) || '';
      
      // 构建API地址
      const { apiUrl, requestMethod, requestBody } = this.buildApiRequest(platformCfg, currentUser.userId, cursor);
      
      // 使用浏览器适配的请求头
      const browserHeaders = getBrowserSpecificHeaders();
      
      // 请求小红书API
      await setSyncStep(platform, '正在请求小红书API...');
      const response = await this.fetchWithRetry(apiUrl, {
        method: requestMethod,
        credentials: 'include',
        headers: {
          'Content-Type': 'application/json',
          'Referer': 'https://www.xiaohongshu.com/',
          'User-Agent': navigator.userAgent,
          ...browserHeaders
        },
        body: requestBody
      });
      
      if (!response.ok) {
        throw new Error(`API请求失败: ${response.status}`);
      }
      
      const data = await response.json();
      if (data.code !== 0) {
        throw new Error(`API返回错误: ${data.msg}`);
      }
      
      // 使用健壮解析器解析数据
      const parseResult = this.parser.parseNoteList(data);
      if (!parseResult.success || !parseResult.data) {
        throw new Error('笔记列表解析失败');
      }
      
      const notes = parseResult.data;
      const nextCursor = data.data?.cursor || '';
      const hasMore = data.data?.has_more || false;
      
      // 初始化进度
      await stateManager.startSync(platform, notes.length);
      console.log(`[V3.1.1] 发现 ${notes.length} 条笔记待同步`);
      
      // 并发处理笔记（带速率限制和随机间隔）
      const rateLimiter = createRateLimiter(2); // 每秒2个请求
      
      for (let i = 0; i < notes.length; i++) {
        const rawNote = notes[i];
        
        concurrentQueue.add(async () => {
          // 添加随机间隔（300-800ms抖动）
          await this.randomDelay(300, 800);
          await rateLimiter.acquire();
          
          const parsedNote = this.parser.parseNote(rawNote);
          if (!parsedNote.data) {
            throw new Error('笔记解析失败');
          }
          
          return this.processNote(parsedNote.data, notionApiKey, notionDatabaseId, aiConfig);
        });
        
        // 每处理10条更新一次进度
        if ((i + 1) % 10 === 0) {
          const status = concurrentQueue.getStatus();
          await updateProgress(platform, status.completed, 0);
        }
      }
      
      // 等待所有任务完成
      await concurrentQueue.waitForComplete?.();
      
      // 更新游标
      if (hasMore && nextCursor) {
        await stateManager.setCursor(platform as keyof typeof platformConfig, nextCursor);
      } else {
        await stateManager.set(platformCfg.storage.allSync, true);
      }
      
      // 完成同步
      await completeSync(platform);
      
      const finalStatus = concurrentQueue.getStatus();
      console.log(`[V3.1.1] ${platformCfg.knowledgeType}同步完成 - 处理: ${notes.length}, 完成: ${finalStatus.completed}`);
      
    } catch (error: any) {
      console.error('同步失败', error);
      await sendError(platform, error.message);
      await completeSync(platform, error.message);
    }
  }
  
  private buildApiRequest(platformCfg: any, userId: string, cursor: string): {
    apiUrl: string;
    requestMethod: string;
    requestBody: string | null;
  } {
    switch (platformCfg.knowledgeType) {
      case KnowledgeType.POST:
        return {
          apiUrl: `https://edith.xiaohongshu.com/api/sns/web/v1/user/notes?cursor=${cursor}&num=20&user_id=${userId}`,
          requestMethod: 'GET',
          requestBody: null
        };
      case KnowledgeType.BOOKMARK:
        return {
          apiUrl: 'https://edith.xiaohongshu.com/api/sns/web/v2/note/collect/page',
          requestMethod: 'POST',
          requestBody: JSON.stringify({ cursor, num: 20 })
        };
      case KnowledgeType.LIKE:
        return {
          apiUrl: 'https://edith.xiaohongshu.com/api/sns/web/v1/note/like/page',
          requestMethod: 'POST',
          requestBody: JSON.stringify({ cursor, num: 20 })
        };
      default:
        return {
          apiUrl: '',
          requestMethod: 'GET',
          requestBody: null
        };
    }
  }
  
  private async fetchWithRetry(url: string, options: RequestInit, maxRetries: number = 3): Promise<Response> {
    let lastError: Error | null = null;
    
    for (let i = 0; i < maxRetries; i++) {
      try {
        const response = await fetch(url, options);
        
        // 429限流时等待后重试
        if (response.status === 429) {
          const retryAfter = parseInt(response.headers.get('Retry-After') || '5');
          console.log(`[限流] 等待 ${retryAfter} 秒后重试...`);
          await this.randomDelay(retryAfter * 1000, retryAfter * 1000 + 2000);
          continue;
        }
        
        return response;
      } catch (error) {
        lastError = error as Error;
        // 指数退避
        await this.randomDelay(1000 * Math.pow(2, i), 1500 * Math.pow(2, i));
      }
    }
    
    throw lastError || new Error('请求失败');
  }
  
  private async processNote(
    note: RednoteNote,
    notionApiKey: string,
    notionDatabaseId: string,
    aiConfig?: AIModelConfig
  ): Promise<void> {
    // 检查是否已同步
    const isSynced = await checkNoteIsSynced(notionApiKey, notionDatabaseId, note.id);
    if (isSynced) return;
    
    // AI分类
    if (aiConfig) {
      note.aiCategory = await classifyNoteWithAI(aiConfig, note);
    }
    
    // 写入Notion
    await retryWithBackoff(() => writeNoteToNotion(notionApiKey, notionDatabaseId, note), {
      maxRetries: 3,
      baseDelay: 1000,
    });
    
    // 更新同步计数
    await updateSyncCount(1);
  }
  
  // 随机延迟（添加抖动防止被检测）
  private randomDelay(min: number, max: number): Promise<void> {
    const delay = Math.floor(Math.random() * (max - min + 1)) + min;
    return new Promise(resolve => setTimeout(resolve, delay));
  }
}

// ==================== 同步错误处理器 ====================
export class SyncErrorHandler implements MessageHandler {
  async handle(message: any, sender: any) {
    const { platform, error } = message.data || {};
    console.error('同步错误:', error);
    
    if (platform) {
      await sendError(platform, error || '未知错误');
    }
    
    return { success: true };
  }
}

// ==================== 消息路由 ====================
export class MessageRouter {
  private handlers: Map<string, MessageHandler> = new Map();
  
  constructor() {
    // 注册默认处理器
    this.register(MessageType.ACCOUNT_SWITCH, new AccountSwitchHandler());
    this.register(MessageType.CLEAR_CACHE, new ClearCacheHandler());
    this.register(MessageType.GET_COOKIE, new GetCookieHandler());
    this.register(MessageType.STOP_ALL_SYNC, new StopAllSyncHandler());
    this.register(MessageType.SYNC_TO_NOTION, new SyncToNotionHandler());
    this.register(MessageType.SYNC_ERROR, new SyncErrorHandler());
  }
  
  /**
   * 注册处理器
   */
  register(messageType: string, handler: MessageHandler): void {
    this.handlers.set(messageType, handler);
  }
  
  /**
   * 获取处理器
   */
  getHandler(messageType: string): MessageHandler | undefined {
    return this.handlers.get(messageType);
  }
  
  /**
   * 处理消息
   */
  async handle(message: any, sender: any): Promise<any> {
    const handler = this.handlers.get(message.name);
    if (!handler) {
      console.warn(`未注册的消息处理器: ${message.name}`);
      return { success: false, error: '未知的消息类型' };
    }
    
    try {
      return await handler.handle(message, sender);
    } catch (error: any) {
      console.error(`消息处理错误 (${message.name}):`, error);
      return { success: false, error: error.message };
    }
  }
}

// 导出默认路由实例
export const messageRouter = new MessageRouter();

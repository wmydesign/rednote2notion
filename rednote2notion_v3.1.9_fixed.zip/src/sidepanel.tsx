import React, { useState, useEffect } from 'react';
import { MessageType, platformConfig, AIProvider, AI_MODEL_PRESETS } from './lib/types';
import { testAIConnection } from './lib/ai-service';
import { getCurrentLicense, LicenseType } from './lib/license';
import { 
  createCompleteDatabase, 
  getNotionPages, 
  checkDatabaseCompleteness, 
  completeDatabaseFields,
  getViewConfigurationGuide,
  createRelationDatabases,
  updateDatabaseWithRelations
} from './lib/notion';
import type { NotionPage, RelationDatabaseConfig, RelationDatabaseResult } from './lib/types';
import './style.css';

// 骨架屏组件
const SkeletonLoader = () => (
  <div className="skeleton-container">
    {/* 头部骨架 */}
    <div className="skeleton-card">
      <div style={{ display: 'flex', alignItems: 'center' }}>
        <div className="skeleton skeleton-avatar" />
        <div className="skeleton-info">
          <div className="skeleton skeleton-line" style={{ width: '120px' }} />
          <div className="skeleton skeleton-line" style={{ width: '80px', height: '10px' }} />
        </div>
      </div>
    </div>
    
    {/* Tab骨架 */}
    <div className="skeleton-card">
      <div className="skeleton skeleton-title" />
      {/* 同步卡片骨架 */}
      {[1, 2, 3].map((i) => (
        <div key={i} className="skeleton-row" style={{ borderBottom: i < 3 ? '1px solid #F0F0F0' : 'none' }}>
          <div className="skeleton skeleton-circle" />
          <div className="skeleton-info" style={{ marginLeft: '12px' }}>
            <div className="skeleton skeleton-line" style={{ width: `${100 + i * 20}px` }} />
            <div className="skeleton skeleton-line" style={{ width: '60px', height: '10px' }} />
          </div>
        </div>
      ))}
    </div>
    
    {/* 操作按钮骨架 */}
    <div className="skeleton-card">
      <div style={{ display: 'flex', gap: '10px' }}>
        <div className="skeleton" style={{ flex: 1, height: '40px', borderRadius: '12px' }} />
        <div className="skeleton" style={{ flex: 1, height: '40px', borderRadius: '12px' }} />
      </div>
    </div>
  </div>
);

// 圆环进度组件
const CircularProgress = ({ progress, size = 64, strokeWidth = 5 }: { 
  progress: number; 
  size?: number;
  strokeWidth?: number;
}) => {
  const radius = (size - strokeWidth) / 2;
  const circumference = radius * 2 * Math.PI;
  const offset = circumference - (progress / 100) * circumference;
  
  return (
    <div className="progress-ring-container">
      <div className="progress-ring" style={{ width: size, height: size }}>
        <svg viewBox={`0 0 ${size} ${size}`}>
          <defs>
            <linearGradient id="progressGradient" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#FF2442" />
              <stop offset="100%" stopColor="#FF6B81" />
            </linearGradient>
          </defs>
          <circle
            className="progress-ring-bg"
            cx={size / 2}
            cy={size / 2}
            r={radius}
          />
          <circle
            className="progress-ring-value"
            cx={size / 2}
            cy={size / 2}
            r={radius}
            style={{ 
              strokeDasharray: circumference,
              strokeDashoffset: offset
            }}
          />
        </svg>
        <span className="progress-ring-text">{Math.round(progress)}%</span>
      </div>
    </div>
  );
};

// 空状态组件
const EmptyState = ({ 
  icon = '📭', 
  title = '暂无数据', 
  description = '这里什么都没有，快去添加内容吧',
  actionText = '',
  onAction = () => {}
}: {
  icon?: string;
  title?: string;
  description?: string;
  actionText?: string;
  onAction?: () => void;
}) => (
  <div className="empty-state animate-fade-in">
    <div className="empty-state-icon">{icon}</div>
    <div className="empty-state-title">{title}</div>
    <div className="empty-state-desc">{description}</div>
    {actionText && (
      <button className="empty-state-action" onClick={onAction}>
        {actionText}
      </button>
    )}
  </div>
);

// Toast组件
const Toast = ({ message, type = 'default', show }: { 
  message: string; 
  type?: 'default' | 'success' | 'error' | 'warning';
  show: boolean;
}) => {
  if (!message) return null;
  
  const icons = {
    default: '💡',
    success: '✅',
    error: '❌',
    warning: '⚠️'
  };
  
  return (
    <div className={`xhs-toast ${show ? 'show' : ''} ${type !== 'default' ? `xhs-toast-${type}` : ''}`}>
      <span className="xhs-toast-icon">{icons[type]}</span>
      <span>{message}</span>
    </div>
  );
};

// 授权未激活提示组件 - 支持直接输入授权码
const LicenseNotActivatedOverlay = ({ 
  onActivate, 
  onVerifyLicense,
  licenseInput,
  setLicenseInput,
  verifying,
  verifyError,
  verifySuccess
}: { 
  onActivate: () => void;
  onVerifyLicense: (code: string) => Promise<boolean>;
  licenseInput: string;
  setLicenseInput: (value: string) => void;
  verifying: boolean;
  verifyError: string;
  verifySuccess: boolean;
}) => {
  const [showInput, setShowInput] = useState(false);

  const handleVerify = async () => {
    if (!licenseInput.trim()) {
      return;
    }
    const success = await onVerifyLicense(licenseInput.trim());
    if (success) {
      // 成功后自动关闭
      setTimeout(() => {}, 1500);
    }
  };

  return (
    <div className="animate-fade-in" style={{
      position: 'fixed',
      top: 0,
      left: 0,
      right: 0,
      bottom: 0,
      background: 'rgba(0, 0, 0, 0.85)',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      zIndex: 9999,
      padding: '20px'
    }}>
      <div className="glass-card" style={{
        maxWidth: '380px',
        width: '100%',
        textAlign: 'center',
        padding: '32px 24px'
      }}>
        {/* 成功动画 */}
        {verifySuccess ? (
          <>
            <div style={{
              width: '80px',
              height: '80px',
              margin: '0 auto 20px',
              borderRadius: '50%',
              background: 'linear-gradient(135deg, #52C41A 0%, #73D13D 100%)',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              fontSize: '40px',
              boxShadow: '0 8px 24px rgba(82, 196, 26, 0.35)',
              animation: 'pulse 0.5s ease-in-out'
            }}>
              ✅
            </div>
            <h2 style={{
              fontSize: '20px',
              fontWeight: 600,
              color: '#52C41A',
              marginBottom: '12px'
            }}>
              激活成功！
            </h2>
            <p style={{
              fontSize: '14px',
              color: 'var(--text-secondary)',
              lineHeight: 1.6
            }}>
              正在为您加载插件功能...
            </p>
          </>
        ) : (
          <>
            <div style={{
              width: '80px',
              height: '80px',
              margin: '0 auto 20px',
              borderRadius: '50%',
              background: 'linear-gradient(135deg, #FF2442 0%, #FF6B81 100%)',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              fontSize: '40px',
              boxShadow: '0 8px 24px rgba(255, 36, 66, 0.35)'
            }}>
              🔐
            </div>
            
            <h2 style={{
              fontSize: '20px',
              fontWeight: 600,
              color: 'var(--text-primary)',
              marginBottom: '12px'
            }}>
              请先激活授权码
            </h2>
            
            <p style={{
              fontSize: '14px',
              color: 'var(--text-secondary)',
              marginBottom: '24px',
              lineHeight: 1.6
            }}>
              为了持续为您提供优质服务<br/>
              请激活授权码后继续使用
            </p>

            {/* 授权码输入区域 */}
            {showInput ? (
              <div style={{ marginBottom: '16px' }}>
                <input
                  type="text"
                  value={licenseInput}
                  onChange={(e) => setLicenseInput(e.target.value)}
                  placeholder="请输入授权码"
                  style={{
                    width: '100%',
                    padding: '12px 16px',
                    border: verifyError ? '2px solid #FF4D4F' : '2px solid var(--border-color)',
                    borderRadius: '12px',
                    fontSize: '14px',
                    outline: 'none',
                    transition: 'border-color 0.2s',
                    boxSizing: 'border-box',
                    marginBottom: '8px'
                  }}
                  disabled={verifying}
                />
                {verifyError && (
                  <div style={{
                    fontSize: '12px',
                    color: '#FF4D4F',
                    marginBottom: '8px',
                    textAlign: 'left'
                  }}>
                    ⚠️ {verifyError}
                  </div>
                )}
                <div style={{ display: 'flex', gap: '10px' }}>
                  <button
                    className="xhs-btn xhs-btn-secondary"
                    onClick={() => {
                      setShowInput(false);
                      setLicenseInput('');
                    }}
                    style={{ flex: 1 }}
                    disabled={verifying}
                  >
                    取消
                  </button>
                  <button
                    className="xhs-btn xhs-btn-primary"
                    onClick={handleVerify}
                    style={{ flex: 2 }}
                    disabled={verifying || !licenseInput.trim()}
                  >
                    {verifying ? '⏳ 验证中...' : '✓ 激活授权'}
                  </button>
                </div>
              </div>
            ) : (
              <>
                <button
                  className="xhs-btn xhs-btn-primary xhs-btn-block"
                  onClick={() => setShowInput(true)}
                  style={{ marginBottom: '12px' }}
                >
                  🔑 输入授权码激活
                </button>
                <button
                  className="xhs-btn xhs-btn-secondary xhs-btn-block"
                  onClick={onActivate}
                  style={{ marginBottom: '12px' }}
                >
                  📋 前往激活页面
                </button>
              </>
            )}
            
            <p style={{
              fontSize: '12px',
              color: 'var(--text-hint)'
            }}>
              没有授权码？联系开发者获取
            </p>
          </>
        )}
      </div>
    </div>
  );
};

const SidePanel = () => {
  // 授权状态
  const [licenseActivated, setLicenseActivated] = useState(false);
  const [licenseInfo, setLicenseInfo] = useState<any>(null);
  const [licenseInput, setLicenseInput] = useState('');
  const [verifying, setVerifying] = useState(false);
  const [verifyError, setVerifyError] = useState('');
  const [verifySuccess, setVerifySuccess] = useState(false);
  
  // 用户信息状态
  const [userInfo, setUserInfo] = useState<{ userId: string; nickname: string } | null>(null);
  const [xiaohongshuAuthorized, setXiaohongshuAuthorized] = useState(false);
  const [xiaohongshuLoading, setXiaohongshuLoading] = useState(true);
  
  const [notionConfig, setNotionConfig] = useState({
    apiKey: '',
    databaseId: ''
  });
  
  // 数据库管理相关状态
  const [notionPages, setNotionPages] = useState<NotionPage[]>([]);
  const [selectedPageId, setSelectedPageId] = useState('');
  const [creating, setCreating] = useState(false);
  const [databaseUrl, setDatabaseUrl] = useState('');
  
  // 新的AI配置状态（多模型支持）
  const [aiConfig, setAiConfig] = useState({
    provider: AIProvider.OPENAI,
    apiKey: '',
    model: 'gpt-3.5-turbo',
    enableAIClassify: false
  });
  
  // 智能知识库配置状态
  const [knowledgeBaseEnabled, setKnowledgeBaseEnabled] = useState(false);
  
  const [syncStatus, setSyncStatus] = useState<Record<string, boolean>>({});
  const [lastSyncTime, setLastSyncTime] = useState<Record<string, number>>({});
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState<'sync' | 'config'>('sync');
  const [syncProgress, setSyncProgress] = useState(0);
  const [isDarkMode, setIsDarkMode] = useState(false);
  const [toast, setToast] = useState({ show: false, message: '', type: 'default' as 'default' | 'success' | 'error' | 'warning' });
  const [testingConnection, setTestingConnection] = useState(false);
  
  // 关联数据库配置状态
  const [relationConfig, setRelationConfig] = useState<RelationDatabaseConfig>({
    enableAuthorDB: true,
    enableTagDB: true,
    enableAlbumDB: false
  });
  const [relationDBResult, setRelationDBResult] = useState<RelationDatabaseResult | null>(null);
  const [creatingRelationDB, setCreatingRelationDB] = useState(false);
  const [syncStatusText, setSyncStatusText] = useState<string>('');  // 同步步骤文本

  // 初始化加载配置
  useEffect(() => {
    loadConfig();
    initDarkMode();
    checkXiaohongshuAuth();
  }, []);

  // 同步进度实时监听（V3.1.1新增）
  useEffect(() => {
    // 监听来自 background 的进度更新
    const handleProgressMessage = (message: any) => {
      if (message.name === 'SYNC_PROGRESS' && message.data) {
        const { progress, processed, failed, step, error } = message.data;
        if (progress !== undefined) {
          setSyncProgress(progress);
        }
        if (step) {
          setSyncStatusText(step);
        }
        if (error) {
          showToast(`同步错误: ${error}`, 'error');
        }
      }
    };

    // 添加消息监听
    chrome.runtime.onMessage.addListener(handleProgressMessage);

    return () => {
      chrome.runtime.onMessage.removeListener(handleProgressMessage);
    };
  }, []);

  // 深色模式初始化
  const initDarkMode = () => {
    // 使用 chrome.storage.local 替代 localStorage（更适合扩展）
    chrome.storage.local.get(['darkMode'], (result) => {
      const stored = result.darkMode;
      if (stored !== undefined) {
        setIsDarkMode(stored === true);
        document.body.classList.toggle('dark', stored === true);
      } else {
        const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
        setIsDarkMode(prefersDark);
        document.body.classList.toggle('dark', prefersDark);
      }
    });
  };

  // 切换深色模式
  const toggleDarkMode = () => {
    const newMode = !isDarkMode;
    setIsDarkMode(newMode);
    chrome.storage.local.set({ darkMode: newMode });
    document.body.classList.toggle('dark', newMode);
  };

  // 显示提示
  const showToast = (msg: string, type: 'default' | 'success' | 'error' | 'warning' = 'default') => {
    setToast({ show: true, message: msg, type });
    setTimeout(() => setToast({ show: false, message: '', type: 'default' }), 2500);
  };

  // 打开授权激活页面
  const openActivationPage = () => {
    chrome.runtime.openOptionsPage();
  };

  // 检查授权状态
  const checkLicenseStatus = async () => {
    const info = await getCurrentLicense();
    setLicenseInfo(info);
    setLicenseActivated(info.isActivated && info.isValid);
    return info.isActivated && info.isValid;
  };

  // 验证并激活授权码
  const handleVerifyLicense = async (code: string): Promise<boolean> => {
    setVerifying(true);
    setVerifyError('');
    
    try {
      // 动态导入激活函数
      const { activateLicenseCode } = await import('./lib/license');
      const result = await activateLicenseCode(code);
      
      if (result.isValid && result.isActivated) {
        setVerifySuccess(true);
        setLicenseActivated(true);
        setLicenseInfo(result);
        showToast('授权码激活成功！', 'success');
        
        // 1.5秒后刷新页面加载功能
        setTimeout(() => {
          loadConfig();
        }, 1500);
        return true;
      } else {
        setVerifyError(result.errorMsg || '授权码无效');
        return false;
      }
    } catch (error: any) {
      setVerifyError(error.message || '验证失败，请重试');
      return false;
    } finally {
      setVerifying(false);
    }
  };

  // 检查小红书授权状态
  const checkXiaohongshuAuth = async () => {
    setXiaohongshuLoading(true);
    try {
      // 先检查本地存储的用户信息
      const storageData = await chrome.storage.local.get(['current_user']);
      if (storageData.current_user) {
        setXiaohongshuAuthorized(true);
        setUserInfo(storageData.current_user);
        setXiaohongshuLoading(false);
        return true;
      }
      
      // 尝试检测小红书登录状态
      const response = await fetch('https://edith.xiaohongshu.com/api/sns/web/v2/user/me', {
        credentials: 'include',
        headers: {
          'Content-Type': 'application/json',
          'Referer': 'https://www.xiaohongshu.com/'
        }
      });
      
      if (response.ok) {
        const data = await response.json();
        if (data.code === 0 && data.data) {
          setXiaohongshuAuthorized(true);
          setUserInfo({
            userId: data.data.user_id,
            nickname: data.data.nickname
          });
          // 保存用户信息到存储
          await chrome.storage.local.set({
            'current_user': {
              userId: data.data.user_id,
              nickname: data.data.nickname
            }
          });
          setXiaohongshuLoading(false);
          return true;
        }
      }
      setXiaohongshuAuthorized(false);
      setUserInfo(null);
      setXiaohongshuLoading(false);
      return false;
    } catch (error) {
      console.error('检查小红书授权失败', error);
      setXiaohongshuAuthorized(false);
      setUserInfo(null);
      setXiaohongshuLoading(false);
      return false;
    }
  };

  // 打开小红书登录页进行授权
  const handleXiaohongshuAuth = () => {
    chrome.tabs.create({
      url: 'https://www.xiaohongshu.com/',
      active: true
    });
    // 授权后提示用户刷新
    showToast('请登录小红书后，点击刷新按钮', 'warning');
  };

  // 测试AI连接
  const handleTestConnection = async () => {
    if (!aiConfig.apiKey) {
      showToast('请先输入 API Key', 'warning');
      return;
    }

    setTestingConnection(true);
    try {
      const result = await testAIConnection({
        provider: aiConfig.provider,
        apiKey: aiConfig.apiKey,
        model: aiConfig.model
      });
      
      if (result.success) {
        showToast(result.message, 'success');
      } else {
        showToast(result.message, 'error');
      }
    } catch (error: any) {
      showToast(`测试失败: ${error.message}`, 'error');
    } finally {
      setTestingConnection(false);
    }
  };

  // 获取Notion页面列表
  const loadNotionPages = async () => {
    if (!notionConfig.apiKey) {
      showToast('请先填写Notion API Key', 'error');
      return;
    }
    
    setLoading(true);
    try {
      const pages = await getNotionPages(notionConfig.apiKey);
      setNotionPages(pages);
      if (pages.length > 0) {
        setSelectedPageId(pages[0].id);
      }
      showToast(`找到 ${pages.length} 个页面`, 'success');
    } catch (error: any) {
      showToast(`获取页面失败: ${error.message}`, 'error');
    } finally {
      setLoading(false);
    }
  };

  // 一键创建数据库
  const handleCreateDatabase = async () => {
    if (!notionConfig.apiKey) {
      showToast('请先填写Notion API Key', 'error');
      return;
    }
    if (!selectedPageId) {
      showToast('请选择一个页面作为数据库的父页面', 'error');
      return;
    }
    
    setCreating(true);
    try {
      const result = await createCompleteDatabase(notionConfig.apiKey, selectedPageId);
      
      // 自动保存数据库ID
      await chrome.storage.local.set({
        'notion_database_id': result.databaseId
      });
      
      setNotionConfig({ ...notionConfig, databaseId: result.databaseId });
      setDatabaseUrl(result.databaseUrl);
      
      showToast('数据库创建成功！已自动保存数据库ID', 'success');
    } catch (error: any) {
      showToast(`创建失败: ${error.message}`, 'error');
    } finally {
      setCreating(false);
    }
  };

  // 检查数据库完整性
  const handleCheckDatabase = async () => {
    if (!notionConfig.apiKey || !notionConfig.databaseId) {
      showToast('请先填写完整配置', 'error');
      return;
    }
    
    try {
      const result = await checkDatabaseCompleteness(notionConfig.apiKey, notionConfig.databaseId);
      
      if (result.isComplete) {
        showToast('数据库字段完整，无需修复', 'success');
      } else {
        showToast(`缺少字段: ${result.missingFields.join(', ')}`, 'warning');
        // 询问是否补齐
        if (confirm('检测到缺失字段，是否自动补齐？')) {
          await completeDatabaseFields(notionConfig.apiKey, notionConfig.databaseId);
          showToast('字段已补齐', 'success');
        }
      }
    } catch (error: any) {
      showToast(`检查失败: ${error.message}`, 'error');
    }
  };

  // 创建关联数据库
  const handleCreateRelationDatabases = async () => {
    if (!notionConfig.apiKey) {
      showToast('请先填写Notion API Key', 'error');
      return;
    }
    if (!selectedPageId) {
      showToast('请先选择一个页面作为数据库的父页面', 'error');
      return;
    }
    if (!notionConfig.databaseId) {
      showToast('请先创建主数据库', 'error');
      return;
    }
    
    // 检查是否至少选择了一个关联库
    if (!relationConfig.enableAuthorDB && !relationConfig.enableTagDB && !relationConfig.enableAlbumDB) {
      showToast('请至少选择一个关联数据库类型', 'warning');
      return;
    }
    
    setCreatingRelationDB(true);
    try {
      // 创建关联数据库
      const result = await createRelationDatabases(
        notionConfig.apiKey,
        selectedPageId,
        notionConfig.databaseId,
        relationConfig
      );
      
      // 更新主数据库，添加关联字段
      await updateDatabaseWithRelations(notionConfig.apiKey, notionConfig.databaseId, {
        authorDBId: result.authorDBId,
        tagDBId: result.tagDBId,
        albumDBId: result.albumDBId
      });
      
      // 保存关联数据库ID到本地存储
      await chrome.storage.local.set({
        'relation_db_ids': {
          authorDBId: result.authorDBId,
          tagDBId: result.tagDBId,
          albumDBId: result.albumDBId
        }
      });
      
      setRelationDBResult(result);
      showToast('关联数据库创建成功！', 'success');
    } catch (error: any) {
      showToast(`创建失败: ${error.message}`, 'error');
    } finally {
      setCreatingRelationDB(false);
    }
  };

  // 获取视图配置指南
  const viewGuide = getViewConfigurationGuide();

  // 加载本地存储配置
  const loadConfig = async () => {
    setLoading(true);
    
    // 模拟加载延迟以展示骨架屏
    await new Promise(resolve => setTimeout(resolve, 800));
    
    // 检查授权状态
    await checkLicenseStatus();
    
    const storageData = await chrome.storage.local.get([
      'notion_api_key',
      'notion_database_id',
      'ai_provider',
      'ai_model',
      'ai_api_key',
      'ai_enable_classify',
      'knowledge_base_enabled',
      'sync-rednote-post-to-notion',
      'sync-rednote-bookmark-to-notion',
      'sync-rednote-like-to-notion',
      'sync-rednote-post-to-notion_last_time',
      'sync-rednote-bookmark-to-notion_last_time',
      'sync-rednote-like-to-notion_last_time',
      'current_user',
      'sync_progress'
    ]);

    setNotionConfig({
      apiKey: storageData.notion_api_key || '',
      databaseId: storageData.notion_database_id || ''
    });

    // 加载智能知识库配置
    setKnowledgeBaseEnabled(storageData.knowledge_base_enabled || false);

    // 加载新的AI配置
    const savedProvider = storageData.ai_provider || AIProvider.OPENAI;
    const savedModel = storageData.ai_model || AI_MODEL_PRESETS[savedProvider]?.defaultModel || 'gpt-3.5-turbo';
    
    setAiConfig({
      provider: savedProvider,
      apiKey: storageData.ai_api_key || '',
      model: savedModel,
      enableAIClassify: storageData.ai_enable_classify || false
    });

    setSyncStatus({
      post: storageData['sync-rednote-post-to-notion'] || false,
      bookmark: storageData['sync-rednote-bookmark-to-notion'] || false,
      like: storageData['sync-rednote-like-to-notion'] || false
    });

    setLastSyncTime({
      post: storageData['sync-rednote-post-to-notion_last_time'] || 0,
      bookmark: storageData['sync-rednote-bookmark-to-notion_last_time'] || 0,
      like: storageData['sync-rednote-like-to-notion_last_time'] || 0
    });

    setUserInfo(storageData.current_user || null);
    setSyncProgress(storageData.sync_progress || 0);
    setLoading(false);
  };

  // 保存配置
  const saveConfig = async () => {
    setLoading(true);
    await chrome.storage.local.set({
      'notion_api_key': notionConfig.apiKey,
      'notion_database_id': notionConfig.databaseId,
      'ai_provider': aiConfig.provider,
      'ai_model': aiConfig.model,
      'ai_api_key': aiConfig.apiKey,
      'ai_enable_classify': aiConfig.enableAIClassify,
      'knowledge_base_enabled': knowledgeBaseEnabled
    });
    setLoading(false);
    showToast('配置保存成功', 'success');
  };

  // 切换同步状态
  const toggleSync = async (platform: 'rednotePost' | 'rednoteBookmark' | 'rednoteLike') => {
    // 第一步：检查授权状态
    if (!licenseActivated) {
      showToast('请先激活授权码', 'warning');
      return;
    }

    // 第二步：检查小红书授权
    if (!xiaohongshuAuthorized) {
      showToast('请先授权小红书账号', 'warning');
      return;
    }

    if (!notionConfig.apiKey || !notionConfig.databaseId) {
      showToast('请先配置Notion', 'warning');
      setActiveTab('config');
      return;
    }

    const statusKey = platform === 'rednotePost' ? 'post' : platform === 'rednoteBookmark' ? 'bookmark' : 'like';
    const newStatus = !syncStatus[statusKey];
    
    if (newStatus) {
      // 开始同步动画
      let progress = 0;
      const progressInterval = setInterval(() => {
        progress += Math.random() * 15;
        if (progress > 90) progress = 90;
        setSyncProgress(progress);
      }, 500);

      await chrome.runtime.sendMessage({
        name: MessageType.SYNC_TO_NOTION,
        data: {
          platform,
          notionApiKey: notionConfig.apiKey,
          notionDatabaseId: notionConfig.databaseId,
          // 传递新的AI配置
          aiProvider: aiConfig.provider,
          aiModel: aiConfig.model,
          aiApiKey: aiConfig.apiKey,
          enableAIClassify: aiConfig.enableAIClassify
        }
      });

      clearInterval(progressInterval);
      setSyncProgress(100);
      showToast('同步已开始', 'success');
    } else {
      await chrome.runtime.sendMessage({
        name: MessageType.STOP_ALL_SYNC
      });
      setSyncProgress(0);
      showToast('已停止同步', 'default');
    }

    await loadConfig();
  };

  // 停止所有同步
  const stopAllSync = async () => {
    await chrome.runtime.sendMessage({
      name: MessageType.STOP_ALL_SYNC
    });
    setSyncProgress(0);
    await loadConfig();
    showToast('已停止所有同步', 'default');
  };

  // 清除缓存
  const clearCache = async () => {
    if (confirm('确定要清除所有同步缓存吗？')) {
      await chrome.runtime.sendMessage({
        name: MessageType.CLEAR_CACHE
      });
      await loadConfig();
      showToast('缓存清除成功', 'success');
    }
  };

  // 格式化时间
  const formatTime = (timestamp: number) => {
    if (!timestamp) return '从未同步';
    const date = new Date(timestamp);
    const now = new Date();
    const diff = now.getTime() - date.getTime();
    
    if (diff < 60000) return '刚刚';
    if (diff < 3600000) return `${Math.floor(diff / 60000)}分钟前`;
    if (diff < 86400000) return `${Math.floor(diff / 3600000)}小时前`;
    return date.toLocaleDateString();
  };

  // 同步类型配置
  const syncTypes = [
    {
      key: 'post' as const,
      platform: 'rednotePost' as const,
      title: '个人帖子',
      desc: '同步发布过的笔记',
      icon: '📝',
      iconClass: 'post'
    },
    {
      key: 'bookmark' as const,
      platform: 'rednoteBookmark' as const,
      title: '收藏内容',
      desc: '同步收藏的笔记',
      icon: '⭐',
      iconClass: 'bookmark'
    },
    {
      key: 'like' as const,
      platform: 'rednoteLike' as const,
      title: '点赞内容',
      desc: '同步点赞的笔记',
      icon: '❤️',
      iconClass: 'like'
    }
  ];

  // 当前选择的模型预设
  const currentPreset = AI_MODEL_PRESETS[aiConfig.provider];

  // 智能知识库功能模块样式
  const featureLabelStyle = {
    display: 'flex',
    alignItems: 'center',
    gap: '8px',
    padding: '8px 12px',
    background: 'var(--bg-secondary)',
    borderRadius: '8px',
    fontSize: '13px'
  };

  const featureDesc = {
    fontSize: '11px',
    color: 'var(--text-hint)',
    marginLeft: 'auto'
  };

  // 切换智能知识库开关
  const toggleKnowledgeBase = async () => {
    const newValue = !knowledgeBaseEnabled;
    setKnowledgeBaseEnabled(newValue);
    await chrome.storage.local.set({ knowledge_base_enabled: newValue });
    showToast(newValue ? '智能知识库已启用' : '智能知识库已关闭', 'success');
  };

  // 显示骨架屏
  if (loading) {
    return (
      <div className="w-full min-h-screen" style={{ background: 'var(--bg-light)' }}>
        <div className="xhs-header">
          <h1>Rednote2Notion</h1>
          <p>小红书内容同步 · AI智能分类</p>
        </div>
        <SkeletonLoader />
      </div>
    );
  }

  return (
    <div className="w-full min-h-screen" style={{ background: 'var(--bg-light)' }}>
      {/* 授权未激活遮罩 - 支持直接输入授权码激活 */}
      {!licenseActivated && (
        <LicenseNotActivatedOverlay 
          onActivate={openActivationPage}
          onVerifyLicense={handleVerifyLicense}
          licenseInput={licenseInput}
          setLicenseInput={setLicenseInput}
          verifying={verifying}
          verifyError={verifyError}
          verifySuccess={verifySuccess}
        />
      )}

      {/* 小红书风格头部 */}
      <div className="xhs-header micro-glow">
        <h1>Rednote2Notion</h1>
        <p>小红书内容同步 · AI智能分类</p>
      </div>

      {/* 深色模式切换 */}
      <div className="p-4">
        <div className="dark-mode-toggle glass-card">
          <div className="dark-mode-toggle-label">
            <span className="dark-mode-toggle-icon">{isDarkMode ? '🌙' : '☀️'}</span>
            <span>{isDarkMode ? '深色模式' : '浅色模式'}</span>
          </div>
          <div 
            className={`dark-mode-switch ${isDarkMode ? 'active' : ''}`}
            onClick={toggleDarkMode}
          />
        </div>
      </div>

      {/* 授权状态横幅 */}
      <div className="px-4 pb-2">
        <div className="xhs-card glass-card" style={{
          background: licenseActivated 
            ? 'linear-gradient(135deg, rgba(82, 196, 26, 0.1), rgba(82, 196, 26, 0.02))' 
            : 'linear-gradient(135deg, rgba(255, 77, 79, 0.1), rgba(255, 77, 79, 0.02))',
          border: `1px solid ${licenseActivated ? 'rgba(82, 196, 26, 0.2)' : 'rgba(255, 77, 79, 0.2)'}`
        }}>
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
              <div style={{
                width: '36px',
                height: '36px',
                borderRadius: '50%',
                background: licenseActivated 
                  ? 'linear-gradient(135deg, #52C41A 0%, #73D13D 100%)' 
                  : 'linear-gradient(135deg, #FF4D4F 0%, #FF7875 100%)',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                fontSize: '16px'
              }}>
                {licenseActivated ? '✅' : '⚠️'}
              </div>
              <div>
                <div style={{ fontSize: '13px', fontWeight: 600, color: licenseActivated ? '#52C41A' : '#FF4D4F' }}>
                  授权 {licenseActivated ? '已激活' : '未激活'}
                </div>
                {licenseInfo && (
                  <div style={{ fontSize: '11px', color: 'var(--text-hint)', marginTop: '2px' }}>
                    {licenseInfo.licenseType === LicenseType.PERMANENT ? '永久版' : 
                     licenseInfo.licenseType === LicenseType.TRIAL ? '体验版' : '免费版'} · 
                    已同步 {licenseInfo.usedSyncCount} / {licenseInfo.maxSyncCount === Infinity ? '∞' : licenseInfo.maxSyncCount} 篇
                  </div>
                )}
              </div>
            </div>
            {!licenseActivated && (
              <button
                className="xhs-btn xhs-btn-primary"
                onClick={openActivationPage}
                style={{ fontSize: '12px', padding: '6px 14px' }}
              >
                前往激活
              </button>
            )}
          </div>
        </div>
      </div>

      {/* 小红书授权状态卡片 - 优化版 */}
      <div className="px-4 pb-2">
        <div className="xhs-card glass-card">
          <div className="xhs-card-title">小红书授权</div>
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
            <div>
              <div style={{ fontSize: '14px', fontWeight: 500, display: 'flex', alignItems: 'center', gap: '6px' }}>
                {xiaohongshuAuthorized ? (
                  <>
                    <span style={{ color: 'var(--success-color)' }}>✅</span>
                    <span style={{ color: 'var(--success-color)' }}>已授权</span>
                  </>
                ) : (
                  <>
                    <span style={{ color: 'var(--error-color)' }}>❌</span>
                    <span style={{ color: 'var(--error-color)' }}>未授权</span>
                  </>
                )}
              </div>
              <div style={{ fontSize: '12px', color: 'var(--text-hint)', marginTop: '4px' }}>
                {xiaohongshuAuthorized && userInfo 
                  ? `👤 ${userInfo.nickname}` 
                  : '请先授权登录小红书账号'}
              </div>
            </div>
            <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
              <span className={`xhs-badge ${xiaohongshuAuthorized ? 'xhs-badge-success' : 'xhs-badge-warning'}`}>
                {xiaohongshuAuthorized ? '已授权' : '未授权'}
              </span>
              <button
                className={`xhs-btn ${xiaohongshuAuthorized ? 'xhs-btn-secondary' : 'xhs-btn-primary'}`}
                onClick={xiaohongshuAuthorized ? checkXiaohongshuAuth : handleXiaohongshuAuth}
                disabled={xiaohongshuLoading}
                style={{ 
                  fontSize: '12px', 
                  padding: '6px 14px',
                  opacity: xiaohongshuLoading ? 0.7 : 1,
                  cursor: xiaohongshuLoading ? 'wait' : 'pointer'
                }}
              >
                {xiaohongshuLoading ? (
                  <span style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
                    <span className="loading-spinner" style={{ 
                      display: 'inline-block', 
                      width: '12px', 
                      height: '12px',
                      border: '2px solid rgba(0,0,0,0.1)',
                      borderTopColor: 'var(--primary-color)',
                      borderRadius: '50%',
                      animation: 'spin 0.8s linear infinite'
                    }} />
                    检测中...
                  </span>
                ) : xiaohongshuAuthorized ? '🔄 刷新' : '🔗 授权'}
              </button>
            </div>
          </div>
          
          {/* 用户详细信息 */}
          {xiaohongshuAuthorized && userInfo && (
            <div style={{
              marginTop: '12px',
              padding: '10px 12px',
              background: 'linear-gradient(135deg, rgba(255, 36, 66, 0.08), rgba(255, 36, 66, 0.02))',
              borderRadius: 'var(--radius-md)',
              border: '1px solid rgba(255, 36, 66, 0.1)'
            }}>
              <div style={{ fontSize: '12px', color: 'var(--text-secondary)' }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: '6px', marginBottom: '4px' }}>
                  <span>👤</span>
                  <span style={{ fontWeight: 500 }}>{userInfo.nickname}</span>
                </div>
                <div style={{ display: 'flex', alignItems: 'center', gap: '6px', fontSize: '11px' }}>
                  <span>🔑</span>
                  <span>用户ID: {userInfo.userId}</span>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* 智能知识库开关卡片 - 新增 */}
      <div className="px-4 pb-2">
        <div className="xhs-card glass-card">
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
              <div style={{
                width: '40px',
                height: '40px',
                borderRadius: '50%',
                background: knowledgeBaseEnabled 
                  ? 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)' 
                  : 'linear-gradient(135deg, #999 0%, #666 100%)',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                fontSize: '18px',
                boxShadow: knowledgeBaseEnabled ? '0 4px 14px rgba(102, 126, 234, 0.35)' : 'none'
              }}>
                📚
              </div>
              <div>
                <div style={{ fontSize: '14px', fontWeight: 600, color: 'var(--text-primary)' }}>
                  智能知识库
                </div>
                <div style={{ fontSize: '11px', color: 'var(--text-hint)', marginTop: '2px' }}>
                  AI智能分析 + 主题归档
                </div>
              </div>
            </div>
            <div 
              className={`xhs-switch ${knowledgeBaseEnabled ? 'active' : ''}`}
              onClick={toggleKnowledgeBase}
              style={{
                background: knowledgeBaseEnabled 
                  ? 'var(--primary-gradient)' 
                  : 'var(--border-color)',
                cursor: 'pointer'
              }}
            />
          </div>
          
          {/* 功能模块说明 */}
          {knowledgeBaseEnabled && (
            <div style={{
              marginTop: '12px',
              padding: '10px 12px',
              background: 'var(--bg-secondary)',
              borderRadius: 'var(--radius-md)'
            }}>
              <div style={{ fontSize: '11px', color: 'var(--text-secondary)', marginBottom: '8px' }}>
                已启用功能：
              </div>
              <div style={{ display: 'flex', flexWrap: 'wrap', gap: '6px' }}>
                {[
                  { icon: '🤖', name: 'AI分析' },
                  { icon: '📂', name: '主题归档' },
                  { icon: '🏷️', name: '智能标签' },
                  { icon: '🔍', name: '内容索引' },
                  { icon: '🛤️', name: '学习路径' }
                ].map(item => (
                  <span key={item.name} style={{
                    display: 'flex',
                    alignItems: 'center',
                    gap: '4px',
                    padding: '4px 8px',
                    background: 'white',
                    borderRadius: '6px',
                    fontSize: '11px',
                    fontWeight: 500,
                    color: 'var(--text-primary)'
                  }}>
                    <span>{item.icon}</span>
                    <span>{item.name}</span>
                  </span>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>

      {/* 同步进度展示 - V3.1.1增强版 */}
      {syncProgress > 0 && syncProgress < 100 && (
        <div className="px-4 pb-2 animate-fade-in">
          <div className="xhs-card glass-card" style={{ padding: '12px 16px' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '16px' }}>
              <CircularProgress progress={syncProgress} size={56} strokeWidth={4} />
              <div style={{ flex: 1 }}>
                <div style={{ fontSize: '13px', fontWeight: 500, color: 'var(--text-primary)' }}>
                  正在同步中...
                  {syncStatusText && (
                    <span style={{ fontSize: '12px', color: 'var(--text-secondary)', marginLeft: '8px' }}>
                      ({syncStatusText})
                    </span>
                  )}
                </div>
                <div className="sync-progress-detail">
                  <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                    <span>已完成</span>
                    <span style={{ color: 'var(--primary-color)' }}>{Math.round(syncProgress)}%</span>
                  </div>
                  <div className="sync-progress-bar-container">
                    <div className="sync-progress-bar" style={{ width: `${syncProgress}%` }} />
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Tab切换 */}
      <div className="px-4">
        <div className="glass-card" style={{ padding: '4px', display: 'flex' }}>
          <button
            onClick={() => setActiveTab('sync')}
            className={`xhs-btn ${activeTab === 'sync' ? 'xhs-btn-primary' : 'xhs-btn-secondary'}`}
            style={{ 
              flex: 1, 
              borderRadius: 'var(--radius-md)',
              boxShadow: activeTab === 'sync' ? 'var(--shadow-sm)' : 'none'
            }}
          >
            📥 同步管理
          </button>
          <button
            onClick={() => setActiveTab('config')}
            className={`xhs-btn ${activeTab === 'config' ? 'xhs-btn-primary' : 'xhs-btn-secondary'}`}
            style={{ 
              flex: 1, 
              borderRadius: 'var(--radius-md)',
              boxShadow: activeTab === 'config' ? 'var(--shadow-sm)' : 'none'
            }}
          >
            ⚙️ 配置设置
          </button>
        </div>
      </div>

      {/* 同步管理面板 */}
      {activeTab === 'sync' && (
        <div className="p-4">
          <div className="xhs-card glass-card">
            <div className="xhs-card-title">同步内容</div>
            
            {syncTypes.map((item) => (
              <div 
                key={item.key}
                className={`sync-status-card ${syncStatus[item.key] ? 'active' : ''} ${!licenseActivated || !xiaohongshuAuthorized ? 'disabled' : ''}`}
                onClick={() => {
                  if (!licenseActivated) {
                    showToast('请先激活授权码', 'warning');
                    return;
                  }
                  if (!xiaohongshuAuthorized) {
                    showToast('请先授权小红书账号', 'warning');
                    return;
                  }
                  toggleSync(item.platform);
                }}
              >
                <div 
                  className={`sync-status-icon ${item.iconClass} ${syncStatus[item.key] ? 'syncing' : ''} xhs-bubble`}
                  data-bubble={!licenseActivated ? '请先激活授权' : !xiaohongshuAuthorized ? '请先授权小红书' : syncStatus[item.key] ? '同步中...' : '点击开启'}
                  style={{ 
                    background: item.iconClass === 'post' 
                      ? 'linear-gradient(135deg, #FFE4E8 0%, #FFCCD5 100%)'
                      : item.iconClass === 'bookmark'
                      ? 'linear-gradient(135deg, #FFF3E0 0%, #FFE0B2 100%)'
                      : 'linear-gradient(135deg, #FFE4EC 0%, #FFCCD5 100%)',
                    opacity: (!licenseActivated || !xiaohongshuAuthorized) ? 0.6 : 1
                  }}
                >
                  {item.icon}
                </div>
                <div className="sync-status-info">
                  <div className="sync-status-title">{item.title}</div>
                  <div className="sync-status-time">
                    {syncStatus[item.key] ? (
                      <span style={{ color: 'var(--success-color)', display: 'flex', alignItems: 'center', gap: '4px' }}>
                        <span className="animate-pulse">●</span> 同步中 · {formatTime(lastSyncTime[item.key])}
                      </span>
                    ) : (
                      `最后同步：${formatTime(lastSyncTime[item.key])}`
                    )}
                  </div>
                </div>
                <div 
                  className={`xhs-switch ${syncStatus[item.key] ? 'active' : ''}`}
                  onClick={(e) => {
                    e.stopPropagation();
                    if (!licenseActivated) {
                      showToast('请先激活授权码', 'warning');
                      return;
                    }
                    if (!xiaohongshuAuthorized) {
                      showToast('请先授权小红书账号', 'warning');
                      return;
                    }
                    toggleSync(item.platform);
                  }}
                  style={{ opacity: (!licenseActivated || !xiaohongshuAuthorized) ? 0.5 : 1 }}
                />
              </div>
            ))}
          </div>

          {/* 快捷操作 */}
          <div className="xhs-card glass-card">
            <div className="xhs-card-title">快捷操作</div>
            <div style={{ display: 'flex', gap: '10px' }}>
              <button 
                className="xhs-btn xhs-btn-secondary xhs-btn-block"
                onClick={stopAllSync}
                disabled={!licenseActivated}
              >
                ⏹️ 停止全部
              </button>
              <button 
                className="xhs-btn xhs-btn-outline xhs-btn-block"
                onClick={clearCache}
                disabled={!licenseActivated}
              >
                🗑️ 清除缓存
              </button>
            </div>
          </div>

          {/* AI功能提示 */}
          {aiConfig.enableAIClassify && (
            <div className="xhs-card glass-card" style={{ background: 'linear-gradient(135deg, #FFF5F5 0%, #FFFFFF 100%)' }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                <span style={{ fontSize: '20px' }}>🤖</span>
                <div>
                  <div style={{ fontWeight: 600, fontSize: '14px' }}>AI智能分类已启用</div>
                  <div style={{ fontSize: '12px', color: 'var(--text-hint)' }}>
                    当前使用: {currentPreset?.name} · {aiConfig.model}
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
      )}

      {/* 配置设置面板 */}
      {activeTab === 'config' && (
        <div className="p-4">
          {/* Notion配置 */}
          <div className="xhs-card glass-card">
            <div className="xhs-card-title">Notion 配置</div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: '14px' }}>
              <div>
                <label className="xhs-input-label">API Key</label>
                <input
                  type="password"
                  value={notionConfig.apiKey}
                  onChange={(e) => setNotionConfig({ ...notionConfig, apiKey: e.target.value })}
                  className="xhs-input"
                  placeholder="输入 Notion Integration Token"
                  disabled={!licenseActivated}
                />
              </div>
              <div>
                <label className="xhs-input-label">数据库 ID</label>
                <input
                  type="text"
                  value={notionConfig.databaseId}
                  onChange={(e) => setNotionConfig({ ...notionConfig, databaseId: e.target.value })}
                  className="xhs-input"
                  placeholder="输入 Notion 数据库 ID"
                  disabled={!licenseActivated}
                />
              </div>
            </div>
          </div>

          {/* 数据库管理 - 一键创建向导 */}
          <div className="xhs-card glass-card">
            <div className="xhs-card-title">🗂️ 数据库管理</div>
            
            {/* 已有数据库ID显示 */}
            {notionConfig.databaseId && (
              <div style={{ marginBottom: '12px', padding: '10px', background: '#F0F9FF', borderRadius: '8px' }}>
                <div style={{ fontSize: '12px', color: 'var(--text-secondary)' }}>当前数据库ID</div>
                <div style={{ fontSize: '13px', fontWeight: 500, wordBreak: 'break-all' }}>
                  {notionConfig.databaseId}
                </div>
                {databaseUrl && (
                  <a href={databaseUrl} target="_blank" rel="noopener noreferrer" style={{ fontSize: '12px', color: 'var(--info-color)' }}>
                    在Notion中打开 →
                  </a>
                )}
              </div>
            )}
            
            {/* 一键创建数据库区域 */}
            <div style={{ marginBottom: '12px' }}>
              <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '8px' }}>
                <label className="xhs-input-label" style={{ margin: 0 }}>选择父页面</label>
                <button 
                  className="xhs-btn xhs-btn-secondary xhs-btn-sm"
                  onClick={loadNotionPages}
                  disabled={loading || !licenseActivated}
                >
                  {loading ? '获取中...' : '获取页面列表'}
                </button>
              </div>
              <select
                className="xhs-input"
                value={selectedPageId}
                onChange={(e) => setSelectedPageId(e.target.value)}
                disabled={!licenseActivated}
              >
                <option value="">请选择一个页面</option>
                {notionPages.map(page => (
                  <option key={page.id} value={page.id}>
                    {page.icon} {page.title}
                  </option>
                ))}
              </select>
            </div>
            
            <button
              className="xhs-btn xhs-btn-primary xhs-btn-block"
              onClick={handleCreateDatabase}
              disabled={creating || !selectedPageId || !licenseActivated}
            >
              {creating ? '创建中...' : '🚀 一键创建完整数据库'}
            </button>
            
            {/* 数据库检查按钮 */}
            {notionConfig.databaseId && (
              <button
                className="xhs-btn xhs-btn-secondary xhs-btn-block"
                onClick={handleCheckDatabase}
                style={{ marginTop: '8px' }}
                disabled={!licenseActivated}
              >
                🔍 检查数据库完整性
              </button>
            )}
            
            {/* 视图创建提示 */}
            <div style={{ marginTop: '12px', padding: '10px', background: '#FFF7ED', borderRadius: '8px', fontSize: '12px' }}>
              <div style={{ fontWeight: 500, marginBottom: '4px' }}>💡 创建多视图提示</div>
              <div style={{ color: 'var(--text-secondary)' }}>
                数据库创建后，在Notion中可添加多种视图：<br/>
                • 📅 日历视图（按发布时间）<br/>
                • 📊 看板视图（按分类）<br/>
                • 🖼️ 画廊视图（封面为主）<br/>
                • 📋 时间轴视图（按收藏时间）
              </div>
            </div>
          </div>

          {/* AI配置 - 新增多模型支持 */}
          <div className="xhs-card glass-card">
            <div className="xhs-card-title">🤖 AI 智能分类</div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: '14px' }}>
              
              {/* 模型提供商选择 */}
              <div>
                <label className="xhs-input-label">AI 模型提供商</label>
                <select
                  className="xhs-input"
                  value={aiConfig.provider}
                  onChange={(e) => {
                    const provider = e.target.value as AIProvider;
                    const preset = AI_MODEL_PRESETS[provider];
                    setAiConfig({
                      ...aiConfig,
                      provider,
                      model: preset.defaultModel
                    });
                  }}
                  style={{ cursor: 'pointer' }}
                  disabled={!licenseActivated}
                >
                  {Object.entries(AI_MODEL_PRESETS).map(([key, preset]) => (
                    <option key={key} value={key}>
                      {preset.name}
                    </option>
                  ))}
                </select>
                {currentPreset && (
                  <div style={{ fontSize: '11px', color: 'var(--text-hint)', marginTop: '4px' }}>
                    {currentPreset.description}
                  </div>
                )}
              </div>

              {/* 具体模型输入 */}
              <div>
                <label className="xhs-input-label">具体模型</label>
                <input
                  type="text"
                  className="xhs-input"
                  value={aiConfig.model}
                  onChange={(e) => setAiConfig({ ...aiConfig, model: e.target.value })}
                  placeholder={currentPreset?.defaultModel || '输入模型名称，如 gpt-4o'}
                  disabled={!licenseActivated}
                />
                {currentPreset?.models && currentPreset.models.length > 0 && (
                  <div style={{ fontSize: '11px', color: 'var(--text-hint)', marginTop: '4px' }}>
                    常用模型：{currentPreset.models.join('、')}
                  </div>
                )}
              </div>

              {/* API Key输入 */}
              <div>
                <label className="xhs-input-label">API Key</label>
                <div style={{ display: 'flex', gap: '8px' }}>
                  <input
                    type="password"
                    value={aiConfig.apiKey}
                    onChange={(e) => setAiConfig({ ...aiConfig, apiKey: e.target.value })}
                    className="xhs-input"
                    placeholder={currentPreset?.getKeyPlaceholder || '输入 API Key'}
                    style={{ flex: 1 }}
                    disabled={!licenseActivated}
                  />
                  <button
                    className="xhs-btn xhs-btn-secondary"
                    onClick={handleTestConnection}
                    disabled={testingConnection || !aiConfig.apiKey || !licenseActivated}
                    style={{ 
                      whiteSpace: 'nowrap',
                      padding: '0 12px',
                      fontSize: '12px'
                    }}
                  >
                    {testingConnection ? '测试中...' : '测试连接'}
                  </button>
                </div>
              </div>

              {/* 启用开关 */}
              <div style={{ 
                display: 'flex', 
                alignItems: 'center', 
                justifyContent: 'space-between',
                paddingTop: '8px',
                borderTop: '1px solid var(--border-color)'
              }}>
                <div>
                  <div style={{ fontWeight: 500, fontSize: '14px' }}>启用AI分类</div>
                  <div style={{ fontSize: '12px', color: 'var(--text-hint)' }}>自动为内容添加智能标签</div>
                </div>
                <div 
                  className={`xhs-switch ${aiConfig.enableAIClassify ? 'active' : ''}`}
                  onClick={() => licenseActivated && setAiConfig({ ...aiConfig, enableAIClassify: !aiConfig.enableAIClassify })}
                  style={{ opacity: !licenseActivated ? 0.5 : 1 }}
                />
              </div>

              {/* 模型信息提示 */}
              {aiConfig.enableAIClassify && aiConfig.apiKey && (
                <div style={{ 
                  fontSize: '11px', 
                  color: 'var(--text-hint)',
                  background: 'var(--bg-secondary)',
                  padding: '8px 10px',
                  borderRadius: 'var(--radius-sm)'
                }}>
                  💡 使用 {currentPreset?.name} 的 {aiConfig.model} 模型进行智能分类
                </div>
              )}
            </div>
          </div>

          {/* 智能知识库配置 - 完善版 */}
          <div className="xhs-card glass-card">
            <div className="xhs-card-title">📚 智能知识库</div>
            
            {/* 启用开关 - 突出显示 */}
            <div style={{ 
              display: 'flex', 
              alignItems: 'center', 
              justifyContent: 'space-between',
              marginBottom: '16px',
              padding: '14px 16px',
              background: knowledgeBaseEnabled 
                ? 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)' 
                : 'var(--bg-secondary)',
              borderRadius: '12px',
              color: knowledgeBaseEnabled ? 'white' : 'var(--text-primary)',
              transition: 'all 0.3s ease'
            }}>
              <div>
                <div style={{ fontWeight: 600, fontSize: '15px' }}>启用智能知识库</div>
                <div style={{ fontSize: '12px', opacity: knowledgeBaseEnabled ? 0.9 : 0.7, marginTop: '2px' }}>
                  AI智能分析 + 主题归档 + 学习路径
                </div>
              </div>
              <div 
                className={`xhs-switch ${knowledgeBaseEnabled ? 'active' : ''}`}
                onClick={() => {
                  if (!licenseActivated) {
                    showToast('请先激活授权码', 'warning');
                    return;
                  }
                  toggleKnowledgeBase();
                }}
                style={{ 
                  background: knowledgeBaseEnabled ? 'rgba(255,255,255,0.3)' : 'var(--border-color)',
                  cursor: licenseActivated ? 'pointer' : 'not-allowed',
                  opacity: !licenseActivated ? 0.5 : 1
                }}
              />
            </div>

            {/* 功能模块说明 */}
            {knowledgeBaseEnabled && (
              <>
                <div style={{ marginBottom: '16px' }}>
                  <div style={{ fontWeight: 500, marginBottom: '10px', fontSize: '13px' }}>功能模块</div>
                  
                  <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
                    <div style={featureLabelStyle}>
                      <span>🤖</span>
                      <span>AI自动分析</span>
                      <span style={featureDesc}>自动生成摘要、关键词</span>
                    </div>
                    
                    <div style={featureLabelStyle}>
                      <span>📂</span>
                      <span>主题归档</span>
                      <span style={featureDesc}>按知识领域分类</span>
                    </div>
                    
                    <div style={featureLabelStyle}>
                      <span>🏷️</span>
                      <span>智能标签</span>
                      <span style={featureDesc}>AI生成#教程等标签</span>
                    </div>
                    
                    <div style={featureLabelStyle}>
                      <span>🔍</span>
                      <span>内容索引</span>
                      <span style={featureDesc}>一句话摘要+关键词</span>
                    </div>
                    
                    <div style={featureLabelStyle}>
                      <span>🛤️</span>
                      <span>学习路径</span>
                      <span style={featureDesc}>推荐学习顺序</span>
                    </div>
                  </div>
                </div>

                {/* 创建按钮 */}
                <button
                  className="xhs-btn xhs-btn-primary xhs-btn-block"
                  onClick={() => showToast('智能知识库功能开发中，敬请期待！', 'warning')}
                  style={{ marginBottom: '12px' }}
                >
                  🚀 创建智能知识库
                </button>

                {/* 视图创建引导 */}
                <div style={{ 
                  padding: '12px', 
                  background: 'linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%)',
                  borderRadius: '10px',
                  fontSize: '12px'
                }}>
                  <div style={{ fontWeight: 600, marginBottom: '8px' }}>📋 视图创建指南</div>
                  
                  <div style={{ marginBottom: '8px' }}>
                    <div style={{ fontWeight: 500, color: '#667eea' }}>📂 视图一：按主题浏览</div>
                    <div style={{ color: 'var(--text-secondary)' }}>看板视图 → 按「知识主题」分组</div>
                  </div>
                  
                  <div style={{ marginBottom: '8px' }}>
                    <div style={{ fontWeight: 500, color: '#f093fb' }}>📈 视图二：学习进度</div>
                    <div style={{ color: 'var(--text-secondary)' }}>看板视图 → 按「学习状态」分组</div>
                  </div>
                  
                  <div style={{ marginBottom: '8px' }}>
                    <div style={{ fontWeight: 500, color: '#4facfe' }}>🔍 视图三：快速检索</div>
                    <div style={{ color: 'var(--text-secondary)' }}>表格视图 → 显示摘要、关键词</div>
                  </div>
                  
                  <div>
                    <div style={{ fontWeight: 500, color: '#43e97b' }}>🛤️ 视图四：学习路径</div>
                    <div style={{ color: 'var(--text-secondary)' }}>表格视图 → 按学习路径排序</div>
                  </div>
                </div>

                {/* 知识主题说明 */}
                <div style={{ marginTop: '12px', padding: '10px', background: 'var(--bg-secondary)', borderRadius: '8px', fontSize: '11px' }}>
                  <div style={{ fontWeight: 500, marginBottom: '6px' }}>📚 知识主题分类</div>
                  <div style={{ display: 'flex', flexWrap: 'wrap', gap: '4px' }}>
                    {['编程开发', '设计美学', '理财投资', '职场成长', '健康生活', '语言学习', '效率工具', '兴趣爱好', '其他'].map(topic => (
                      <span key={topic} style={{ 
                        padding: '2px 6px', 
                        background: 'white', 
                        borderRadius: '4px',
                        fontSize: '10px',
                        color: 'var(--text-secondary)'
                      }}>
                        {topic}
                      </span>
                    ))}
                  </div>
                </div>
              </>
            )}
          </div>
        </div>
      )}
    </div>
  </div>
</div>
</div>
  );
};

export default SidePanel;